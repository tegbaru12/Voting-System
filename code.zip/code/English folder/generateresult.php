<!DOCTYPE html>
<?php 
session_start();
?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="generator" content="CoffeeCup HTML Editor (www.coffeecup.com)">
    <meta name="dcterms.created" content="Mon, 23 Dec 2013 21:53:19 GMT">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <title>ETHIOPIA ELECTION BOARD</title>
   <link href="css/ovs.css" type="text/css" rel="stylesheet">
   <script type="text/javascript" src="js/validateVote_form.js"></script>
  </head>
  <body>
<div id="main">
    <div id="header">
	<h1> <table width=100% height=100%> 
<tr>
<td rowspan=3 align="right"><image src="image/et.jpg" width=130 height=120></td>
<td>የኢትዮጲያ ምርጫ ቦርድ</td>
<td> 
<span style="font-size: 10pt;color: white;">LANGUAGE (ቋንቋ):-- <a href="#"><span style="font-size: 10pt;color: white;">ENGLISH /</span></a>
<a href="#"><span style="font-size: 10pt;color: white;">አማረኛ</span></a></span>
</span>
</td>
</tr>
<tr> 
<td>
ELECTION BOARD OF ETHIOPIA</td>
<td>
<span style="font-size: 14pt; font-family: verdana, geneva; color: #ccffff;"><a href="#"><span style="color: #red;">LOGOUT</span></a></span>
</td>	
</tr></table>
</h1>
</div>
</div>
   <div id="menu_container">
   <div id="menubar">
	<div id="nav">
    <ul class="sf-menu dropdown">
    <li><a href="HOME.html">HOME</a></li>
	<li><a href="#">ABOUT ELECTION</a><span class="darrow">&#9660;</span>
			<ul>
				  <li><a href="electionEthio.html">Election in Ethiopia</a></li>
				  <li><a href="#">Country structure</a></li>
				  <li><a href="historydemo.html">Democracy in Ethiopia</a></li>
				  <li><a href="#">About E-VOTING</a></li>
			
		     </ul>
	     </li>
	
	<li><a href="#">POLETICAL PARTY</a><span class="darrow">&#9660;</span>
	     <ul>
		    <li><a href="#">Party in Ethiopia </a></li>
			<li><a href="#">party police</a></li>
			<li><a href ="partyregister.html"> Register Party</a></li>
			<li><a href="#">organize candidate</a></a><span class = "rarrow">&#9654;</span>
				<ul>
				<li><a href="candidate reg.html"> Register Candidate </a></li>
				<li><a href="#">delete from candidate</a></li>
				</ul></li>
			<li><a href="#">Registered Party  </a></a><span class = "rarrow">&#9654;</span>
			 <ul>
				<li> <a href="#">candidate</a>
				</li>
				<li> <a href="#">party logos</a></li>
				<li> <a href ="#">party list</a></li>
				</ul>
				</li>
				<li> <a href="#"> mission of party  and questions</a></li>
		</ul>
	</li>
	<li><a href="#">ELECTION OFFICER</a><span class="darrow">&#9660;</span>
	    <ul>
		    <li><a href="nebe.html">NEBE</a></li>
			<li><a href="createAccount.html">Create EC account</a></li>
			<li><a href="#">Election zone</a></li>
			<li><a href="#">Declarities</a></li>
			<li><a href="#">Proclamation</a></li>
			<li><a href="#">Authority</a></a><span class = "rarrow">&#9654;</span>
			 <ul>
			 <li><a href="#"> party candidate</a> </li></ul>
			 </li>
		</ul>
	</li>
	<li><a href="#">VOTERS</a><span class="darrow">&#9660;</span>
	     
		 <ul>
		    <li><a href="voterregister.html">Register voter</a></li>  
		    <li><a href="#">Vote</a></li>	
		</ul>
	</li>
	<li><a href="#">ELECTION WAY </a><span class="darrow">&#9660;</span>
	     
		 <ul>
		    <li><a href="#">Election period</a></li>
			<li><a href="#">News</a></li>
			<li><a href="#">Governor</a></li>
			<li><a href="#">Election result</a></li>
			<li><a href="#">Photo Gallery</a></li>
		</ul>
	</li>
	<li><a href="#">Comments</a>
		 <ul>
		    <li><a href="comment.html">Comments</a></li>
		</ul>
	</li>  
	  
</ul>
</div>
</div>
</div>
<div id="site_content">	

<div class="sidebar_container1">       
	<div class="sidebar">
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of ETHIOPIA</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of democracy</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of election</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">Past Election in Ethiopia</a></span>
	</div>
	</div>
	<div id="content">
   <div class="content_item">
   <b>
						<div id="contact" background="green">
						<form>
						<?php 
						$localhost="localhost";
			$dbuser="root";
			$dbpass="";
			$dbname="ovs";
			$con=mysql_connect($localhost,$dbuser,$dbpass);
			if(!$con)
			{ 
			die("Coudn't connect to the server");
			}
			$db_select=mysql_select_db($dbname,$con);
			if(!$db_select)
			{
			die("db is not selected".mysql_error());
			}
			$wor=$_POST['woreda'];
			if(!mysql_num_rows(mysql_query("select *from vote where woreda='$wor'")))
			{
			echo"Election Doesn't takes place in this Election zone";
			exit;
			}
			$sql="select *from vote where woreda='$wor' ORDER BY vot DESC";
			$resu=mysql_query($sql);
			if(!$resu)
			{
			echo"Error".mysql_error();
			exit;
			}
			ECHO'<center><font color="green" size="5pt"> ELECTION RESULT OF '.$wor." ".'ELECTION ZONE </font>';
			?>
			
			<table border="green">
			<th>Party Name</th>
			<th>Candidate Name</th>
			<th>Region</th>
			<th>Zone</th>
			<th>Election Zone</th>
			<th>Number of voice</th>
			<?php
			while($row=mysql_fetch_array($resu))
			{
			?>
			<tr>
			<td><?php Echo $row[0];?>
			</td>
			<td><?php Echo $row[1];?>
			</td>
			<td><?php Echo $row[2];?>
			</td>
			<td><?php Echo $row[3];?>
			</td>
			<td><?php Echo $row[4];?>
			</td>
			<td><?php Echo $row[5];?>
			</td>
			</tr>
			<?php
			}
			?>
			</table>
						</form>
						</div>
			</div>
	</div>
	</div>
	<div id="content_green">
	  <div class="content_green_container_box">
		<h4>Latest Post</h4>
	    <p> Hawassa University is a public university in the SNNPR's of Ethiopia.</p>
		<div class="readmore">
		  <a href="#">Read more</a>
		</div>
	  </div>
      <div class="content_green_container_box">
       <h4>Follow Us</h4>
            <div class="footer_social_button">
                <a href="#"><img src="image/facebook.png" title="facebook" alt="facebook" /></a>
				<a href="#"><img src="image/twitter.png" title="twitter" alt="twitter" /></a>
                <a href="#"><img src="image/gmail.png" title="gmail" alt="gmail" /></a>
                <a href="#"><img src="image/youtube.png" title="youtube" alt="youtube" /></a>
			</div>
	  </div>
      <div class="content_green_container_boxl">
			<h4>Latest Election News</h4>
			<p> Ethiopia is one of developing country in east africa.</p>
			<div class="readmore">
			  <a href="#">Read more</a>
			</div> 
	  </div>    
	  <div class="content_green_container_boxl">
			<h4>Latest News</h4>
			<p>Ethiopia is one of developing country in east africa.</p>
			<div class="readmore">
			  <a href="#">Read more</a>
			</div>
		</div>   
    </div> 
</div>
<div id="footer_container">
    <div id="footer">
	<p>
				&copy 2016 by TEGBARU,ALEHEGN,TEWABE AND YIDEG. All Rights Reserved !!!
		</p>
	
    </div>
</div>  
  </body>
</html>
