<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="generator" content="CoffeeCup HTML Editor (www.coffeecup.com)">
    <meta name="dcterms.created" content="Mon, 23 Dec 2013 21:53:19 GMT">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <title>ETHIOPIA ELECTION BOARD</title>
   <link href="css/ovs.css" type="text/css" rel="stylesheet">
<div id="main">
    <div id="header">
	<h1> <table width=100% height=100%> 
<tr>
<td rowspan=3 align="right"><image src="image/et.jpg" width=130 height=120></td>
<td>የኢትዮጲያ ምርጫ ቦርድ</td>
<td> 
<span style="font-size: 10pt;color: white;">LANGUAGE (ቋንቋ):-- <a href="../English folder/HOME.html"><span style="font-size: 10pt;color: white;">ENGLISH /</span></a>
<a href="../amharic folder/HOME.html "><span style="font-size: 10pt;color: white;">አማረኛ</span></a></span>
</span>
</td>
</tr>
<tr> 
<td>
ELECTION BOARD OF ETHIOPIA</td>
<td>
<a href="login.php"><span style="font-size: 16pt; color: red;">[ LOGIN ]</span></a></span>
</td>
</tr></table>
</h1>
</div>
</div>
   <div id="menu_container">
   <div id="menubar">
	<div id="nav">
    <ul class="sf-menu dropdown">
    <li><a href="HOME.php">HOME</a></li>
	<li><a href="#">ABOUT ELECTION</a><span class="darrow">&#9660;</span>
			<ul>
				  <li><a href="electionEthio.php">Election in Ethiopia</a></li>
				  <li><a href="counstruct.php">Country structure</a></li>
				  <li><a href="historydemo.php">Democracy in Ethiopia</a></li>
				  <li><a href="aboutevot.php">About E-VOTING</a></li>
			
		     </ul>
	     </li>
	
	<li><a href="#">POLETICAL PARTY</a><span class="darrow">&#9660;</span>
	     <ul>
		    <li><a href="partyInEthio.php">Party in Ethiopia </a></li>
			<li><a href="partypolice.php">party police</a></li>
			<li><a href ="partyregister.php"> Register Party</a></li>
			<li><a href="#">organize candidate</a></a><span class = "rarrow">&#9654;</span>
				<ul>
				<li><a href="party/candidate regsiter.php"> Register Candidate </a></li>
				<li><a href="party/deletecandidate.php">Replace Candidate</a></li>
				</ul></li>
			<li><a href="#">Registered Party  </a></a><span class = "rarrow">&#9654;</span>
			 <ul>
				<li> <a href="#">candidate</a>
				</li>
				<li> <a href="partylogo.php">party logos</a></li>
				<li> <a href ="partylist.php">party list</a></li>
				</ul>
				</li>
				<li> <a href="#"> mission of party  and questions</a></li>
		</ul>
	</li>
	<li><a href="#">ELECTION OFFICER</a><span class="darrow">&#9660;</span>
	    <ul>
		    <li><a href="nebe.php">NEBE</a></li>
			<li><a href="ECA/createAccount.php">Create EC account</a></li>
			<li><a href="#">Election zone</a></li>
			<li><a href="#">Declarities</a></li>
			<li><a href="#">Proclamation</a></li>
			<li><a href="#">Authority</a></a><span class = "rarrow">&#9654;</span>
			 <ul>
			 <li><a href="#"> party candidate</a> </li></ul>
			 </li>
		</ul>
	</li>
	<li><a href="#">VOTERS</a><span class="darrow">&#9660;</span>
	     
		 <ul>
		    <li><a href="ECA/voterregister.php">Register voter</a></li>
		    <li><a href="voter/vote.php">Vote</a></li>
			 <li><a href="aboutvoter.php">About voter</a></li>
		</ul>
	</li>
	<li><a href="#">ELECTION WAY </a><span class="darrow">&#9660;</span>
	     
		 <ul>
		    <li><a href="#">Election period</a></li>
			<li><a href="#">News</a></li>
			<li><a href="#">Governor</a></li>
			<li><a href="#">Photo Gallery</a></li>
		</ul>
	</li>
		<li><a href="#">View</a>
			<ul>
				<li><a href="resultserch.php">Election result</a></li>
				<li><a href="seats.php">winned seats</a></li>
			</ul>
		</li>
	  
</ul>
</div>
</div>
</div>