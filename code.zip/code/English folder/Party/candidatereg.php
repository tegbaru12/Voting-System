<?php
/**
 * Created by PhpStorm.
 * User: alexo
 * Date: 5/27/2016
 * Time: 12:53 AM
 */
session_start();
include ("partyheader.php");
?>
    <STYLE TYPE="text/css">
		#site_content
		{
			padding: 0px;
			width: 1200px;
			height:900px;
			overflow: hidden;
			margin:80px auto;
			text-align:left;
			background:#ccc url(../image/mainback.jpg) repeat;
			border:2px solid green;
		}
</style>
	<?php
	include ("sidebar.php");
	?>
	<div id="content">
<div class="content_item">
<div id="contact" class="body">
<form name = "CandidateForm">
<font size="5pt" color="green">
<?php
$userna=$_SESSION['login_party'];
$localhost="localhost";
$dbuser="root";
$dbpass="";
$dbname="ovs";
$con=mysql_connect($localhost,$dbuser,$dbpass);
if(!$con)
{ die("Coudn't connect to the server");
}
$db_select=mysql_select_db($dbname,$con);
if(!$db_select)
{
die("db is not selected".mysql_error());
}
$cname=$_POST['ca_name'];
$cposition=$_POST['rep_of'];
$cssn=$_POST['ca_ssn'];
$sex=$_POST['ca-Sex'];
$ag=$_POST['ca_age'];
$cpro=$_POST['party_rep_pro'];
$nati=$_POST['Nationality'];
$reg=$_POST['region'];
$zon=$_POST['zone'];
$wor=$_POST['woreda'];
$ema=$_POST['email'];
$phn=$_POST['pho_num'];
$use_name=$_POST['User_name'];
$pass=md5($_POST ['password']);
if(getimagesize($_FILES['can_pic']['tmp_name'])==FALSE)
{
echo "please upload candidate photo";
exit;
}
$img_name=$_FILES['can_pic']['name'];
$temp=$_FILES['can_pic']['tmp_name'];
$file_type=$_FILES['can_pic']['type'];
$size=$_FILES['can_pic']['size'];
if($size>500000)
{
echo "image is too large";
exit;
}
$image=addslashes($temp);
$image=file_get_contents($image);
$target_file=$image;
$image=base64_encode($image);
/*if(!mysql_num_rows(mysql_query("select party_name from party where party_name='$pname'")))
{
echo $pname."This party is not registered yet";
exit;
$x=1;
}*/
$sele="select *from party where user_name='$userna' ";
$result=mysql_query( $sele);
while($row=mysql_fetch_array($result))
{
	$pname=$row[0];
}
$inser="INSERT INTO cand(party_name,C_name,	profile_pic, position,C_ssn, sex, age, C_prof, nationality, region, zone, woreda, e_mail, phone_num, user_name, password,status) VALUES 
          ('$pname','$cname','$image','$cposition','$cssn','$sex','$ag','$cpro','$nati','$reg','$zon','$wor','$ema','$phn','$use_name','$pass',1)";
if (!mysql_query($inser))
{
die('you  used   ' .mysql_error());
  }
  echo "You have successfully register candidate with the following details";
  mysql_close($con);
?>
						<table border="green"> 
				<tr>
				<td>Party name</td><td><?php echo $pname?></td>
				</tr>
				<tr>
				<td>Candidate Name</td><td><?php echo $cname?></td></tr>
				<tr>
				<tr>
				<td>Candidate computing  position</td><td><?php echo $cposition?></td></tr>
				<tr>
				<td>candidate social security code</td><td><?php echo $cssn?></td></tr>
				<tr>
				<td>candidate sex</td><td><?php echo $sex?></td></tr>
				<tr>
				<td>Candidate Age</td><td><?php echo $ag?></td></tr>
				<tr>
				<td>candidate proffesion</td><td><?php echo $cpro?></td></tr>
				<tr>
				<td>Nationality</dt><td><?php echo $nati?></td></tr>
				<tr>
				<td>Region</td><td><?php echo $reg?></td></tr>
				<tr>
				<td>zone</td><td><?php echo $zon?></td></tr>
				<tr>
				<td>woreda</td><td><?php echo $wor?></td></tr>
				<tr>
				<td>E-mail</td><td><?php echo $ema?></td></tr>
				<tr>
				<td>phone number</td><td><?php echo $phn?></td></tr>
				<tr>
				<td>User name</td><td><?php echo $use_name?></td></tr>
				<tr>
				<td>Password</td><td><?php echo $pass?></td></tr>
				<tr>
				<td> Candidate Photo</td>
				<td><?php echo '<img src=" data:image;base64,'. $image.'" height="130" width="130" alt="file not found" />'?></td>
				</tr>
				</table>
				<br>
				<br>
				</font>
				<center><a href="#"><span style="font-size: 15pt;color: blue;">Print</a></center></span>
				
				</form>
					</div>
							</div>
					</div>
					</div>
	<?php
	include ("../footer.php");
	?>
  </body>
</html>