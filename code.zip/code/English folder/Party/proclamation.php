<?php
/**
 * Created by PhpStorm.
 * User: alexo
 * Date: 5/27/2016
 * Time: 12:53 AM
 */
session_start();
ini_set('post_max_size','800M');
ini_set('upload_max_filesize','800M');
include ("partyheader.php");
include ("sidebar.php");

?>
<style type="text/css" xmlns="http://www.w3.org/1999/html">
    #site_content
    {
        padding: 0px;
        overflow: hidden;
        height: 2000px;
        margin:10px auto;
        text-align:left;
        border:5px solid green;
    }
    </style>
    <div id="content">
    <div class="content_item">
        <p><font size="6pt" color="blue"><b><u>Proclamation from Ethiopia Constutution</U></b></FONT></p>
    <p> <font size="5pt" color="green">The Revised Political Parties Registration Proclamation</font> </p>
        <p><font size="3pt" color="red">PROCLAMATION NO. 573/2008<br>
    POLITICAL PARTIES REGISTRATION PROCLAMATION</font></p>
    <p>
     Whereas, it is necessary to regulate by law the conditions by which citizens using their freedom of association in accordance
    with the Constitution for participating in peaceful and lawful political activities to assume political power;
    Whereas, it is necessary, to provide the right and duty of citizens when forming political parties and acting as members of
    political parties, and also by providing basic principles to be followed by political parties to enable the political parties to act
    upon having legal personality;</p>
    <p> <font size="5pt" color="green"> A PROCLAMATION TO AMEND THE ELECTORAL LAW OF ETHIOPIA</font></p>
       <p> <font size="3pt" color="red">Proclamation No. 532/2007<br>
   A PROCLAMATION TO AMEND THE ELECTORAL LAW OF ETHIOPIA</font></p>
    <p>
    WHEREAS, it has become necessary to enable the nations, nationalities and peoples of Ethiopia to exercise their right to
    self administration without any discrimination through their representatives elected in a direct and free election;
    WHEREAS, it has become necessary that any electoral activity shall be guided by an electoral law that meets international
    standards;
    WHEREAS, it has become necessary to establish an electoral institution that conducts free, fair and peaceful elections at
    every level in an impartial manner in which Ethiopians freely express their will on the basis of equal popular suffrage and
    secret ballot system;</p>
    <p> <font size="5pt" color="green"> Proclamation on the Electoral Code of Conduct for Political Parties</font></p>
        <p> <font color="red">PROCLAMATION NO. 662/2009<br>
                Proclamation on the Electoral Code of Conduct for Political Parties</font></p>
    <p>
      WHEREAS, is necessary to provide an electoral code of conduct for political parties, candidates, members and supporters
    of political parties to ensure that subsequent elections which draw lessons from previous elections are transparent, free,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                legitimate, fair, peaceful, democratic and acceptable by the people;
    WHEREAS, Believing and accepting the impotence of full enforcement of human and democratic rights in our country for a
    legal civilized, democratic and peaceful competition for power;</p>


    </div>
    </div>
      </div>
        <?php
        include ("../footer.php");
        ?>
   </body>
   </html>