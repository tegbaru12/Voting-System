<!DOCTYPE html>
	<head>
<?php
session_start();
include ("partyheader.php");
?>
<style type="text/css">
#site_content
{
padding: 0px;
width: 1200px;
height:1200px;
overflow: hidden;
margin:10px auto;
text-align:left;
background:#ccc url(../image/mainback.jpg) repeat;
border:5px solid green;
}
</style></head>
<?php
include ("sidebar.php");
?>
<div id="content">
<div class="content_item">
		<b>
			<div id="contact" class="body">
				<form>
						<table border="red">
<?php
$userna=$_SESSION['login_party'];
$localhost="localhost";
$dbuser="root";
$dbpass="";
$dbname="ovs";
$con=mysql_connect($localhost,$dbuser,$dbpass);
if(!$con)
{ die("Coudn't connect to the server");
}
$db_select=mysql_select_db($dbname,$con);
if(!$db_select)
{
	die("db is not selected".mysql_error());
}
$sql="select *from party where user_name='$userna'";
$result=mysql_query($sql);
while ($row=mysql_fetch_row($result))
{
	echo'<tr><td>Party Name:</td> <td>'.$row[0].'</td></tr>';
	echo'<tr><td>Party name Abrevation:</td> <td>'.$row[1].'</td></tr>';
	echo'<tr><td>party Symbol name:</td> <td>'.$row[2].'</td></tr>';
	echo'<tr><td>Part symbol:</td> <td><img src=" data:image;base64,'. $row[3].'" height="130" width="130" alt="image not found"/></td></tr>';
	echo'<tr><td>Party representative:</td><td> <table><tr><td> Name</td><td>'.$row[4].'</td></tr>
	<tr><td>ssc</td><td>'.$row[5].'</td></tr>
	<tr><td> Sex</td><td>'.$row[6].'</td></tr>
	<tr><td>Age</td><td>'.$row[7].'</td></tr>
	<tr><td>Proffision</td><td>'.$row[8].'</td></tr>';
	echo'<tr><td>Nationality:</td> <td>'.$row[9].'</td></tr>';
	echo'<tr><td>Region:</td> <td>'.$row[10].'</td></tr>';
	echo'<tr><td>Zone:</td> <td>'.$row[11].'</td></tr>';
	echo'<tr><td>Woreda:</td> <td>'.$row[12].'</td></tr>';
	echo'<tr><td>E_mail:</td> <td>'.$row[13].'</td></tr>';
	echo'<tr><td>Phone Number:</td> <td>'.$row[14].'</td></tr></td></tr></table>';
	echo'<tr><td>User Name:</td> <td>'.$row[15].'</td></tr>';
	if($row[18]==0)
	{
		echo'<tr><td> Remark</td><td> This party is Not approved so <br>it can not partcipate on election </td></tr>';
	}
	else
	{
		echo'<tr><td> Remark</td><td> This party  is approved so <br>it can  partcipate on election </td></tr>';
	}

}
mysql_close($con);
?>
						</table>
				</form>
			</div>
	</div>
</div>
</div>
	<?php
	include ("../footer.php");
	?>
	</body>
	</html>
