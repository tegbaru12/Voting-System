<!DOCTYPE html>
<html lang="AM">
<head>
	<?php
	session_start();
	include ("partyheader.php");

	?>
    <STYLE TYPE="text/css">
	 #contact form {
	background: rgba(149, 75, 75, 0.11);
margin:auto;
position:relative;
width:650px;
height:900px;
font-family: ;
font-size: 14px;
font-style: italic;
line-height: 24px;
font-weight: ;
color: black;
text-decoration: none;
-webkit-border-radius: 10px;
-moz-border-radius: 10px;
border-radius: 10px;
padding:10px;
}
#site_content
{ 
    padding: 0px;
	width: 1200px;
	height:1100px;
	overflow: hidden;
	margin:10px auto;
	text-align:left;
	background:#ccc url(../image/mainback.jpg) repeat;
	border:5px solid green;
}
</style>
</head>
<?php
include ("sidebar.php");
?>
<div id="content">
<div class="content_item">
<b>
<div id="contact" class="body">
	<form  method="post">
		<?php
		$localhost="localhost";
		$dbuser="root";
		$dbpass="";
		$dbname="ovs";
		$con=mysql_connect($localhost,$dbuser,$dbpass);
		if(!$con)
		{ die("Coudn't connect to the server");
		}
		$db_select=mysql_select_db($dbname,$con);
		if(!$db_select)
		{
		die("db is not selected".mysql_error());
		}
		$id=$_POST['num'];
		if(!mysql_num_rows(mysql_query("select *from cand where id='$id'")))
		{
		echo'<font size="4pt" color="red"> NO Such candidate number found</font>';
		exit;
		}
		$sql="select *from cand WHERE id='$id'";
		$res=mysql_query($sql);
		echo'<table border="red">';
			while($ro=mysql_fetch_array($res))
			{
			echo'<tr><td> candidate number</td><td>'.$ro[0].'</td></tr>
			<tr>
				<td>Profile Picture</td><td><img src=" data:image;base64,'. $ro[3].'" height="130" width="130" alt="file not found" /></td>
			</tr>
			<tr>
				<td>Candidate Name</td><td>'.$ro[2].'</td></tr>
			<tr>
			<tr>
				<td>candidate to party </td><td>'.$ro[1].'</td></tr>
			<tr>
				<td>Subjected to </td><td>'.$ro[4].'</td></tr>
			<tr>
				<td>candidate social security code</td><td>'.$ro[5].'</td></tr>
			<tr>
				<td>candidate sex</td><td>'.$ro[6].'</td></tr>
			<tr>
				<td>Candidate Age</td><td>'.$ro[7].'</td></tr>
			<tr>
				<td>candidate proffesion</td><td>'.$ro[8].'</td></tr>
			<tr>
				<td>Nationality</dt><td>'.$ro[9].'</td></tr>
			<tr>
				<td>Region</td><td>'.$ro[10].'</td></tr>
			<tr>
				<td>zone</td><td>'.$ro[11].'</td></tr>
			<tr>
				<td>woreda</td><td>'.$ro[12].'</td></tr>
			<tr>
				<td>E-mail</td><td>'.$ro[13].'</td></tr>
			<tr>
				<td>phone number</td><td>'.$ro[14].'</td></tr>
			<tr>
				<td>User name</td><td>'.$ro[15].'</td></tr>';
			echo '<tr><td> Remark</td>';
				$st=$ro[17];
				if($ro[17]==1)
				{
				echo'<td>candidate can compute for election</td></tr>';
			}
			else
			{
			echo'<td> candidate can not compute for election</td></tr>';
			}
				echo '</table>';
			}
		if($st==1)
		{
			$sql = "update cand set status=0 WHERE id=$id";
			if (!(mysql_query($sql))) {
				echo 'Error on susbending' . mysql_error();
				exit;
			} else {
				Echo '<font color="#8a2be2" size="5pt">Candidate ' . $id . 'susbended from computation</font>';
				exit;
			}
		}
		else
		{
			$sql = "update cand set status=1 WHERE id=$id";
			if (!(mysql_query($sql))) {
				echo 'Error on permissioned to computing' . mysql_error();
				exit;
			} else {
				Echo '<font color="#8a2be2" size="5pt">Candidate ' . $id . 'permissioned to participate on election</font>';
				exit;
			}

		}
		?>
		</form>
</div>
</div>
	</div>
	</div>
		<?php
		include ("../footer.php");
		?>
  </body>
</html>
