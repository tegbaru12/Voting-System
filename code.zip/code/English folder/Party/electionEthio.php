
<!DOCTYPE html>
<?php
session_start();
include("partyheader.php");
include ("sidebar.php");
?>

	<div id="content">
		<div class="content_item">
			<div id="bheder">
				<b><font size="12pt" color="blue">ETHIOPIAN ELECTION (የኢትዮጵያውያን ምርጫ)</font></b>
			</div>
			<p>National Elections in Ethiopia began in the 20th Century. In July, 1935 Emperor Haile Selassie
				granted a Constitution that asserted his own status, reserved imperial succession to the line of Haile Selassie, and declared
				that ‹‹the Person of the Emperor is sacred, his dignity inviolable and his power Indisputable.››</p>

			<p>
				<b>Elections During the Reign of Emperor Haile Selassie</p>
			<p>
				1931 - 1936 (Prior to the Italian occupation) The first Parliament was established in 1931.</b></p>
			<ol value=1>
				<li>It was bi-cameral i.e. the Chamber of Deputies and the Senate.</li>
				<li>Thechamber of Deputies constituted members chosen by the Emperor, the nobility
					and the aristocrats.</li>
				<li>The Senate was composed of members of the nobility, the aristocracy, ministers,
					Distinguished Veterans and Commanders noted for their long Service.</li>
				<li>The number of the members of the two houses was equal</li>
				<li>The term of the Deputies to the Chamber was 15 to 20 Years.</li>
			</ol>

			<p><b>The Parliament established After 1941 (Post Italian Occupation)</b></p>
			<ol value=1>
				<li> There was no change in structure from the previous arrangement.
					The elders used to meet at the district level and elect the landed aristocrats as members of the senate.</li>
				<li>The election to the Chamber of Deputies was proclaimed in the revised constitution of 1955</li>
				<li>There were five elections between 1955 and 1974</li>
				<li>Both the Chamber of Deputies and the Senate were the legislative bodies.</li>
				<li>The number of Deputies reached 250 and the Senate 125 at the end of their mandate</li>
				<li>Members to the Chamber of Deputies in the last assembly were mostly from the highly paid
					segments of the civil Service, Feudal lords and rich merchantsv</li></ol>
			<p><B>Election During the Dergue (Military Junta)</b></p>
			<ol value=1><li>An assembly of councilors consisting of 60 members selected from various government Institutions
					and provinces was established in October 1974.The mandate of this assembly lasted until 1975
				</li>
				<li>The rule of the Dergue was socialist oriented.
				</li>
				<li>The people were organized in various associations to elect their representative. There were direct and indirect
					modalities of elections
				</li>
				<li>Members to the various posts of leadership were elected only from the rank of followers and
					supporters of socialism. No other group was eligible
				</li>
				<li>A uni-cameral assembly or the National Council (the Shengo) with 835 members was established in 1986.
				</li>
				<li>The 'Shengo' was structured at the national, autonomous and the regional administrator levels with a five-year term.
				</li></ol>
			<p><b>The Transitional Government of Ethiopia
			</p></b>
			</p>
			<ol value=1>
				<li>The EPRDF toppled the Dergue through Popular armed struggle and established a Transitional
					Government (TGE) in 1991
				</li>
				<li>The Transitional Government consisted of political organizations and National Liberation
					Movements that endorsed a Transitional Charter in June 1991.
				</li>
				<li>Elections of members to the Chambers of regional states and Woreda (district) Councils were conducted in 1992
				</li>
				<li>The National Electoral Commission, accountable to the House of Representatives,
					was established through Proclamation No. 11/1992.
				</li>
				<li>The mandate of the National Electoral Commission
					terminated after the election of members of regional and zonal councils</li>
				<li>The Ethiopian National Electoral Board was established, as a free and
					neutral institution, based on proclamation No. 64/1993.
				</li></ol>
			<font size="5pt"><b>The Federal Democratic Republic of Ethiopia (FDRE)</b></font>
			</p><ol value=1>
				<li>The government has a Federal Structure
				</li>
				<li>There are two Houses. The House of People's representative and the House of the Federation.
				</li>
				<li>The House of People's Representatives has 547 members, elected for a term of five Years
				</li>
				<li>The House of the Federation is composed of representatives of Nations, Nationalities
					and Peoples. It has 112 members elected for a term of five Years.
					<</li>
				<li>The Regional State Councils elect the members of the House of Federation.
				</li>
				<li>Each nation, nationalities and peoples is represented in the house of the Federation by at least one Deputy.</li></ol>
		</div>
	</div>
</div>
<?php
include("../footer.php");
?>
</body>
</html>
