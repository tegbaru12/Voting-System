<?php
/**
 * Created by PhpStorm.
 * User: alexo
 * Date: 5/27/2016
 * Time: 12:53 AM
 */
session_start();
include ("partyheader.php");
include ('sidebar.php');
?>
    <div id="content">
    <div id="contact" class="body">
        <form name = "CandidateForm">
<?php
$userna=$_SESSION['login_party'];
$localhost="localhost";
$dbuser="root";
$dbpass="";
$dbname="ovs";
$con=mysql_connect($localhost,$dbuser,$dbpass);
if(!$con)
{ die("Coudn't connect to the server");
}
$db_select=mysql_select_db($dbname,$con);
if(!$db_select)
{
    die("db is not selected".mysql_error());
}
$sele="select *from party where user_name='$userna' ";
$res=mysql_query($sele);
if(!($res))
{
    echo "error".mysql_error();
    exit;
}
while ($row=mysql_fetch_array($res))
{
    $wore=$row[0];
}
if(!(mysql_num_rows(mysql_query("select *from cand where party_name='$wore' AND status=1 "))))
{
    Echo'<font color="red" size="5pt">This party have not any candidate registered</font>';
    exit;
}

echo '<font size="5pt" color="green">Candidates of '.$wore.'  party</font>';
$sel="select *from cand  where party_name='$wore' AND status=1 ";
$result=mysql_query($sel);
if(!($result))
{
    echo'error'.mysql_error();
    exit;
}
echo '<table border="green">';
echo'<th>Candidate number</th>
     <th> candidate  name</th>
     <th>Region</th>
     <th> Election Zone</th>
<th> candidate photo</th>';
while($ro=mysql_fetch_array($result)) {
    echo'<tr><td>'.$ro[0].'</td>';
    echo'<td>'.$ro[2].'</td>';
    echo'<td>'.$ro[10].'</td>';
    echo'<td>'.$ro[12].'</td>';
    echo'<td><img src=" data:image;base64,'. $ro[3].'" height="130" width="130" alt="file not found" /></td></tr>';
}
echo '</table>';
mysql_close($con);
?>
            </form>
    </div>
    </div>
</div>
</div>
<?php
include ("../footer.php");
?>
</body>
</html>

