<?php
/**
 * Created by PhpStorm.
 * User: alexo
 * Date: 5/27/2016
 * Time: 12:53 AM
 */
session_start();
include ("partyheader.php");
?>
    <STYLE TYPE="text/css">
 #contact form {
	background: #ccc url(../image/mainback.jpg) repeat;
margin:auto;
position:relative;
width:580px;
height:200px;
font-family: ;
font-size: 14px;
font-style: italic;
line-height: 24px;
font-weight: ;
color: black;
text-decoration: none;
-webkit-border-radius: 10px;
-moz-border-radius: 10px;
border-radius: 10px;
padding:10px;
border: 1px solid #99779;
border: inset 0px solid #0d332b;
-webkit-box-shadow: 0px 0px 28px rgba(98, 98, 24, 0.58);
-moz-box-shadow: 0px 0px 28px rgba(121, 124, 15, 0.9);
box-shadow: 0px 0px 28px rgba(0, 0, 0, 0.21)
}
</style>
	  <?php
	  include ("sidebar.php");
	  ?>

<div id="content"
<div class="content_item">
					<b>
						<div id="contact" class="body">
							<form name = "CandidateForm" enctype="multipart/form-data" action ="candidatedel.php" method="POST" onsubmit = "return validateForm(this.form);">
								<legend align="center"><font color="blue" size="5pt">Search candidate to be susbended </font></legend>
								<table >
									<tbody  > 
										<tr>
											<td align="right">Enter candidate number:</td>
											<td><input id = "num" name = "num"class = "contactFormInput" type="text" class="txtfield" placeholder = "Candidate number here"required><button  name="sea" id="sea"type = "submit" ><strong> Search </strong></button> </td>
								
										</tr>
									</tbody>
								</table>
							</form>
				</div>
			</div>
	</div>
	</div>
	  <?php
	  include ("../footer.php");
	  ?>
  </body>
</html>