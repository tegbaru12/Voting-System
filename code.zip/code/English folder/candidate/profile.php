<?php
/**
 * Created by PhpStorm.
 * User: alexo
 * Date: 5/27/2016
 * Time: 12:53 AM
 */
session_start();
include ("candheader.php");
?>
    <STYLE TYPE="text/css">
		#site_content
		{
			padding: 0px;
			width: 1200px;
			height:900px;
			overflow: hidden;
			margin:80px auto;
			text-align:left;
			background:#ccc url(../image/mainback.jpg) repeat;
			border:2px solid green;
		}
</style>
	<?php
	include ("sidebar.php");
	?>
	<div id="content">
<div id="contact" class="body">
<form name = "CandidateForm">
<font size="5pt" color="green">your profile</font>
<?php
$use=$_SESSION['login_cand'];
$localhost="localhost";
$dbuser="root";
$dbpass="";
$dbname="ovs";
$con=mysql_connect($localhost,$dbuser,$dbpass);
if(!$con)
{ die("Coudn't connect to the server");
}
$db_select=mysql_select_db($dbname,$con);
if(!$db_select)
{
die("db is not selected".mysql_error());
}
$sql="select *from cand WHERE  user_name='$use'";
$res=mysql_query($sql);
echo'<table>';
while($ro=mysql_fetch_array($res))
{
echo'<tr><td> candidate number</td><td>'.$ro[0].'</td></tr>
<tr>
	<td>Profile Picture</td><td><img src=" data:image;base64,'. $ro[3].'" height="130" width="130" alt="file not found" /></td>
	</tr>
	<tr>
	<td>Candidate Name</td><td>'.$ro[2].'</td></tr>
	<tr>
	<tr>
	<td>candidate to party </td><td>'.$ro[1].'</td></tr>
	<tr>
	<td>Subjected to </td><td>'.$ro[4].'</td></tr>
	<tr>
	<td>candidate social security code</td><td>'.$ro[5].'</td></tr>
	<tr>
	<td>candidate sex</td><td>'.$ro[6].'</td></tr>
	<tr>
		<td>Candidate Age</td><td>'.$ro[7].'</td></tr>
	<tr>
		<td>candidate proffesion</td><td>'.$ro[8].'</td></tr>
	<tr>
		<td>Nationality</dt><td>'.$ro[9].'</td></tr>
	<tr>
		<td>Region</td><td>'.$ro[10].'</td></tr>
	<tr>
		<td>zone</td><td>'.$ro[11].'</td></tr>
	<tr>
		<td>woreda</td><td>'.$ro[12].'</td></tr>
	<tr>
		<td>E-mail</td><td>'.$ro[13].'</td></tr>
	<tr>
		<td>phone number</td><td>'.$ro[14].'</td></tr>
	<tr>
		<td>User name</td><td>'.$ro[15].'</td></tr>';
	
}
	echo'</table>';
mysql_close($con);
?>
</form>
</div>
	</div>
	</div>
	</div>

	<?php
	include ("../footer.php");
	?>
	</body>
</html>