<!DOCTYPE html>
<?php
session_start();
include("candheader.php");
include ("sidebar.php");
?>
	<div id="content">
		<div class="content_item">

			<p><font size="10pt" color="blue"><b> <U>DEMOCRACY IN ETHIOPIA</U></b></FONT></p>
			<p>From the 1700s, for roughly 100 years, there was no central power in Ethiopia. This "Era of the Princes" was characterized by
				the turmoil caused by local rulers competing against each other. In 1869, however, Emperor Tewodros brought many of the princes together, and was a significant
				unifying force. He was succeeded by Emperor Yohannes, who built upon the efforts made by Tewodros, as well as beating off invasion
				attempts by the Dervish and the Sudanese..</P>

			<p>
				Emperor Menelik II reigned from 1889 to 1913, fending off the encroachment of European powers. Italy posed the greatest threat, having begun to
				colonize part of what would become its future colony of Eritrea in the mid 1880s. In 1896 Ethiopia defeated Italy at the Battle of Adwa, which remains famous today as the first victory of
				an African nation over a colonial power</P>
			<p> In 1916, the Christian nobility deposed the sitting king, Lij Iyassu because of his Muslim sympathies and made his predecessor's, (King Menelik 11 1889 - 1913), daughter, Zewditu, Empress. Her cousin, Ras Tafari Makonnen (1892-1975) was appointed regent and successor
				to the throne.l></P>

			<p>Zewditu died in 1930, after which the regent - adopting the name Haileselassie - became Emperor. His reign was interrupted in 1936 when Italian forces briefly invaded and occupied Ethiopia. Haileselassie then appealed to the League of Nations, but that appeal fell on deaf ears and he fled to exile in the UK, where he spent five years until the Ethiopian patriotic resistance forces with the help of the
				British defeated the Italians and he returned to his throne</p>
			<p>
				Haileselassie then reigned until 1974 when he was deposed and a provisional council of soldiers (the Derg, meaning committee) seized power and installed a government which was socialist in name and military in style. Fifty nine members of the Royal Family and ministers and generals from the Imperial Government were summarily executed. Haile Selassie himself was strangled in the
				basement of his palace in August 1975.</p>
			<pMajor Mengistu Haile Mariam assumed power as head of state and Derg chairman after having his two predecessors killed. His years in office were marked by a totalitarian style government and the country's massive militarisation financed
			and supplied by the Soviet Union and assisted by Cuba.
			</p>

			<p>
				The brutality of the regime over a period of 17 years - aided by droughts and famine - hastened the Derg's collapse.
			</p>

			<p>Insurrections occurred throughout Ethiopia, particularly in the northern regions of Tigray and Eritrea.
				In 1989, the Tigrayan People's Liberation front (TPLF) merged with the Amhara and Oromo liberation fronts (EPDM & OPDO) to form the Ethiopian Peoples' Revolutionary
				Democratic Front (EPRDF). In May 1991, the EPRDF forces advanced on Addis Ababa
				forcing Mengistu to flee to Zimbabwe.</p>

			<p>In 1991, the Transitional Government of Ethiopia (TGE) was set up from the EPRDF and other political
				parties in the country with an 87 strong Council of Representatives and a transitional constitution.
			</p>
			<P>
				Meanwhile, in May 1991, The Eritrean People's Liberation front (EPLF), led by Isaias Afworki assumed control of Eritrea after 30 years of struggle and established
				a provisional government.
				This ran Eritrea until April 1993 when Eritreans voted for independence in a UN monitored referendum.
			</P>
			<P>
				In Ethiopia, President Meles Zenawi and members of the TGE pledged to oversee the formation of a multi-party democracy. The election for a 548 member
				constituent assembly was held in June 1994. This assembly adopted the constitution of the Federal Democratic Republic of Ethiopia in December 1994. Elections
				for the first parliament were held in 1995 and the government was installed in August of that year.</P>
			<P>Ethiopia adopted a new constitution that established the Federal Democratic Republic of Ethiopia (FDRE) in 1995.The federal government is responsible for
				national defense, foreign relations and general policy of common interest and benefits. The federal state comprises nine autonomous states vested with power for
				self-determination.  The FDRE is structured along the lines of bicameral parliament, with the council of Peoples' Representatives being the highest authority of
				the federal government while the federal council represents the common interests of the nations, nationalities and peoples of the states. Members of both councils
				are elected by universal suffrage for a five-year term.</P>
			<P>The federal state is headed by a constitution president and the federal government by an executive prime minister who is accountable to the council of peoples'
				Representative.  Each autonomous state is headed by a state president elected by the state council.  The judiciary is constitutionally independent.
			</P>
			<P>
				The Federal Democratic Republic is composed of states which are delimited on the basis of settlement patterns, language, identity and consent of the peoples concerned.
				<A HREF="http://www.ethiopia.gov.et/web/Pages/GovernmentOverview">READ MORE</A></P>
		</div></div></div>
<?php
include("../footer.php");
?>
</body>
</html>
