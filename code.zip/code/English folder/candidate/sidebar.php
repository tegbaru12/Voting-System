	  <div id="site_content">
		  <div class="sidebar_container1">
			  <div class="sidebar">
				  <a href="#"><span style="color: blue;font-size: 12pt;">History of ETHIOPIA</a></span><br>
				  <a href="#"><span style="color: blue;font-size: 12pt;">History of democracy</a></span><br>
				  <a href="#"><span style="color: blue;font-size: 12pt;">History of election</a></span><br>
				  <a href="#"><span style="color: blue;font-size: 12pt;">Past Election in Ethiopia</a></span>
			  </div>
		  </div>
		  <div class="sidebar_container2">
			  <div class="sidebar">
				  <p><font size="3pt"> </u><b>Election</b></u></p>
				  <ul>
					  <p><li><a href="#">past election in ethiopia</a></p>…</font>
					  <ul>
						  <p><li><a href="#">the 2005 ethiopian election</a></p>…</font></li>
						  <p><li><a href="#">the 2010 ethiopian election</</a></p>…</font></li>
						  <p><li><a href="#">the 2015 ethiopian election</</a></p>…</font></li></ul></li>
					  <p><li><a href="#">structure of past ethiopian Government</a></p>…</font>
					  <ul><p><li><a href="#">zemene mesafinit</a></p>…</font></li>
						  <p>Between 1755 to 1855, Ethiopia experienced a period of isolation referred to as the Zemene Mesafint or "Age of Princes". The Emperors became figureheads.</<a href="#">read more</a>
						  </p>
						  <p><li><a href="#">Ethiopia 1855-1991</a></p>…</font></li>
						  <p>
							  The Emperor of Ethiopia was refered to as Niguse Negest (King of Kings) and Atse (Emperor).This time pass through  emperor Tewodros II,emperor Yohanis IV,
							  emperor minilik II,lij Eyasu, Zewditu ,emperor H/silasie and derue<a href="#">read more </a>
						  </p>
						  <p><li><a href="#">EFDRE </a></p>…</font></li></ul>
					  </li>
					  <p>
					  </p>
				  </ul>
			  </div>
		  </div>