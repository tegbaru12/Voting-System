<!DOCTYPE html>
<html lang="en">
<head>
	<?php
	session_start();
	include ("candheader.php");
	?>
	<script type="text/javascript" src="../js/validatePart_form.js"></script>
	<STYLE TYPE="text/css">
		#contact form {
			background: #f2f5f5;
			margin:auto;
			position:relative;
			width:680px;
			height:600px;
			font-family: ;
			font-size: 14px;
			font-style: italic;
			line-height: 24px;
			font-weight: ;
			color: black;
			text-decoration: none;
			-webkit-border-radius: 10px;
			-moz-border-radius: 10px;
			border-radius: 10px;
			padding:10px;
			border: 1px solid #99779;
			border: inset 0px solid #333;
			-webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
			-moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
			box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3)
		}
		#site_content
		{
			padding: 0px;
			width: 1200px;
			height:700px;
			overflow: hidden;
			margin:80px auto;
			text-align:left;
			background:#ccc url(../image/mainback.jpg) repeat;
			border:2px solid green;
		}
	</style>
</head>
<?php
include ("sidebar.php");
?>
	<div id="content"
	<div class="content_item">
	<b>
	<div id="contact" class="body">
		<form>
		<?php
		$userna=$_SESSION['login_party'];
		$localhost="localhost";
		$dbuser="root";
		$dbpass="";
		$dbname="ovs";
		$con=mysql_connect($localhost,$dbuser,$dbpass);
		if(!$con)
		{ die("Coudn't connect to the server");
		}
		$db_select=mysql_select_db($dbname,$con);
		if(!$db_select)
		{
			die("db is not selected".mysql_error());
		}
  $email=$_POST['email'];
  $pho=$_POST['pho_num'];
 $use=$_POST['User_name'];
$olppass=md5($_POST['oldpassword']);
$newpass=md5($_POST['password']);
$sql="select *from party where user_name='$userna'";
$result=mysql_query($sql);
while ($row=mysql_fetch_row($result))
{
	/*if($row[16]!=$olppass)
	{
		echo '<font size="4pt" color="red">Wrong old password</font>';
		incorrectpass();
	}
	else{*/
		$sq="update party set email='$email',phone_number='$pho',user_name='$use',password='$newpass' where party_name='$row[0]'";
		if(!mysql_query($sq))
		{
			die("Edit profile Error".mysql_error());
		}
		echo'<font color="blue" size="5pt"> Change Saved</font>';
}
function incorrectpass()
{
	$userna = $_SESSION['login_party'];
	echo '<font size="4pt" color="red">Wrong old password</font>';
	$localhost = "localhost";
	$dbuser = "root";
	$dbpass = "";
	$dbname = "ovs";
	$con = mysql_connect($localhost, $dbuser, $dbpass);
	if (!$con) {
		die("Coudn't connect to the server");
	}
	$db_select = mysql_select_db($dbname, $con);
	if (!$db_select) {
		die("db is not selected" . mysql_error());
	}
	$sql = "select *from party where user_name='$userna' ";
	$result = mysql_query($sql);
	while ($row = mysql_fetch_row($result)) {
		echo '
	<form name = "PartForm"  enctype="multipart/form-data" action ="editprofilechange.php" method="POST" onsubmit = "return validateParRegisterForm(this.form);">
	<fieldset>
	<legend align="center"><font color="blue" size="5pt"><legend>EDIT PROFILE</font></legend>
		<table >
			<tbody  >
			<tr>
				<td align ="center">E-mail:</td>
				<td><input id = "email" name="email"  class = "contactFormInput" type="text" value="' . $row[13] . '" class="txtfield" placeholder = "' . $row[13] . '"  onblur = "validaterepemail()" required></td>
				<td><label id = "emilPrompt"> </label></td>
			</tr>
			<tr>
				<td align ="center">Phone_number:</td>
				<td><input id = "pho_num"  name = "pho_num" class = "contactFormInput" type="text" value="' . $row[14] . '" class="txtfield" placeholder = "' . $row[14] . '"  onblur = " validaterepone()" required></td>
				<td><label id = "phonePrompt"> </label></td>
			</tr>
			<tr>
				<td align ="center">User Name:</td>
				<td><input id = "User_name" name="user_name" class = "contactFormInput" value="' . $row[15] . '" type="text" class="txtfield" placeholder = "' . $row[15] . '" onblur = " validateUsername()" required></td>
				<td><label id = "UserNamePrompt"></label> </td>
			</tr>
			<tr>
				<td align ="center">Current Password:</td>
				<td><input id = "oldpassword" name = "oldpassword" class = "contactFormInput" type="password" class="txtfield" placeholder = "enter Password" required></td>
			</tr>
			<tr>
				<td align ="center">New Password:</td>
				<td><input id = "password" name = "password" class = "contactFormInput" type="password" class="txtfield" placeholder = "enter Password" onblur = "validatePassword()"required></td>
				<td><label id = "PasswordPrompt"></label> </td>
			</tr>
			<tr>
				<td align ="center">Re  type new password:</td>
				<td><input id = "re_pasword" name = "re_pasword"  class = "contactFormInput" type="password" class="txtfield" placeholder = "re enter password" onblur = "validateRePassword()"required></td>
				<td><label id = "re_passowrdPrompt"></label> </td>
			</tr>
			<tr>
				<td></td>
				<td align="center"><button type = "submit" id="se" ><strong> Save Change </strong></button> </td>
				<td><button type = "reset" onclick = "" ><strong> CLEAR </strong></button> </td>
			</tr>
			</tbody>
		</table>
		</fieldset></form>';
	}
}
mysql_close($con);
?>
			</form>
	</div>
	</div>
</div>
</div>
<?php
include ("../footer.php");
?>
</body>
</html>
