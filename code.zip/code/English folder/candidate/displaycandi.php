<?php
/**
 * Created by PhpStorm.
 * User: alexo
 * Date: 5/27/2016
 * Time: 12:53 AM
 */
session_start();
include ("candheader.php");
include ('sidebar.php');
?>
    <div id="content">
    <div id="contact" class="body">
        <form name = "CandidateForm">
<?php
$use=$_SESSION['login_cand'];
$localhost="localhost";
$dbuser="root";
$dbpass="";
$dbname="ovs";
$con=mysql_connect($localhost,$dbuser,$dbpass);
if(!$con)
{ die("Coudn't connect to the server");
}
$db_select=mysql_select_db($dbname,$con);
if(!$db_select)
{
    die("db is not selected".mysql_error());
}
$sql="select *from cand WHERE  user_name='$use'";
$res=mysql_query($sql);
while ($row=mysql_fetch_row($res))
{
    $wore=$row[12];
}
echo '<font size="5pt" color="green">computent partys and thier candidates in'.$wore.'  election zone</font>';
$sel="select *from cand where woreda='$wore' AND status=1 ";
$result=mysql_query($sel);
echo '<table border="green">';
echo'<th>Candidate name</th>
     <th> Party name</th>
     <th>party symbol</th>
     <th> candidate photo</th>';
while($ro=mysql_fetch_row($result)) {
    $sol = "select *from party WHERE 	party_name='$ro[1]'";
    $ru = mysql_query($sol);
    if(!($ru))
    {
       echo"error".mysql_error();
    }
    while ($th = mysql_fetch_array($ru))
    {
        $ph=$th[3];
    }
    echo'<tr><td>'.$ro[2].'</td>';
    echo'<td>'.$ro[1].'</td>';
    echo'<td><img src=" data:image;base64,'. $ph.'" height="130" width="130" alt="file not found" /></td>';
    echo'<td><img src=" data:image;base64,'. $ro[3].'" height="130" width="130" alt="file not found" /></td></tr>';


}
echo '</table>';
mysql_close($con);
?>
            </form>
    </div>
    </div>
</div>
</div>
<?php
include ("../footer.php");
?>
</body>
</html>

