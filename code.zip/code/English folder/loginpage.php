<!DOCTYPE html>
<html lang="en">
  <head>
	  <?php
	  session_start();
	  include ("headerfile.php");
	  ?>
      <script type="text/javascript" src="js/login.js"></script>
 <STYLE TYPE="text/css">
 #contact form {
	background: #ccc url(../image/mainback.jpg) repeat;
margin:auto;
position:relative;
width:620px;
height:230px;
font-family: ;
font-size: 14px;
font-style: italic;
line-height: 24px;
font-weight: ;
color: black;
text-decoration: none;
-webkit-border-radius: 10px;
-moz-border-radius: 10px;
border-radius: 10px;
padding:10px;
border: 1px solid #99779;
border: inset 0px solid #333;
-webkit-box-shadow: 0px 0px 20px rgba(0, 0, 0, 1.9);
-moz-box-shadow: 0px 0px 28px rgba(0, 0, 0, 1.9);
box-shadow: 0px 0px 28px rgba(0, 0, 0, 1.9)
}
#site_content
{ 
    padding: 0px;
	width: 1300px;
	height:600px;
	overflow: hidden;
	margin:10px auto;
	text-align:left;
	background:#ccc url(../image/mainback.jpg) repeat;
	border:5px solid green;
}
</style>
  </head>
  <body>
<div id="site_content">	
<div class="sidebar_container1">       
	<div class="sidebar">
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of ETHIOPIA</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of democracy</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of election</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">Past Election in Ethiopia</a></span>
	</div>
	</div>
<div id="content">
<div class="content_item">
<div id="contact" class="body">
<?php
$localhost="localhost";
$dbuser="root";
$dbpass="";
$dbname="ovs";
$con=mysql_connect($localhost,$dbuser,$dbpass);
if(!$con)
{ die("Coudn't connect to the server");
}
$db_select=mysql_select_db($dbname,$con);
if(!$db_select)
{
die("db is not selected".mysql_error());
}
if(isset($_POST['log']))
{
$acoutype=$_POST['type'];
$user_name=$_POST['user_name'];
$password=md5($_POST['pass']);
if($acoutype=="0")
{
?><form name = "loginform" action ="loginpage.php" method="POST" onsubmit = "return login(this.form);">
<table>
								 <tr >
								 <td rowspan=3><img src="image/kkk.gif" height="130px" width="100px"/></td>
								 <td align="center">Login As</td>
								 <td><select id="type" class = "contactFormInput"  name = "type" value = "" onchange="validateAccounttype(this.options[this.selectedIndex].value);">
								         <option value = "0"selected = "selected">-select your account type-</option>
										 <option value="1" >Election Officer</option>
										 <option value="2" >Party</option>
										 <option value="3" >candidate</option>
										 <option value="4" >Voter</option>
										 </select>
										 </td>
										 <td><label id = "typeprompt"></label> </td>
										</tr>
										
										<tr>
								  <td align="center">user name</td>
								  <td><input type="text" id="user_name" name="user_name" class="contactFormInput"class="txtfield"  required></td>
								  </tr>
								 <tr><td align="center"> Password:</td>
								 <td><input type="password" id ="pass"  name ="pass" class="contactFormInput" class="txtfield" required> </td></tr>
								  <tr><td>
								  </td><td align="right"><button type="submit" name="log" id="log"><font color="blue" size="4pt">LOGIN</font></td></tr>
								  <tr>
								  <td>
								  </td>
								  <td align="center">
										<font color="red">
										please select account type
										</font>
										</td>
										</tr>
										</table>   </form>
<?php
}
	function retry()
	{

		echo'<form name = "RegistrationForm" action ="loginpage.php" method="POST" onsubmit = "return login(this.form);">
                           <table>
								 <tr >
								 <td rowspan=3><img src="image/kkk.gif" height="100px" width="130px"/></td>
								 <td align="center">Login As</td>
								 <td><select id="type" class = "contactFormInput"  name = "type" value = "" onchange="validateAccounttype(this.options[this.selectedIndex].value);">
								         <option value = "0"selected = "selected">-select your account type-</option>
										 <option value="1" >Election Officer</option>
										 <option value="2" >Party</option>
										 <option value="3" >candidate</option>
										 <option value="4" >Voter</option>
										 </select>
										 </td>
										 <td><label id = "typeprompt"></label> </td>
										</tr>
										
										<tr>
								  <td align="center">user name</td>
								  <td><input type="text" id="user_name" name="user_name" class="contactFormInput"class="txtfield"  required></td></tr>
								 <tr><td align="center"> Password:</td>
								 <td><input type="password" id ="pass"  name ="pass" class="contactFormInput" class="txtfield" required> </td></tr>
								  <tr><td>
								  </td><td align="right"><button type="submit" id="log" name="log" ><font color="blue" size="4pt">LOGIN</font></td></tr>
								  <tr>
								  <td>
								  </td>
								  <td align="right">
								 <font color="red">Wrong user Name or Password
	                                  </font>
										</td>
										</tr>
										</table></form>';
	}
 if($acoutype=="1")
{
if(!(mysql_num_rows(mysql_query("SELECT * FROM election_officer where username='$user_name' AND password='$password'"))))
{
	retry();
}
   else
   {
   $qry="SELECT * FROM election_officer where username='$user_name' AND password='$password'";
  $result=mysql_query($qry);
   while($row=mysql_fetch_array($result))
   {
$_SESSION['login_EO']=$user_name;
setcookie("user", $user_name, strtotime(
	'+30 days' ), "/", "", "", TRUE);
		   ?>
	<script language="javascript">
		window.location="ECA/HOME.php";
	</script>
		<?php

		}
		
        }
  }
if($acoutype=="2")
{
if(!(mysql_num_rows(mysql_query("SELECT * FROM party where user_name='$user_name'AND password='$password'"))))
{
	echo'error'.mysql_error();
retry();
 }
   else
   {
   $qry="SELECT * FROM party where user_name='$user_name'AND password='$password'";
  $result=mysql_query($qry);
	   while($row=mysql_fetch_array($result))
	   {
		$_SESSION['login_party']=$user_name;
		setcookie("user", $user_name, strtotime(
			'+30 days' ), "/", "", "", TRUE);
			?>
			   <script language="javascript">
			   window.location="party/homepage.php";
	</script>
			   <?php
	   }
		
        }
	}
 if($acoutype=="3")
{
if(!(mysql_num_rows(mysql_query("SELECT * FROM cand where user_name='$user_name' AND password='$password'"))))
  {
 retry();
  }
   else
   {
   $qry="SELECT * FROM cand where user_name='$user_name'AND password='$password'";
  $result=mysql_query($qry);
	   while($row=mysql_fetch_array($result))
	   {
			   $_SESSION['login_cand']=$user_name;
			   setcookie("user", $user_name, strtotime(
				   '+30 days' ), "/", "", "", TRUE);
			   ?>
	<script language="javascript">
		window.location="candidate/homepage.php";
	</script>
	<?php
	   }
		
        }
	}
 if($acoutype=="4")
	{
	if(!(mysql_num_rows(mysql_query("SELECT * FROM voters where user_name='$user_name'AND password='$password'"))))
  {
 retry();
			 }
      else
        {
		   $qry="SELECT * FROM voters where user_name='$user_name' AND password='$password'";
		  $result=mysql_query($qry);
			while($row=mysql_fetch_array($result))
			{
					$_SESSION['login_voter']=$user_name;
					setcookie("user", $user_name, strtotime(
						'+30 days' ), "/", "", "", TRUE);
					?>
	<script language="javascript">
		window.location="voter/HOME.php";
	</script>
	<?php
			}
		
       }
	}
}
		 mysql_close($con);
 ?>

				</div>
			</div>
			</div>
	</div>
	</div>

<div id="footer_container">
    <div id="footer">
	<p>
				&copy 2016 by TEGBARU,ALEHEGN,TEWABE AND YIDEG. All Rights Reserved !!!
		</p>
	
    </div>
</div>  
  </body>
</html>