function validateP_Name(){
	var pname = document.getElementById("p_Name").value;
	if(pname.length == 0){
		jsShow("PNamePrompt");
		producePrompt("Please party Name?  ", "PNamePrompt", "red");
		return false;
		
	}
	var nameexp =/^[a-zA-Z&/\s-, ]+$/;
	if(!pname.match(nameexp)){
		jsShow("PNamePrompt");
		producePrompt("please enter correct party name ", "PNamePrompt", "orange");
		return false;
	}
	jsShow("PNamePrompt");
	producePrompt("yes   ", "PNamePrompt", "green");
	setTimeout(function(){jsHide("PNamePrompt");}, 2000);
		return true;
}
function validatesympnmae()
{
var pname = document.getElementById("sym_name").value;
	if(pname.length == 0){
		jsShow("symbnameprompt");
		producePrompt("Please symbol Name?  ", "symbnameprompt", "red");
		return false;
		
	}
	var nameexp =/^[a-zA-Z\s-, ]+$/;
	if(!pname.match(nameexp)){
		jsShow("symbnameprompt");
		producePrompt("please enter correct symbol name ", "symbnameprompt", "orange");
		return false;
	}
	jsShow("symbnameprompt");
	producePrompt("yes   ", "symbnameprompt", "green");
	setTimeout(function(){jsHide("symbnameprompt");}, 2000);
		return true;
}
function validateP_code()
{
var pname = document.getElementById("party_identity").value;
	if(pname.length == 0){
		jsShow("Party_codePrompt");
		producePrompt("Please party name abrivation if any ?  ", "Party_codePrompt", "red");
		return false;
		
	}
	var nameexp =/^[a-zA-Z0-9\/]+$/;
	if(!pname.match(nameexp)){
		jsShow("Party_codePrompt");
		producePrompt("incorrect ", "Party_codePrompt", "orange");
		return false;
	}
	jsShow("Party_codePrompt");
	producePrompt("J!   " + pname, "Party_codePrompt", "green");
	setTimeout(function(){jsHide("Party_codePrompt");}, 2000);
		return true;
}
 function validateName(){
	var cname = document.getElementById("party_rep_name").value;
	if(cname.length == 0){
		jsShow("repnamePrompt");
		producePrompt("Please representative full Name?  ", "repnamePrompt", "red");
		return false;
		
	}
	var nameexp = /^[a-zA-Z/\s-, ]+$/;
	if(!cname.match(nameexp)){
		jsShow("repnamePrompt");
		producePrompt(" please enter correct representative full name ", "repnamePrompt", "orange");
		return false;
	}
	jsShow("repnamePrompt");
	producePrompt("representative name  " + cname, "repnamePrompt", "green");
	setTimeout(function(){jsHide("repnamePrompt");}, 2000);
		return true;	
}
function validate_ssn()
{
var pname = document.getElementById("rep_ssn").value;
	if(pname.length == 0){
		jsShow("ssnPrompt");
		producePrompt("Please SSN?  ", "ssnPrompt", "red");
		return false;
		
	}
	var nameexp =/^[a-zA-Z0-9\/]+$/;
	if(!pname.match(nameexp)){
		jsShow("ssnPrompt");
		producePrompt("please enter correct SSN ", "ssnPrompt", "orange");
		return false;
	}
	jsShow("ssnPrompt");
	producePrompt("ok!   " + pname, "ssnPrompt", "green");
	setTimeout(function(){jsHide("ssnPrompt");}, 2000);
		return true;	
}
function validatecanage(x)
{
	var cage=parseInt(x);
	if(cage<21)
	{
	 jsShow("canagePrompt");
		producePrompt("age must be greater than 20?  ", "canagePrompt", "red");	
		return false;
	}
	jsShow("canagePrompt");
	producePrompt("ok !rep age is  " + cage, "canagePrompt", "green");
	setTimeout(function(){jsHide("canagePrompt");}, 2000);
		return true;
}
function validateprofession(x){
	if(x == "0"){
		jsShow("canproPrompt");
		producePrompt("Please rep proffision?  ", "canproPrompt", "red");
		return false;
		
	}
	jsShow("canproPrompt");
	producePrompt("proffesion is   " + x, "canproPrompt", "green");
	setTimeout(function(){jsHide("canproPrompt");}, 2000);
		return true;
		
}
function validateNationality(x)
{
	if(x=="0")
	{
		jsShow("nationpropmt");
		producePrompt("please select country  ", "nationpropmt", "orange");
		return false;
	}
	if(x!="Ethiopia")
	{
		jsShow("nationpropmt");
		producePrompt("representative must be Ethiopian  ", "nationpropmt", "orange");
		return false;
	}
	jsShow("nationpropmt");
	producePrompt(" correct", "nationpropmt", "green");
	setTimeout(function(){jsHide("nationpropmt");}, 2000);
		return true;
}
function validateRegion(x)
{
	if(x=="0")
	{
		jsShow("canregionPrompt");
		producePrompt("please select region ", "canregionPrompt", "orange");
		return false;
	}
	
	jsShow("canregionPromp");
	producePrompt("correct", "canregionPromp", "orange");
	setTimeout(function(){jsHide("canregionPromp");}, 2000);
		return true;
}
function validatezone(x)
{
	if(x=="-1"){
		jsShow("canzonePrompt");
		producePrompt("Please select  zone?  ", "canzonePrompt", "red");
		return false;
		
	}
	jsShow("canproPrompt");
	producePrompt("ok!   ", "canzonePrompt", "green");
	setTimeout(function(){jsHide("canzonePrompt");}, 2000);
		return true;
}
function validateWoreda(x)
{
	if(x == "-1"){
		jsShow("canwereaPrompt");
		producePrompt("Please select  woreda?  ", "canwereaPrompt", "red");
		return false;
		
	}
	jsShow("canwereaPrompt");
	producePrompt("ok !   ", "canwereaPrompt", "green");
	setTimeout(function(){jsHide("canwereaPrompt");}, 2000);
		return true;
}
function validaterepemail()
{
	var caemail = document.getElementById("email").value;
	
	if(caemail.length == 0){
		jsShow("caemilPrompt");
		producePrompt("Valid Email Please? ", "caemilPrompt", "red");
		return false;
		
	}
	var emailexp =  /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,7})+$/;
	if(!caemail.match(emailexp)){
		jsShow("caemilPrompt");
		producePrompt("Invalid Email Address ", "caemilPrompt", "orange");
		return false;
	}
	jsShow("caemilPrompt");
	producePrompt("Valid Email Address " + caemail, "caemilPrompt", "green");
	setTimeout(function(){jsHide("caemilPrompt");}, 2000);
		return frue;
}
function validaterepone()
{
var phone = document.getElementById("pho_num").value;
	var phoexp=/^\+\d{3}-\d{9}$/
	if(!phone.match(phoexp))
	{
		jsShow("phonePrompt");
		producePrompt("Enter Phone Number as +251-9####### ", "phonePrompt", "blue");
		return false;
	}
	if(phone.length == 14){
	jsShow("phonePrompt");
	producePrompt("well done " + phone, "phonePrompt", "green");
	setTimeout(function(){jsHide("phonePrompt");}, 4000);
		return true;
	}	
	
		jsShow("phonePrompt");
		producePrompt("Enter Phone Number as +251-9#######  ", "phonePrompt", "orange");
		return false;
}
function isNumeric(n) {
  return !isNaN(parseFloat(n)) && isFinite(n);
}
function validateUsername()
{
	var A_name = document.getElementById("User_name").value;
	if(A_name.length == 0){
		jsShow("UserNamePrompt");
		producePrompt("Please user Name?", "UserNamePrompt", "red");
		return false;
		
	}
	var A_nameexp = /^([a-zA-Z0-9_\.\-])+[A-Za-z0-9]+$/;
	if(!A_name.match(A_nameexp)){
		jsShow("UserNamePrompt");
		producePrompt("Invalid user Name", "UserNamePrompt", "orange");
		return false;
	}
	if(A_name.length <= 3||A_name.length >= 20){
		jsShow("UserNamePrompt");
		producePrompt("user name must between at least 3 and 20 char", "UserNamePrompt", "orange");
		return false;
		
	}
	var y=A_name[0];
	if(isNumeric(y)){
		jsShow("UserNamePrompt");
		producePrompt("User name can not start with number", "UserNamePrompt", "orange");
		return false;
		
	}
	jsShow("UserNamePrompt");
	producePrompt("welcome  " + A_name, "UserNamePrompt", "green");
	setTimeout(function(){jsHide("UserNamePrompt");}, 2000);
		return true;
}
function validatePassword()
{
	var pass=document.getElementById("password").value;
	var x=pass.length;
	if(x == 0){
		jsShow("PasswordPrompt");
		producePrompt("Password please?    ", "PasswordPrompt", "red");
		return false;
		
	}
	if(x<=5){
		jsShow("PasswordPrompt");
		producePrompt(" Weak !   ", "PasswordPrompt", "orange");
		return true;
		}
	jsShow("PasswordPrompt");
	producePrompt("good " , "PasswordPrompt", "green");
	setTimeout(function(){jsHide("PasswordPrompt");}, 2000);
		return true;
}
function validateRePassword(){
	var RPassword = document.getElementById("re_pasword").value;
	var pass=document.getElementById("password").value;
	var x=RPassword.length;
	if( x == 0){
		jsShow("re_passowrdPrompt");
		producePrompt("Retype Password ", "re_passowrdPrompt", "red");
		return false;
		
	}
	
	if(pass ==RPassword){
		jsShow("re_passowrdPrompt");
	producePrompt("mached" , "re_passowrdPrompt", "green");	
	setTimeout(function(){jsHide("re_passowrdPrompt");}, 4000);
	return true;	
	}
	jsShow("re_passowrdPrompt");
	producePrompt("password not match" , "re_passowrdPrompt", "red");	
	return false;	
}
function validateParRegisterForm(form)
{
var ag = document.getElementById("ca_age");
var agval = ag.options[ag.selectedIndex].value;
var co = document.getElementById("Nationality");
var coval = co.options[co.selectedIndex].value;
var re = document.getElementById("region");
var reval = re.options[re.selectedIndex].value;
var z = document.getElementById("zone");
var zval = z.options[z.selectedIndex].value;
var w = document.getElementById("woreda");
var wva = w.options[w.selectedIndex].value;
var pro=document.getElementById("party_rep_pro");
var proval=pro.options[pro.selectedIndex].value;
if(!(validateP_Name()))
{
  jsShow("suc");
	producePrompt("Incorrect party Name" , "suc", "red");
	return false;
}
if(!(validateP_code()))
{
  jsShow("suc");
	producePrompt("Incorrect party name abrivation " , "suc", "red");
	return false;
}
if(!(validateName()))
{
jsShow("suc");
	producePrompt("Incorrect reperesentative name" , "suc", "red");
	return false;
}
if(!(validateprofession(proval)))
{
jsShow("suc");
	producePrompt("you are not select Proffesion" , "suc", "red");
	return false;
}
if(!(validate_ssn()))
{
jsShow("suc");
	producePrompt("Incorrect SSN" , "suc", "red");
	return false;
}
if(!(validatecanage(agval)))
{
jsShow("suc");
	producePrompt("Incorrect age" , "suc", "red");
	return false;
}
if(!(validateNationality(coval)))
{
jsShow("suc");
	producePrompt("you are not select Country" , "suc", "red");
	return false;
}
if(!(validateRegion(reval)))
{
jsShow("suc");
	producePrompt("you are not select Region" , "suc", "red");
	return false;
}
if(!(validatezone(zval)))
{
jsShow("suc");
	producePrompt("you are not select zone" , "suc", "red");
	return false;
}
if(!(validateWoreda(wva)))
{
jsShow("suc");
	producePrompt("you are not select woreda" , "suc", "red");
	return false;
}
if(!(validatecanemail()))
{
jsShow("suc");
	producePrompt("invalid E_mail" , "suc", "red");
	return false;
}
if(!(validatereppone()))
{
jsShow("suc");
	producePrompt("Incorrect phone number" , "suc", "red");
	return false;
}
if(!(validateUsername()))
{
jsShow("suc");
	producePrompt("Invalid user name" , "suc", "red");
	return false;
}
if(!(validatePassword()))
{
jsShow("suc");
	producePrompt("Password not Entered" , "suc", "red");
	return false;
}
if(!(validateRePassword()))
{
  jsShow("suc");
	producePrompt("password doesn't match" , "suc", "red");
	return false;
}
return true;
}
function jsShow(id){
	document.getElementById(id).style.display = "block";
}

function jsHide(id){
	document.getElementById(id).style.display = "none";
}


function producePrompt(message, promptLocation, color){
	document.getElementById(promptLocation).innerHTML = message;
	document.getElementById(promptLocation).style.color = color;
}