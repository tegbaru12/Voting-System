 function validatefname(){
	var fname = document.getElementById("F_Name").value;
	if(fname.length == 0){
		jsShow("F_NamePrompt");
		producePrompt("Please first  Name?  ", "F_NamePrompt", "red");
		return false;
		
	}
	var nameexp =/^[a-zA-Z]+$/;
	if(!fname.match(nameexp)){
		jsShow("F_NamePrompt");
		producePrompt("name must be alphabet ", "F_NamePrompt", "orange");
		return false;
	}
	jsShow("F_NamePrompt");
	producePrompt("ok!  " + fname, "F_NamePrompt", "green");
	setTimeout(function(){jsHide("F_NamePrompt");}, 2000);
		return true;
}
 function validatelname(){
	var lname = document.getElementById("La_Name").value;
	if(lname.length == 0){
		jsShow("L_NamePrompt");
		producePrompt("Please last  Name?  ", "L_NamePrompt", "red");
		return false;
		
	}
	var nameexp =/^[a-zA-Z]+$/;
	if(!lname.match(nameexp)){
		jsShow("L_NamePrompt");
		producePrompt("name must be alphabet ", "L_NamePrompt", "orange");
		return false;
	}
	jsShow("L_NamePrompt");
	producePrompt("ok !    " + lname, "L_NamePrompt", "green");
	setTimeout(function(){jsHide("L_NamePrompt");}, 2000);
		return true;
}
 function validatemName(){
	var cname = document.getElementById("Mother_Name").value;
	if(cname.length == 0){
		jsShow("M_NamePrompt");
		producePrompt("Please your mother full Name?  ", "M_NamePrompt", "red");
		return false;
		
	}
	var nameexp = /^[a-zA-Z/\s-, ]+$/;
	if(!cname.match(nameexp)){
		jsShow("M_NamePrompt");
		producePrompt(" please enter correct full name ", "M_NamePrompt", "orange");
		return false;
	}
	jsShow("M_NamePrompt");
	producePrompt("ok  " + cname, "M_NamePrompt", "green");
	setTimeout(function(){jsHide("M_NamePrompt");}, 2000);
		return true;
		
}
function validate_ssn()
{
var pname = document.getElementById("ssn").value;
	if(pname.length == 0){
		jsShow("ssnPrompt");
		producePrompt("Please SSN?  ", "ssnPrompt", "red");
		return false;
		
	}
	var nameexp =/^[a-zA-Z0-9\/]+$/;
	if(!pname.match(nameexp)){
		jsShow("ssnPrompt");
		producePrompt("please enter correct SSN ", "ssnPrompt", "orange");
		return false;
	}
	jsShow("ssnPrompt");
	producePrompt("ok!   " + pname, "ssnPrompt", "green");
	setTimeout(function(){jsHide("ssnPrompt");}, 2000);
		return true;	
}
function validatecanage(x)
{
	var cage=parseInt(x);
	if(cage<18)
	{
	 jsShow("agePrompt");
		producePrompt("you can not vote?  ", "agePrompt", "red");	
		return false;
	}
	jsShow("agePrompt");
	producePrompt("ok ! voter age is  " + cage, "agePrompt", "green");
	setTimeout(function(){jsHide("agePrompt");}, 2000);
		return true;
}
function isNumeric(n) {
  return !isNaN(parseFloat(n)) && isFinite(n);
}
function validateNationality(x)
{
	if(x=="0")
	{
		jsShow("nationpropmt");
		producePrompt("please select country  ", "nationpropmt", "orange");
		return false;
	}
	if(x!="Ethiopia")
	{
		jsShow("nationpropmt");
		producePrompt("voter must be Ethiopian  ", "nationpropmt", "orange");
		return false;
	}
	jsShow("nationpropmt");
	producePrompt(" correct", "nationpropmt", "green");
	setTimeout(function(){jsHide("nationpropmt");}, 2000);
		return true;
}
function validateRegion(x)
{
	if(x=="0")
	{
		jsShow("canregionPrompt");
		producePrompt("please select country  ", "canregionPrompt", "orange");
		return false;
	}
	jsShow("canregionPrompt");
	producePrompt(" correct", "canregionPrompt", "green");
	setTimeout(function(){jsHide("canregionPrompt");}, 2000);
	return true;
}
function validatezone(x)
{
	if(x=="-1"){
		jsShow("canzonePrompt");
		producePrompt("Please select voter zone?  ", "canzonePrompt", "red");
		return false;
		
	}
	jsShow("canproPrompt");
	producePrompt("ok!   ", "canzonePrompt", "green");
	setTimeout(function(){jsHide("canzonePrompt");}, 2000);
		return true;
}
function validateWoreda(x)
{
	if(x == "-1"){
		jsShow("canwereaPrompt");
		producePrompt("Please select voter woreda?  ", "canwereaPrompt", "red");
		return false;
		
	}
	jsShow("canwereaPrompt");
	producePrompt("OK !   ", "canwereaPrompt", "green");
	setTimeout(function(){jsHide("canwereaPrompt");}, 2000);
		return true;
}
function validateUsername()
{
	var A_name = document.getElementById("User_name").value;
	if(A_name.length == 0){
		jsShow("UserNamePrompt");
		producePrompt("Please user Name?", "UserNamePrompt", "red");
		return false;
		
	}
	var A_nameexp = /^([a-zA-Z0-9_\.\-])+[A-Za-z0-9]+$/;
	if(!A_name.match(A_nameexp)){
		jsShow("UserNamePrompt");
		producePrompt("Invalid user Name", "UserNamePrompt", "orange");
		return false;
	}
	if(A_name.length <= 3||A_name.length >= 20){
		jsShow("UserNamePrompt");
		producePrompt("user name must between at least 3 and 20 char", "UserNamePrompt", "orange");
		return false;
		
	}
	jsShow("UserNamePrompt");
	producePrompt("welcome  " + A_name, "UserNamePrompt", "green");
	setTimeout(function(){jsHide("UserNamePrompt");}, 2000);
		return true;
}
function validatePassword()
{
	var pass=document.getElementById("password").value;
	var x=pass.length;
	if(x == 0){
		jsShow("PasswordPrompt");
		producePrompt("Password please?    ", "PasswordPrompt", "red");
		return false;
		
	}
	if(x<=5){
		jsShow("PasswordPrompt");
		producePrompt(" Weak !   ", "PasswordPrompt", "orange");
		return true;
		}
	jsShow("PasswordPrompt");
	producePrompt("good " , "PasswordPrompt", "green");
	setTimeout(function(){jsHide("PasswordPrompt");}, 2000);
		return true;
}
function validateRePassword(){
	var RPassword = document.getElementById("re_pasword").value;
	var pass=document.getElementById("password").value;
	var x=RPassword.length;
	if( x == 0){
		jsShow("re_passowrdPrompt");
		producePrompt("Retype Password ", "re_passowrdPrompt", "red");
		return false;
		
	}
	
	if(pass ==RPassword){
		jsShow("re_passowrdPrompt");
	producePrompt("mached" , "re_passowrdPrompt", "green");	
	setTimeout(function(){jsHide("re_passowrdPrompt");}, 4000);
	return true;	
	}
	jsShow("re_passowrdPrompt");
	producePrompt("password not match" , "re_passowrdPrompt", "red");
    document.getElementById("re_pasword").focus=false;	
	return false;	
}
function validateForm(form)
{
var ag = document.getElementById("ca_age");
var agval = ag.options[ag.selectedIndex].value;
var co = document.getElementById("Nationality");
var coval = co.options[co.selectedIndex].value;
var re = document.getElementById("region");
var reval = re.options[re.selectedIndex].value;
var z = document.getElementById("zone");
var zval = z.options[z.selectedIndex].value;
var w = document.getElementById("woreda");
var wva = w.options[w.selectedIndex].value;

if( !(validatecanage(agval)))
{
jsShow("suc");
producePrompt("Incorrect age " , "suc", "red");
return false;
}
if(!(validateNationality(coval)))
{
jsShow("suc");
producePrompt("country doesn't selected " , "suc", "red");
return false;
}
if(!(validateRegion(reval)))
{
jsShow("suc");
producePrompt("region doesn't selected " , "suc", "red");
return false;
}
if(!(validatezone(zval)))
{
jsShow("suc");
producePrompt("zone doesn't selected " , "suc", "red");
return false;
}
if(!(validateWoreda(wva)))
{
jsShow("suc");
producePrompt("woreda doesn't selected " , "suc", "red");
return false;
}
if(!(validatefname()))
{
jsShow("suc");
producePrompt("Incorrect first name " , "suc", "red");
return false;
}
if(!(validatelname()))
{jsShow("suc");
producePrompt("Incorrect last name " , "suc", "red");
return false;
}
if(!(validatemName()))
{
jsShow("suc");
producePrompt("Incorrect Mother name  " , "suc", "red");
return false;
}
if(!(validate_ssn()))
{
jsShow("suc");
producePrompt("SSN not correct " , "suc", "red");
return false;
}
if(!(validateUsername()))
{
jsShow("suc");
producePrompt("user name nor correct" , "suc", "red");
return false;
}
if(!(validatePassword()))
{
jsShow("suc");
producePrompt("password not entered" , "suc", "red");
return false;
}
if(!(validateRePassword()))
{
jsShow("suc");
producePrompt("password not matched  " , "suc", "red");
return false;
}
	return true;
}
function jsShow(id){
	document.getElementById(id).style.display = "block";
}

function jsHide(id){
	document.getElementById(id).style.display = "none";
}
function producePrompt(message, promptLocation, color){
	document.getElementById(promptLocation).innerHTML = message;
	document.getElementById(promptLocation).style.color = color;
}