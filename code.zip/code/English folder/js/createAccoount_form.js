function validateName()
{
	var ename = document.getElementById("Name").value;
	if(ename.length == 0)
	{
		jsShow("NamePrompt");
		producePrompt("Please  full Name?  ", "NamePrompt", "red");
		return false;
		
	}
	var nameexp = /^[A-Za-z]+\s{1}[A-Za-z]+$/;
	if(!ename.match(nameexp)){
		jsShow("NamePrompt");
		producePrompt(" please enter correct  full name ", "NamePrompt", "orange");
		return false;
	}
	jsShow("NamePrompt");
	producePrompt(" correct !  " + ename, "NamePrompt", "green");
	setTimeout(function(){jsHide("NamePrompt");}, 2000);
		return true;	
}
function validateidentity()
{
var ename = document.getElementById("eoid").value;
	if(ename.length == 0){
		jsShow("eoidPrompt");
		producePrompt("Please enter election officer SSN?  ", "eoidPrompt", "red");
		return false;
		
	}
	var nameexp =/^[a-zA-Z\/0-9]+$/;
	if(!ename.match(nameexp)){
		jsShow("eoidPrompt");
		producePrompt("please enter correct EO SSN ", "eoidPrompt", "orange");
		return false;
	}
	jsShow("eoidPrompt");
	producePrompt("ok!   " + ename, "eoidPrompt", "green");
	setTimeout(function(){jsHide("eoidPrompt");}, 2000);
		return true;	
}
function validateEoage(x)
{
	var age=parseInt(x);
	if(age<21)
	{
	 jsShow("canagePrompt");
		producePrompt("X !age must be greater than 20?  ", "canagePrompt", "red");	
		return false;
	}
	jsShow("canagePrompt");
	producePrompt("correct " + age, "canagePrompt", "green");
	setTimeout(function(){jsHide("canagePrompt");}, 2000);
		return true;
}
function validateemail()
{
	var eemail = document.getElementById("email").value;
	if(eemail.length == 0){
		jsShow("emilPrompt");
		producePrompt("Valid Email Please? ", "emilPrompt", "red");
		return false;
		
	}
	var emailexp = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if(!eemail.match(emailexp)){
		jsShow("emilPrompt");
		producePrompt("Invalid Email Address ", "emilPrompt", "orange");
		return false;
	}
	jsShow("emilPrompt");
	producePrompt("Valid Email Address " + eemail, "emilPrompt", "green");
	setTimeout(function(){jsHide("emilPrompt");}, 2000);
		return frue;
}
function validatephone()
{
var phone = document.getElementById("pho_num").value;
	var phoexp=/^\+\d{3}-\d{9}$/;
	if(!phone.match(phoexp))
	{
		jsShow("phonePrompt");
		producePrompt("X ! Enter like +###-######## ", "phonePrompt", "red");
		return false;
	}
	if(phone.length == 14){
	jsShow("phonePrompt");
	producePrompt("well done " + phone, "phonePrompt", "green");
	setTimeout(function(){jsHide("phonePrompt");}, 4000);
		return true;
	}	
	
		jsShow("phonePrompt");
		producePrompt("Phone Number must much with Area Code ", "phonePrompt", "orange");
		return false;
}
function validateNationality(x)
{
	if(x=="0")
	{
		jsShow("nationpropmt");
		producePrompt("please select country  ", "nationpropmt", "orange");
		return false;
	}
	if(x!="Ethiopia")
	{
		jsShow("nationpropmt");
		producePrompt("candidate must be Ethiopian  ", "nationpropmt", "orange");
		return false;
	}
	jsShow("nationpropmt");
	producePrompt(" correct", "nationpropmt", "green");
	setTimeout(function(){jsHide("nationpropmt");}, 2000);
		return true;
}
function validateRegion(x)
{
	if(x=="0")
	{
		jsShow("canregionPrompt");
		producePrompt("please select region ", "canregionPrompt", "orange");
		return false;
	}
	
	jsShow("canregionPromp");
	producePrompt("correct", "canregionPromp", "orange");
	setTimeout(function(){jsHide("canregionPromp");}, 2000);
		return true;
}
function validatezone(x)
{
	if(x=="-1"){
		jsShow("canzonePrompt");
		producePrompt("Please select candidate zone?  ", "canzonePrompt", "red");
		return false;
		
	}
	jsShow("canproPrompt");
	producePrompt("ok!   ", "canzonePrompt", "green");
	setTimeout(function(){jsHide("canzonePrompt");}, 2000);
		return true;
}
function validateWoreda(x)
{
	if(x == "-1"){
		jsShow("canwereaPrompt");
		producePrompt("Please select candidate woreda?  ", "canwereaPrompt", "red");
		return false;
		
	}
	jsShow("canwereaPrompt");
	producePrompt("ok !   ", "canwereaPrompt", "green");
	setTimeout(function(){jsHide("canwereaPrompt");}, 2000);
		return true;
}
function isNumeric(n) {
  return !isNaN(parseFloat(n)) && isFinite(n);
}
function validateUsername()
{
	var A_name = document.getElementById("User_name").value;
	if(A_name.length == 0){
		jsShow("UserNamePrompt");
		producePrompt("Please user Name?", "UserNamePrompt", "red");
		return false;
		
	}
	var A_nameexp = /^([a-zA-Z0-9_\.\-])+[A-Za-z0-9]+$/;
	if(!A_name.match(A_nameexp)){
		jsShow("UserNamePrompt");
		producePrompt("Invalid user Name", "UserNamePrompt", "orange");
		return false;
	}
	if(A_name.length <= 3||A_name.length >= 20){
		jsShow("UserNamePrompt");
		producePrompt("user name must between at least 3 and 20 char", "UserNamePrompt", "orange");
		return false;
		
	}
	var y=A_name[0];
	if(isNumeric(y)){
		jsShow("UserNamePrompt");
		producePrompt("User name can not start with number", "UserNamePrompt", "orange");
		return false;
		
	}
	jsShow("UserNamePrompt");
	producePrompt("welcome  " + A_name, "UserNamePrompt", "green");
	setTimeout(function(){jsHide("UserNamePrompt");}, 2000);
		return true;
}
function validatePassword()
{
	var pass=document.getElementById("password").value;
	var x=pass.length;
	if(x == 0){
		jsShow("PasswordPrompt");
		producePrompt("Password please?    ", "PasswordPrompt", "red");
		return false;
		
	}
	if(x<=5){
		jsShow("PasswordPrompt");
		producePrompt(" Weak !   ", "PasswordPrompt", "orange");
		return true;
		}
	jsShow("PasswordPrompt");
	producePrompt("good " , "PasswordPrompt", "green");
	setTimeout(function(){jsHide("PasswordPrompt");}, 2000);
		return true;
}
function validateRePassword(){
	var RPassword = document.getElementById("re_pasword").value;
	var pass=document.getElementById("password").value;
	var x=RPassword.length;
	if( x == 0){
		jsShow("re_passowrdPrompt");
		producePrompt("Retype Password ", "re_passowrdPrompt", "red");
		return false;
		
	}
	
	if(pass ==RPassword){
		jsShow("re_passowrdPrompt");
	producePrompt("mached" , "re_passowrdPrompt", "green");	
	setTimeout(function(){jsHide("re_passowrdPrompt");}, 4000);
	return true;	
	}
	jsShow("re_passowrdPrompt");
	producePrompt("password not match" , "re_passowrdPrompt", "red");	
	return false;	
}
function validatecreateAccount(form)
{
var ag = document.getElementById("ca_age");
var agval = ag.options[ag.selectedIndex].value;
var co = document.getElementById("Nationality");
var coval = co.options[co.selectedIndex].value;
var re = document.getElementById("region");
var reval = re.options[re.selectedIndex].value;
var z = document.getElementById("zone");
var zval = z.options[z.selectedIndex].value;
var w = document.getElementById("woreda");
var wva = w.options[w.selectedIndex].value;
if(!(validateName()))
{
return false;
}
if(!(validateidentity()))
{
return false;
}
if(!(validateEoage(agval)))
{
return false;
}
if(!(validateNationality(coval)))
{
return false;
}
if(!(validateRegion(reval)))
{
return false;
}
if(!(validatezone(zval)))
{
return false;
}
if(!(validateWoreda(wva)))
{
return false;
}
if(!(validateemail()))
{
return false;
}
if(!(validatephone()))
{
return false;
}
if(!(validateUsername()))
{
return false;
}
if(!(validatePassword()))
{
return false;
}
if(!(validateRePassword()))
{
return false;
}
return true;
}
function jsShow(id)
{
	document.getElementById(id).style.display = "block";
}
function jsHide(id)
{
	document.getElementById(id).style.display = "none";
}
function producePrompt(message, promptLocation, color)
{
	document.getElementById(promptLocation).innerHTML = message;
	document.getElementById(promptLocation).style.color = color;
}