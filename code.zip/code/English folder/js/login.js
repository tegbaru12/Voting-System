function validateAccounttype(x)
{
if(x=="0")
{
       jsShow("typeprompt");
		producePrompt("log in as what ? ", "typeprompt", "red");
		return false;
		}
 return true;
}
function login(form)
{
var ty = document.getElementById("type");
var tyval = ty.options[ty.selectedIndex].value;
if(!(validateAccounttype(tyval)))
{
return false;
}
return true;
}
   function jsShow(id){
	document.getElementById(id).style.display = "block";
}

function jsHide(id){
	document.getElementById(id).style.display = "none";
}


function producePrompt(message, promptLocation, color){
	document.getElementById(promptLocation).innerHTML = message;
	document.getElementById(promptLocation).style.color = color;
}