function validateID()
{
var pname = document.getElementById("voter_id").value;
	if(pname.length == 0){
		jsShow("voteridePrompt");
		producePrompt("Please Voter identity?  ", "voteridePrompt", "red");
		return false;
		
	}
	var nameexp =/^[0-9]+$/;
	if(!pname.match(nameexp))
	{
		jsShow("voteridePrompt");
		producePrompt("please enter correct voter identity ", "voteridePrompt", "orange");
		return false;
	}
	jsShow("voteridePrompt");
	producePrompt("ok!   " + pname, "voteridePrompt", "green");
	setTimeout(function(){jsHide("voteridePrompt");}, 2000);
		return true;	
}
function validateNationality(x)
{
	if(x=="0")
	{
		jsShow("nationpropmt");
		producePrompt("please select country  ", "nationpropmt", "orange");
		return false;
	}
	if(x!="2")
	{
		jsShow("nationpropmt");
		producePrompt("voter  must be Ethiopian  ", "nationpropmt", "orange");
		return false;
	}
	jsShow("nationpropmt");
	producePrompt(" correct", "nationpropmt", "green");
	setTimeout(function(){jsHide("nationpropmt");}, 2000);
		return true;
}
function validateRegion(x)
{
	if(x=="0")
	{
		jsShow("canregionPrompt");
		producePrompt("please select region  ", "canregionPrompt", "orange");
		return false;
	}
	return true;
}
function validatezone(x)
{
	if(x=="-1"){
		jsShow("canzonePrompt");
		producePrompt("Please select voter zone?  ", "canzonePrompt", "red");
		return false;
		
	}
	jsShow("canproPrompt");
	producePrompt("ok!   ", "canzonePrompt", "green");
	setTimeout(function(){jsHide("canzonePrompt");}, 2000);
		return true;
}
function validateWoreda(x)
{
	if(x == "-1"){
		jsShow("canwereaPrompt");
		producePrompt("Please select voter woreda?  ", "canwereaPrompt", "red");
		return false;
		
	}
	jsShow("canwereaPrompt");
	producePrompt("OK !   ", "canwereaPrompt", "green");
	setTimeout(function(){jsHide("canwereaPrompt");}, 2000);
		return true;
}
function validateUsername()
{
	var A_name = document.getElementById("User_name").value;
	if(A_name.length == 0){
		jsShow("UserNamePrompt");
		producePrompt("Please user Name?", "UserNamePrompt", "red");
		return false;
		
	}
 return true;
}
function validatePassword()
{
	var pass=document.getElementById("password").value;
	var x=pass.length;
	if(x == 0){
		jsShow("PasswordPrompt");
		producePrompt("Password please?    ", "PasswordPrompt", "red");
		return false;
		
	}
		return true;
}
function validateloginform()
{
	var na=document.getElementById("Nationality").selectedIndex.value;
	var reg=document.getElementById("region").selectedIndex.value;
	var zo=document.getElementById("zone").selectedIndex.value;
	var wo=document.getElementById("woreda").selectedIndex.value;
	if(!validateID()||!validateNationality(na)||!validateRegion(reg)||!validatezone(zo)||!validateWoreda(wo)
		||!validateUsername()||!validatePassword())
		{
			return false;
		}
		return true;
}