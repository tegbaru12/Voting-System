<!DOCTYPE html>
<?php
if(!isset($_SESSION['login_EO']))
{
?>
<script language="JavaScript">
	window.location="../login.php";
</script>
<?php
}
?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="generator" content="CoffeeCup HTML Editor (www.coffeecup.com)">
    <meta name="dcterms.created" content="Mon, 23 Dec 2013 21:53:19 GMT">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <title>ETHIOPIA ELECTION BOARD</title>
   <link href="../css/ovs.css" type="text/css" rel="stylesheet">
<div id="main">
    <div id="header">
	<h1> <table width=100% height=100%> 
<tr>
<td rowspan=3 align="right"><image src="../image/et.jpg" width=130 height=120></td>
<td>የኢትዮጲያ ምርጫ ቦርድ</td>
<td> 
<span style="font-size: 10pt;color: white;">LANGUAGE (ቋንቋ):-- <a href="../English folder/HOME.html"><span style="font-size: 10pt;color: white;">ENGLISH /</span></a>
<a href="../amharic folder/HOME.html "><span style="font-size: 10pt;color: white;">አማረኛ</span></a></span>
</span>
</td>
</tr>
<tr> 
<td>
ELECTION BOARD OF ETHIOPIA</td>
<td>
<?php
$userna=$_SESSION['login_EO'];
$localhost="localhost";
$dbuser="root";
$dbpass="";
$dbname="ovs";
$con=mysql_connect($localhost,$dbuser,$dbpass);
if(!$con)
{ die("Coudn't connect to the server");
}
$db_select=mysql_select_db($dbname,$con);
if(!$db_select)
{
	die("db is not selected".mysql_error());
}
$qry="SELECT * FROM election_officer where username='$userna'";
$result=mysql_query($qry);
while($row=mysql_fetch_array($result))
{
	$name=$row['name'];
}
echo '<a href="profile.php"><span style="font-size: 12pt; font-family: verdana, geneva; color: deepskyblue;">' .$name. '</a>';
echo" ";
echo '<a href="editprofile.php"><span style="font-size: 12pt; color: #941dff;">[ Edit Profile ]</span></a></span>';
echo '<a href="logout.php"><span style="font-size: 12pt; color: lightsteelblue;">[ Logout ]</span></a></span></td>';
?>
</tr></table>
</h1>
</div>
</div>
   <div id="menu_container">
   <div id="menubar">
	<div id="nav">
    <ul class="sf-menu dropdown">
    <li><a href="HOME.php">HOME</a></li>
	<li><a href="#">ABOUT ELECTION</a><span class="darrow">&#9660;</span>
			<ul>
				  <li><a href="electionEthio.php">Election in Ethiopia</a></li>
				  <li><a href="counstruct.php">Country structure</a></li>
				  <li><a href="historydemo.php">Democracy in Ethiopia</a></li>
				  <li><a href="aboutevot.php">About E-VOTING</a></li>
			
		     </ul>
	     </li>
	
	<li><a href="#">POLETICAL PARTY</a><span class="darrow">&#9660;</span>
	     <ul>
		    <li><a href="partyInEthio.php">Party in Ethiopia </a></li>
			<li><a href="partypolice.php">party police</a></li>
			<li><a href ="approveparty.php"> Approve Party</a></li>
			<li><a href="#">Registered Party  </a></a><span class = "rarrow">&#9654;</span>
			 <ul>
				<li> <a href="partylogo.php">party logos</a></li>
				<li> <a href ="partylist.php">party list</a></li>
				</ul>
				</li>
				<li> <a href="#">search party</a></li>
		</ul>
	</li>
	<li><a href="#">ELECTION OFFICER</a><span class="darrow">&#9660;</span>
	    <ul>
		    <li><a href="nebe.php">NEBE</a></li>
			<li><a href="createAccount.php">Create EC account</a></li>
			<li><a href="#">Election zone</a></li>
			<li><a href="#">Declarities</a></li>
			<li><a href="#">Proclamation</a></li>
			<li><a href="#">Authority</a></a><span class = "rarrow">&#9654;</span></li>
		</ul>
	</li>
	<li><a href="#">VOTERS</a><span class="darrow">&#9660;</span>
	     
		 <ul>
		    <li><a href="voterregister.php">Register voter</a></li>
			 <li><a href="aboutvoter.php">About voter</a></li>
		</ul>
	</li>
	<li><a href="#">ELECTION WAY </a><span class="darrow">&#9660;</span>
		 <ul>
		    <li><a href="#">Election period</a></li>
			<li><a href="#">News</a></li>
			<li><a href="#">Governor</a></li>
			<li><a href="#">Election result</a></li>
			<li><a href="#">Photo Gallery</a></li>
		</ul>
	</li>
		<li><a href="#">View</a>
			<ul>
				<li><a href="resultserch.php">Election result</a></li>
				<li><a href="seats.php">winned seats</a></li>
			</ul>
		</li>

	</ul>
</div>
</div>
</div>