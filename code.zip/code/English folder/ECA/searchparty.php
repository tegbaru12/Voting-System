
<!DOCTYPE html>
<html lang="en">
  <head>
	  <?php
	  session_start();
	  include ("ecaheader.php");
	  ?>
   <STYLE TYPE="text/css">
 #contact form {
	background: #f2f5f5;
margin:auto;
position:relative;
width:680px;
height:800px;
font-family: ;
font-size: 14px;
font-style: italic;
line-height: 24px;
font-weight: ;
color: black;
text-decoration: none;
-webkit-border-radius: 10px;
-moz-border-radius: 10px;
border-radius: 10px;
padding:10px;
border: 1px solid #99779;
border: inset 0px solid #333;
-webkit-box-shadow: 0px 0px 8px rgba(160, 24, 255, 0.25);
-moz-box-shadow: 0px 0px 8px rgba(21, 10, 255, 0.3);
box-shadow: 0px 0px 8px rgba(156, 56, 6, 0.88)
}
#site_content
{ 
    padding: 0px;
	width: 1200px;
	height:1000px;
	overflow: hidden;
	margin:10px auto;
	text-align:left;
	background:#ccc url(../image/mainback.jpg) repeat;
	border:2px solid green;
}
</style>
  </head>
  <?php
  include ("sidebar.php");
  ?>
<div id="content"
<div class="content_item">
					<b>
						<div id="contact" class="body">
							<form name = "CandidateForm" action ="#" method="POST" enctype="multipart/form-data"">
								<legend align="center"><font color="blue" size="5pt">SEARCH PARTY</font></legend>
								<table >
									<tbody  > 
										<tr>
											<td align ="center">Party Name or Abrevation codd:</td>
											<td ><input id = "pName" name = "pName" class = "contactFormInput" type="text" class="txtfield" placeholder = "Enter value here" "required>
								  <button type = "submit" id="se" name="se" > <strong>Search</strong> </button>
										<button type="submit" id="edi" name="edi"><strong>Edit</strong></button></td></tr>;
									</tbody>
								</table>

							<?php

							if(isset($_POST['se']))
							{
								$localhost="localhost";
								$dbuser="root";
								$dbpass="";
								$dbname="ovs";
								$con=mysql_connect($localhost,$dbuser,$dbpass);
								if(!$con)
								{ die("Coudn't connect to the server");
								}
								$db_select=mysql_select_db($dbname,$con);
								if(!$db_select)
								{
									die("db is not selected".mysql_error());
								}
								$searched=$_POST['pName'];
								$sql="select *from party where party_name='$searched' OR PIC='$searched'";
								if(!(mysql_num_rows(mysql_query($sql))))
								{
									echo'<font color="red">There is No such Party</font> ';
									exit;
								}

								$result=mysql_query($sql);
								while($row=mysql_fetch_row($result))
								{
									echo'<center><table border="red"><tr><td><label id="pnameprom"> Party Name</label></td>';
									echo'<td><label>'.$row[0].'</label></td></tr>';
									echo'<tr><td><label id="pic"> Party Code</label></td>';
									echo'<td><label>'.$row[1].'</label></td></tr>';
									echo'<tr><td><label id="syname"> Symol Name</label></td>';
									echo'<td><label>'.$row[2].'</label></td></tr>';
									echo'<tr><td><label id="sym"> party symbol </label></td>';
									echo'<td><img src=" data:image;base64,'. $row[3].'" height="100" width="100" alt="image not found"/></td></tr>';
									echo'<tr><td><label id="repna"> Party Representative name</label></td>';
									echo'<td><label>'.$row[4].'</label></td></tr>';
									echo'<tr><td><label id="ressn"> Representative SSN:</label></td>';
									echo'<td><label>'.$row[5].'</label></td></tr>';
									echo'<tr><td><label id="repsex"> Representative Sex</label></td>';
									echo'<td><label>'.$row[6].'</label></td></tr>';
									echo'<tr><td><label id="repage"> Representative Age:</label></td>';
									echo'<td><label>'.$row[7].'</label></td></tr>';
									echo'<tr><td><label id="pic"> Representative Proffision</label></td>';
									echo'<td><label>'.$row[8].'</label></td></tr>';
									echo'<tr><td><label id="pic"> Nationality</label></td>';
									echo'<td><label>'.$row[9].'</label></td></tr>';
									echo'<tr><td><label id="pic"> region</label></td>';
									echo'<td><label>'.$row[10].'</label></td></tr>';
									echo'<tr><td><label id="pic"> Zone</label></td>';
									echo'<td><label>'.$row[11].'</label></td></tr>';
									echo'<tr><td><label id="pic"> Woreda</label></td>';
									echo'<td><label>'.$row[12].'</label></td></tr>';
									echo'<tr><td><label id="pic"> E-mail</label></td>';
									echo'<td><label>'.$row[13].'</label></td></tr>';
									echo'<tr><td><label id="pic"> Phone number</label></td>';
									echo'<td><label>'.$row[14].'</label></td></tr>';
									echo'<tr><td><label id="pic"> User Name</label></td>';
									echo'<td><label>'.$row[15].'</label></td></tr>';
									echo'</table></center>';
								}
							}
							if(isset($_POST['edi']))
							{
								$localhost="localhost";
								$dbuser="root";
								$dbpass="";
								$dbname="ovs";
								$con=mysql_connect($localhost,$dbuser,$dbpass);
								if(!$con)
								{ die("Coudn't connect to the server");
								}
								$db_select=mysql_select_db($dbname,$con);
								if(!$db_select)
								{
									die("db is not selected".mysql_error());
								}
								$searched=$_POST['pName'];
								$sql="select *from party where party_name='$searched' OR PIC='$searched'";
								if(!(mysql_num_rows(mysql_query($sql))))
								{
									echo'<font color="red">There is No such Party</font> ';
									exit;
								}

								$result=mysql_query($sql);
								while ($row=mysql_fetch_row($result)) {


									echo '<div id="contact" class="body">
							<form name = "PartForm"  enctype="multipart/form-data" action ="#" method="POST" onsubmit = "return validateParRegisterForm(this.form);">
							<fieldset><legend align="center"><font color="blue" size="5pt">Edit Party Information</font></legend>
								<table >
									<tbody  > 
										<tr>
											<td align ="center">Party Name:</td>
											<td><input id = "p_Name" name="p_Name" class = "contactFormInput" type="text" value="'.$row[0].'" class="txtfield" placeholder = "'.$row[0].'" onblur = " validateP_Name()"required></td>
										<td><label id = "PNamePrompt"></label> </td>
										</tr>
										<tr>
											<td align ="center">Party Identity code(name abrevation):</td>
											<td><input id = "party_identity" name="party_identity" class = "contactFormInput" value="'.$row[1].'" type="text" class="txtfield" placeholder = "'.$row[1].'"  onblur = "validateP_code()" ></td>
										<td><label id = "Party_codePrompt"></label> </td>
										</tr>
										<tr>
											<td align ="center">Party symbol name:</td>
											<td><input id = "sym_name" name="sym_name" class = "contactFormInput" value="'.$row[2].'" type="text" class="txtfield" placeholder = "'.$row[2].'"  onblur = " validatesympnmae()" required></td>
										<td><label id = "symbnameprompt"></label> </td>
										</tr>
										<tr>
											<td align ="center">Part symbol:</td>
											<td><input id = "logo" name="logo" class = "contactFormInput"  accept="image/gif, image/jpeg, image/png,image/jpg" value="" type="file" class="txtfield" placeholder = "'.$row[3].'" ></td>
										<td><label id = "LogoPrompt"></label> </td>
										</tr>
										<tr>
										$i=0;
										$j=1;
											<td align ="center">Party status </td>
											<td><select name="per" id="per">
											<option value=$i>Not permisioned for election</option>
											<option value=$j>permisioned for election</option></select></td>
										<td><label id = "repnamePrompt"></label> </td>
										</tr>
										<tr>
											<td></td>
											<td align="center"><button type = "submit" id="reg" name="reg" ><strong> Save Change </strong></button> </td>
										<td><button type = "reset" onclick = "" ><strong> Reset </strong></button> </td>
										</tr>
										</tbody>
								</table></fieldset> </form>';
								}
							}
			if(isset($_POST['reg']))
			{	$searched=$_POST['pName'];
					$localhost="localhost";
					$dbuser="root";
					$dbpass="";
					$dbname="ovs";
					$con=mysql_connect($localhost,$dbuser,$dbpass);
					if(!$con)
					{ die("Coudn't connect to the server");
					}
					$db_select=mysql_select_db($dbname,$con);
					if(!$db_select)
					{
						die("db is not selected".mysql_error());
					}
				$update;
					$pname=$_POST['p_Name'];
					$PIC=$_POST['party_identity'];
				$syname = $_POST['sym_name'];
				$perm=$_POST['per'];
						if(is_uploaded_file($_FILES['logo']['name'])) {
							$img_name = $_FILES['logo']['name'];

							$temp = $_FILES['logo']['tmp_name'];
							$file_type = $_FILES['logo']['type'];
							$size = $_FILES['logo']['size'];
							if ($size > 500000) {
								echo "image is too large";
								exit;
							}

							$image = addslashes($temp);

							$image = file_get_contents($image);
							$target_file = $image;
							$image = base64_encode($image);
							$update="update party set party_name='$pname', PIC='$PIC', symb_name='$syname', party_symbol='$image',status='$perm' where party_name='$searched=' OR PIC='$searched'";
						}
						else{
							$update="update party set party_name='$pname', PIC='$PIC',status='$perm' where party_name='$searched=' OR PIC='$searched'";
						}
					if(mysql_query($update))
					{
						echo'<font color="green" size="4pt">Change Saved</font>';
						exit;
					}
					else
					{
						echo'Error'.mysql_error();
						exit;
					}
					}
					?>


				</div>
			</div>
	</div>
	</div>
  <?php
  include ("../footer.php");
  ?>
  </body>
</html>
