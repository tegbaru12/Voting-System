<!DOCTYPE html>
<?php
session_start();
include ("ecaheader.php");
?>
<?php
include ("sidebar.php");
?>
	<div id="content">
		<div class="content_item">
			<b>
				<div id="contact" background="green">
					<form name = "RegistrationForm" action ="#" enctype="multipart/form-data" method="post" onsubmit = "return(validatloginform());">
						<?php
						$date =date_create();
						date_date_set($date,2016 ,05 ,26 );
						$date=date_format($date, "y/m/d");
						$curentdate=date("y/m/d");
						if($date>$curentdate)
						{
							echo'<font size="5pt" color="red">Election is not takes place So there is no election result!!!</font>';
							exit;
						}
						if ($date==$curentdate)
						{
							echo'<font size="5pt" color="red">Election is not finished so result cannot be generated !!!</font>';
							exit;
						}
						?><table>
							<center><font color="blue" size="5pt">ELECTION RESULT</font>

								<tr>
									<td align="center"> Election zone</td>
									<td>
										<select id="woreda" class="contactFormInput" name="woreda" onchange="validateWoreda(this.options[this.selectedIndex].value)" onmouseover="selectworeda(this.options[this.selectedIndex].value)" required>
											<option value="-1">-----select woreda--</option>
										</select>
										<script language="JavaScript">
											function selectworeda(x)
											{

												var wo=["Ababo", "Ab Ala", "Abaya", "Abay Chomen","Abe Dongoro "," Abergele"," Abeshege","Abichuna Gne'a","Abobo","Abuna Gindeberet","Adaa'r","Ada'a",
													"Adaba","Adadle"," Adama","Adami Tulu Jido Kombolcha ","Adda Berga","Addi Arekay","Addis Ketema","Adola","Adwa","Afambo","Afdem","Afder",
													"Afdera","Afele Kola (Dima)","Agalometi","Agarfa","Ahferom","Akaki","Akaki - Kalit","Akobo","Alaba","Alaje","Alamata","Albuko","Ale",
													"Aleltu","Alem Gena","Aleta Wendo","Alfa","Alge Sachi","Alicho Woriro","Alle","Amaro","Ambasel","Ambo Zuria","Ameya","Amibara","Amigna",
													"Amuru","Analemmo","Anchar","Anderacha","Aneded","Anfilo","Angolelana Tera","Anigacha","Ankasha","Ankober","Antsokiya","Arada","Arba Minch Zuria",
													"Arbe Gonna","Arero","Argoba","Argoba Liyu","Aroresa","Arsi Negele","Artuma","Artuma Fursi","Aseko","Asgede Tsimbila","Assagirt","Assosa","Atsbi Wenberta",
													"Awabel","Aware","Awash Fentale","Awra","Ayida","Ayira Guliso","Ayisha","Aysaita","Babile","Babile","Babo","Badele Zuria","Bahirdar Zuria","Bako Tibe",
													"Bambasi","Banja","Bare","Basketo","Baso Liben","Basona Worena","Bati","Becho","Bedeno","Begi","Bele Gesgar","Bena Tsemay","Bensa","Berahle",
													"Berbere","Bereh","Berehet","Bero","Beyeda","Bibugn","Bidu","Bila Seyo","Bilidigilu","Bilo Nopha","Bio Jiganifado","Bita (Big)","Boh","Boji Chekorsa",
													"Boji Dirmeji","Boke","Bole","Boloso Bombe","Boloso sore","Bona Zuria","Boneya Boshe","Bonke","Bora","Bore","Borecha",
													"Boreda","Boricha","Boset","Bugna","Bule","Bule Hora","Bulen","Bure","Bure Mudaytu","Burji","Bursa","Chefa Gula","Cheha",
													"Cheliya","Chena","Chencha","","Chereti/Weyib","Cheta","Chifra","Chilga","Chinaksen","Chire","Chiro Zuria","Chole","Chora",
													"Chuko","Chwaka","Dabat","Dabo Hana","Dale","Dale Sadi","Dale Wabera","Dalocha","Dalul","Damot Gale","Damot Pulasa","Damot Sore",
													"Damot Weydie","Dangila","Dangura","Daniboya","Dano","Danot","","Dara","Daramalo","Darimu","Daro Lebu","Dasenech (Kuraz)",
													"Dawe Kachen","Dawo","Dawunt","Debark","Debay Telatgen","Debeweyin","Debre Elias","Debre Libanos","Debresina","Debub Achefer","Debub Bench",
													"Decha","Deder","Dedesa","Dedo","Dega","Dega Damot","Degehabur","Degehamedo","Degeluna Tijo","Degem","Degua Temben","Dehana","Dehas",
													"Dejen","Delanta","Dembecha","Dembel","Dembia","Denan","Dendi","Denibu Gofa","Dera","Derashe","Dessie Zuria","Dewa Harewa",
													"Dewe","Dibat","Didu","Diga","Diguna Fango","Dihun","Diksis","Dila Zuria","Dillo","Dima","Dinsho","Dire","Dire Dawa",
													"Dire Dawa/Town","Dita","Doba","Dodola","Dodota","Dolobay","Dolo Odo","Dorani","Doya Gena","Dubti","Dugda","Dugda Dawa","Dulecha","Dune",
													"East Belesa","East Esite","East Imi","Ebenat","Eferatana Gidem","Ejere (Addis Alem)","Ela (Konta) ","Elidar","Enarj Enawga",
													"Enbise Sar Midir","Endamehoni","Enderta","Endiguagn","Enemay","Enemorina Eaner","Ensaro","Erebti","Erer","Erob","Esira",
													"Etang","Ewa","Ezha","Fagta Lakoma","Farta","Fedis","Fentale","Ferfer","Fik","Filtu","Fogera","Fursi","Gaji","Gambela Zuria",
													"Ganta Afeshum","Gasera","Gawo Kebe","Gaz Gibla","Gechi","Gedeb Asasa","Geladin","Gelana","Gelila (Semen Ari)","Gembora",
													"Gemechis","Gena Bosa","Gera","Gerar Jarso","Gerbo","Gesha (Deka)","Geta","Getawa","Gewane","Geze Gofa","Gibe","Gida Kiremu",
													"Gidami","Gidan","Gimbi","Gimbichu","Gimbo","Ginde Beret","Ginir","Girawa","Girja (Harenfema)","Gishe Rabel","Gnangatom","Goba",
													"Goba Koricha","Gobu Seyo","Gode","Godere","Goge","Gololcha Arsi","Gololcha Bale","Golo Oda","Goma","Goncha Siso Enese","Gonder Zuria",
													"Gonje","Gorche","Goro","Goro","Goro Baqaqsa","Goro Gutu","Guagusa Shikudad","Guangua","Guba","Guba Lafto","Gudetu Kondole",
													"Guduru","Gulele","Gulina","Gulomekeda","Gumay","Gumer","Guna","Gunagado","Guradamole","Gura Damole","Gurafereda","Gursum",
													"Gursum","Guto Gida","Guzamn","Habro","Habru","Hadero Tubito","Hagere Mariam","Halu (Huka)","Hambela Wamena","Hamer","Hamero",
													"Harar","Harena Buluk","Hareshen","Hargele","Haro Limu","Haro Maya","Haru","Hawa Galan","Hawasa Town","Hawassa Zuria",
													"Hawi Gudina","Hawzen","Hidabu Abote","Hintalo Wejirat","Hitosa","Homosha","Horo","Hudet","Hulet Ej Enese","Hulla","Humbo","Hurumu",
													"Ibantu","Ifata","Ilu","Inkolo Wabe","Jabi Tehnan","Jama","Janamora","Jarso","Jarso","Jarte Jardega","Jawi",
													"Jeju","Jeldu","Jibat","Jida","Jijiga","Jikawo","Jille Timuga","Jimma Arjo","Jimma Genete","Jimma Horo","Jimma Rare","Jore","Kacha Bira",
													"aKalu","Kamashi","Kebena","Kebribeyah","Kebridehar","Kediada Gambela","Kelafo","Kelela","Kelete Awelallo","Kemba","Kembibit","Kercha","Kersa","Kersa","Kersana Malima","Kewe","Kiltu Kara","Kindo Dida","Kindo Koysha","Kirkos-Kobo","Kochere","Kochere Gedeb","Kofele","Kokir Gedbano","Kokir Gedbano","Kokosa","Kola Temben","Kolfe - Keran","Kondaltiti","Koneba","Kore","Kucha","Kuni","Kurfa Chele","Adiyabo","Kurmuk","Kurri","Kutaber","Kuyu","Laelay","Laelay Maychew","Lagahida","Lalo Asabi"
													,"Lalo Kile","Lanfero","Lare","Lasta (Ayna)","Lay Armacho","Lay Gayint","Legambo","Legehida","Lege Hida","Leka Dulecha","Liben","Liben Chukala","Libo Kemkem","Lideta-Limu","Limu","Limu Bilbilo","Limu Kosa","Limu Seka","Loka-Abaya","Loma Bosa","Lome","Lude Hitosa","Maji","Male","Malga","Malka Balo","Mana Sibu","Maokomo Special","Mareka","Mareko","Masha","Mecha",
													"Meda Welabu","Medebay Zana","Megale","Mehal Sayint","Mekdela","Meket","Meko","Melekoza","Melka Soda","Mena","Mena","Menge","Mengesh","Menit Goldiye","Menjiwo","Menz Gera Midir","Menz Keya Gabriel"
													,"Menz Lalo Midir","Menz Mama Midir","Merahbete","Mereb Leke","Merti","Mesela","Meskan","Meta","Meta Robi","Metema","Metu Zuria","Meyu","Meyumuluka","Michakel","Mida Kegn",
													"Midega Tola","Mierab Azenet Berbere","Mierab Badawacho","Mieso","Mile","Mimo Weremo","Minjar Shenkora","Mirab Abaya","Mirab Armacho","Misha","Misrak Azenet Berbere","Misrak Badawacho","Misrak Gashamo","Miyo","Mojan Wedera","Moretna Jiru","Moyale","Muhur Na Aklil","Mulo","Munessa","Mustahil","Naeder Adet","Nefas Silk","Nejo","Nenesebo (Wereka)","Nole Kaba",
													"Nono","Nunu Kumba","Odo Shakiso","Ofa","Ofla","Omo Nada","Pawe Special","Quara","Quarit","Raya Azebo","Rayitu","Robe","Saesie Tsaedaemba","Saharti Samre","Sahla","Sale Nono","Sankura","Sasiga","Sayilem","Sayint","Sayo","Sayo Nole","Seden Sodo","Segeg",
													"Seka Chekorsa","Sekela","Sekoru","Sekota","Selahad","Selamgo","Selti","Semen Achefer","Semen Bench","Senan","Serer/Elkere","Seru","Setema","Seweyna","Shalla","Shashemene Zuria","Shashogo",
													"Shay Bench","Shebe Dino","Shebel Bereta","Shebe Sambo","Sheka","Shekosh","Sherkole","Shilabo","Shinile","Shirka","Sibu Sire",
													"Sigmo","Simada","Simurobi Gele'alo","Sinana","Siraro","Sirba Abay","Sire","Siya Debirna Wayu","Sodo","Sodo Daci","Sodo Zuria","Soro","South Ari (Bako Gazer)",
													"Sude","Sululta","Surma","Tach Armacho","Tach Gayint","Tahtay Adiyabo","Tahtay Koraro","Tahtay Maychew",
													"Takusa","Tanqua Abergele","Tarema Ber","Teferi Ber","Telalak","Teltele","Tembaro","Tena","Tenta","Teru","Thehulederie","Tikur Enchini","Tiro Afeta","Tiyo",
													"Tocha","Toke Kutaye","Tole","Tsegede","Tselemt","Tselemti","Tulo","Ubadebretsehay","Uraga","Wadera","Wadla","Waliso","Walmara","Wama Hagalo","Wantawo","Wara Jarso",
													"Warder","Wayu Tuka","Wegde","Welkait","Wemberma","Wenago","Wenbera","Wenchi","Werei Leke","Were Ilu","West Belesa","West Esite","West Imi","Wilbareg","Wondo-Genet",
													"Wonosho","Worebabu","Wuchale","Yabelo","Yalo","Yama Logi Welel","Yaso","Yaya Gulele","Yayu","Yeka","Yeki","Yem Special","Yilmana Densa","Yirgachefe","Yubdo","Zala","Ziquala","Ziway Dugda"];
												var t=document.getElementById("woreda");
												var option=new Array(wo.length);
												for(i=0;i<wo.length;i++)
												{
													option[i]= document.createElement("option");
													option[i].text=wo[i];
													option[i].value=wo[i];
													t.add(option[i]);
												}
												return true;
											}

										</script>
										<input type = "submit" name="search" id="search" value="Show"></td></tr>
						</table>
						<?php
						if(isset($_POST['search']))
						{
							$localhost="localhost";
							$dbuser="root";
							$dbpass="";
							$dbname="ovs";
							$con=mysql_connect($localhost,$dbuser,$dbpass);
							if(!$con)
							{ die("Coudn't connect to the server");
							}
							$db_select=mysql_select_db($dbname,$con);
							if(!$db_select)
							{
								die("db is not selected".mysql_error());
							}
							$Elezone=$_POST['woreda'];
							$sql="SELECT * FROM vote WHERE 	woreda='$Elezone'AND subje=0 ORDER BY vot  DESC ";
							if(!(mysql_num_rows((mysql_query($sql)))))
							{
								echo'<br><font size="5pt" color="#FF1493">FEDRAL Election does not takes place in this Election zone</font><br>';
							}
							else {
								echo ' <br><font size="5pt" color="#4169e1">ELECTION RESULT FOR FEDRAL</font><br>';
								$result = mysql_query($sql);
								echo '<table border="green">
										<th>Party Name</th>
												<th>Candidate name</th>
												<th>voice</th>';
								while ($row = mysql_fetch_row($result)) {
									echo ' <tr>
                                                <td>' . $row[0] . '</td>
                                                <td>' . $row[1] . '</td>
                                                <td>' . $row[5] . '</td>
												</tr>';
								}
								echo '</table>';
							}
							$sql="SELECT * FROM vote WHERE 	woreda='$Elezone'AND subje=1 ORDER BY vot  DESC ";
							if(!(mysql_num_rows((mysql_query($sql)))))
							{
								echo'<font size="5pt" color="#FF1493">REGIONAL Election does not takes place in this Election zone</font>';
							}
							else {
								echo '<br><font size="5pt" color="#4169e1"> ELECTION RESULT FOR REGIONAL</font><br>';
								$result = mysql_query($sql);
								echo '<table border="green">
										<th>Party Name</th>
												<th>Candidate name</th>
												<th>voice</th>';
								while ($row = mysql_fetch_row($result)) {
									echo ' <tr>
                                                <td>' . $row[0] . '</td>
                                                <td>' . $row[1] . '</td>
                                                <td>' . $row[5] . '</td>
												</tr>';
								}
								echo '</table>';
							}
							echo'<br><right></right><a href=""><font color=blue size="4pt">print</font></a></right>';
						}
						?></center>
					</form>
				</div>
		</div>
	</div>
</div>
<?php
include ("footer.php");
?>
</body>
</html>
