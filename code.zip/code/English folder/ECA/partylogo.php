<!DOCTYPE html>
<?php
session_start();
include ("ecaheader.php");
include ("sidebar.php");
?>

<div id="content">
<div class="content_item">
<b>
<div id="contact" class="body">
	<form  >
   <fieldset>	
	<legend align="center"><font color="blue" size="5pt">PARTY SYMBOLS ABROVED BY THE BOARD</font></legend>
	<table border="green">
			<tr> <th>party name</th>
			<th>symbol name</th>
			<th>party symbol</th></tr>
		<?php 
		$localhost="localhost";
			$dbuser="root";
			$dbpass="";
			$dbname="ovs";
			$con=mysql_connect($localhost,$dbuser,$dbpass);
			if(!$con)
			{ die("Coudn't connect to the server");
			}
			$db_select=mysql_select_db($dbname,$con);
			if(!$db_select)
			{
			die("db is not selected".mysql_error());
			}
			$sql="select * FROM party ORDER BY party_name ASC";
			$result=mysql_query($sql);
			if(!$result)
			{
			echo "Error on displaying";
			exit;
			}
			while($row=mysql_fetch_array($result))
			{
			?>
			<tr><td>
			<?php echo $row[0]?>
			(<?php echo$row[1]?>
			   )
			</td>
			<td>
			<?php echo $row[2];?>
			</td>
			<td>
			<?php echo '<img src=" data:image;base64,'. $row[3].'" height="130" width="130" alt="image not found"/>';?>
			</td>
			</tr>
			<?php }?>
			<?php
			mysql_close($con);
			?>
			</table>
				<center><a href="#">Print</a></center>
	</fieldset>
	</form>
</div>
</div>
	</div>
	</div>
<?php
include ("../footer.php");
?>
  </body>
</html>
