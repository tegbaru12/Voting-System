<?php
/**
 * Created by PhpStorm.
 * User: alexo
 * Date: 5/27/2016
 * Time: 12:53 AM
 */
session_start();
include ("partyheader.php");
?>
<style type="text/css" xmlns="http://www.w3.org/1999/html">
#site_content
{
padding: 0px;
overflow: hidden;
margin:10px auto;
text-align:left;
border:5px solid green;
}
#contact form {
    background: #f2f5f5;
    margin:auto;
    position:relative;
    width:680px;
    height:5000px;
    font-family: ;
    font-size: 14px;
    font-style: italic;
    line-height: 24px;
    padding-top: -10px;
    color: black;
}
#contact form table {
    width:650px;
    position: relative;
}
</style>
<?php
include ("sidebar.php");
?>
    <div id="content">
                <div id="contact" background="green">
                    <form action="#" name="add" enctype="multipart/form-data" method="POST">
                        <fieldset>
                        <legend><font color="blue" size="5pt" >Add photo or viedo</legend></font>
                       <center>
                           <table>
                                <tr>
                                    <td>
                                    <input type="file"  name="ph" id="ph" accept="image/gif, image/jpeg, image/png,image/jpg" style="width:90px;" placeholder="Choose Image" onchange="showimage(this)"  >
                                    </td>
                                    <td>
                                        <input type="file" style="width:90px;" name="vi" id="vi" >
                                    </td>
                                </tr>
        <tr>
            <td>write something here...</td>
        </tr>
        <tr>
            <td colspan="2"><textarea name="wri" id="wri" rows="3" cols="60"   >
                            </textarea></td>
               </tr>
                               <tr>
                                   <td colspan="2"><img src="#" alt="Your image"></td>
                               </tr>
                               <script type="javascript">
                                   function readURL(input) {
                                       if (input.files && input.files[0]) {
                                           var reader = new FileReader();

                                           reader.onload = function (e) {
                                               $('#blah')
                                                   .attr('src', e.target.result)
                                                   .width(150)
                                                   .height(200);
                                           };

                                           reader.readAsDataURL(input.files[0]);
                                       }
                                   }
                               </script>

    <?php
        $localhost = "localhost";
        $dbuser = "root";
        $dbpass = "";
        $dbname = "ovs";
        $con = mysql_connect($localhost, $dbuser, $dbpass);
        if (!$con) {
            die("Coudn't connect to the server");
        }
        $db_select = mysql_select_db($dbname, $con);
        if (!$db_select) {
            die("db is not selected" . mysql_error());
        }
    ?>

    <tr>
        <td>
        </td>
        <td><input type="submit" name="post" value="Post" id="post"></td>
    </tr>
</table>
                                </center>
                        </fieldset>
                        <?php
                        if(isset($_POST['post']))
                        {

                            if($_POST['wri']==""&&$_FILES['vi']['name']==""&&$_FILES['ph']['name']=="")
                            {
                                echo'upload something to post';
                            }
                            if($_FILES['vi']['name']!="")
                            {
                                $name = $_FILES['vi']['name'];
                                $tempp = $_FILES['vi']['tmp_name'];
                                move_uploaded_file($tempp, "videofile/" . $name);
                                $url = "http://localhost/code/English folder/videofile/$name";
                                $come = $_POST['wri'];
                                echo"<tr><td colspan='2'> <embed src='$url' width='560' height='315'></embed></td></tr>";
                                if(!mysql_query("INSERT INTO video VALUES('','$name','$url','$come')"))
                                {
                                   echo'video does not uploaded'.mysql_error();
                                }
                                
                            }
                            if($_FILES['ph']['name']!="")
                            {
                                $img_name = $_FILES['ph']['name'];
                                $temp = $_FILES['ph']['tmp_name'];
                                $file_type = $_FILES['ph']['type'];
                                $size = $_FILES['ph']['size'];
                                $image = addslashes($temp);
                                $image = file_get_contents($image);
                                $target_file = $image;
                                $image = base64_encode($image);
                                $come = $_POST['wri'];
                                echo'<tr><td colspan="2"><img src=" data:image;base64,'. $image.'" height="230" width="230" alt="file not found" /></td></tr>';
                                $inser="INSERT INTO photos(name, image, comment) VALUES ('$img_name','$image','$come')";
                                $qryd=mysql_query($inser);
                                if(! $qryd)
                                {
                                    echo'image does not uploaded'.mysql_errno();
                                }
                                
                            }
                        }
                        $qry="SELECT *FROM video ORDER BY id DESC ";
                        $resul=mysql_query($qry);
                        while($row=mysql_fetch_row($resul))
                        {
                            echo$row[3];
                            echo'<br>';
                            echo" <embed src='$row[2]' width='560' height='315'></embed>";
                            echo'<br>';
                            echo$row[1];
                            echo'<br>';
                        }
                        $qr="SELECT *FROM photos ORDER BY id DESC ";
                        $result=mysql_query($qr);
                        while($row=mysql_fetch_row($result))
                        {
                            echo$row[3];
                            echo'<br>';
                            echo '<img src=" data:image;base64,'. $row[2].'" height="400" width="560" alt="image not found"/>';
                            echo'<br>';
                            echo$row[1];
                            echo'<br>';
                        }
                        ?>
                    </form>

        </div>
    </div>
</div>
<?php
include ("../footer.php");
?>
</body>
</html>
