<html lang="en">
<head>

	<?php
	session_start();
	include ("ecaheader.php");
	?>
   <script type="text/javascript" src="js/validateVoter_form.js"></script>
    <STYLE TYPE="text/css">
#site_content
{ 
    padding: 0px;
	width: 1200px;
	height:800px;
	overflow: hidden;
	margin:10px auto;
	text-align:left;
	background:#ccc url(../image/mainback.jpg) repeat;
	border:5px solid green;
}
</style>
	<?php
	include ("sidebar.php");
	?>
	<div id="content">
<div class="content_item">
<b>
						<div id="contact" class="body">
<?php
$localhost="localhost";
$dbuser="root";
$dbpass="";
$dbname="ovs";
$con=mysql_connect($localhost,$dbuser,$dbpass);
if(!$con)
{ die("Coudn't connect to the server");
}
$db_select=mysql_select_db($dbname,$con);
if(!$db_select)
{
die("db is not selected".mysql_error());
}
$fname=$_POST['F_Name'];
$lname=$_POST['La_Name'];
$mothername=$_POST['Mother_Name'];
$socila_co=$_POST['ssn'];
$sex=$_POST['v-Sex'];
$ag=$_POST['ca_age'];
$nati=$_POST['Nationality'];
$reg=$_POST['region'];
$zon=$_POST['zone'];
$wor=$_POST['woreda'];
$use_name=$_POST['User_name'];
$pass=md5($_POST ['password']);
$inser="insert into voters (F_name, l_name, mo_name, ssn, sex, age, nationality, region, zone, woreda, user_name, password) 
values('$fname','$lname','$mothername','$socila_co','$sex','$ag','$nati','$reg','$zon','$wor','$use_name','$pass')";
if (!mysql_query($inser))
{
die('you used  ' .mysql_error());
  }
 $x=0;
$sel = mysql_query( "SELECT MAX( v_id ) AS max FROM voters ;" );
$row = mysql_fetch_array( $sel );
$x = $row['max'];
$vot_id=$x;
  mysql_close($con);
?>

					
						<form><u><b><center><font color="green" size="5pt">You have register</b></u></font></center>
						<table border="green" width=650px> 
				<tr>
				<td>First name</td><td><?php echo $fname?></td>
				</tr>
				<tr>
				<td>last Name</td><td><?php echo $lname?></td></tr>
				<tr>
				<td>mother's  name</td><td><?php echo $mothername ?></td></tr>
				<tr>
				<td>Soial security code</td><td><?php echo $socila_co?></td></tr>
				<tr>
				<td>Sex</td><td><?php echo $sex?></td></tr>
				<tr>
				<td>Age</td><td><?php echo $ag?></td></tr>
				<tr>
				<td>Nationality</dt><td><?php echo $nati?></td></tr>
				<tr>
				<td>Region</td><td><?php echo $reg?></td></tr>
				<tr>
				<td>zone</td><td><?php echo $zon?></td></tr>
				<tr>
				<td>woreda</td><td><?php echo $wor?></td></tr>
				<tr>
				<td>User name</td><td><?php echo $use_name?></td></tr>
				<tr>
				<td>Password</td><td><?php echo $pass?></td></tr>
				<tr>
				<td>Your Voter identity code is:</td><td><?php echo $vot_id ?></td></tr>
				</table>
				<br>
				<br>
				<center><a href="#">Print</a></center>
				</form>
					</div>
							</div>
					</div>
					</div>
					</div>
	<?php
	include ("../footer.php");
	?>
  </body>
</html>