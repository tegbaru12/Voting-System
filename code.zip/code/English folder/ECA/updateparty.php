<!DOCTYPE html>
<html lang="en">
  <head>
	  <?php
	  session_start();
	  include ("ecaheader.php");
	  ?>
   <STYLE TYPE="text/css">
 #contact form {
	background: #f2f5f5;
margin:auto;
position:relative;
width:680px;
height:200px;
font-family: ;
font-size: 14px;
font-style: italic;
line-height: 24px;
font-weight: ;
color: black;
text-decoration: none;
-webkit-border-radius: 10px;
-moz-border-radius: 10px;
border-radius: 10px;
padding:10px;
border: 1px solid #99779;
border: inset 0px solid #333;
-webkit-box-shadow: 0px 0px 8px rgba(160, 24, 255, 0.25);
-moz-box-shadow: 0px 0px 8px rgba(21, 10, 255, 0.3);
box-shadow: 0px 0px 8px rgba(156, 56, 6, 0.88)
}
#site_content
{ 
    padding: 0px;
	width: 1200px;
	height:1000px;
	overflow: hidden;
	margin:10px auto;
	text-align:left;
	background:#ccc url(../image/mainback.jpg) repeat;
	border:2px solid green;
}
</style>
  </head>
  <?php
  include ("sidebar.php");
  ?>
<div id="content"
<div class="content_item">
	<b>
	<div id="contact" class="body">
	<?php
$localhost="localhost";
$dbuser="root";
$dbpass="";
$dbname="ovs";
$con=mysql_connect($localhost,$dbuser,$dbpass);
if(!$con)
{ die("Coudn't connect to the server");
}
$db_select=mysql_select_db($dbname,$con);
if(!$db_select)
{
	die("db is not selected".mysql_error());
}
$upd=$_POST['partna'];
$pname=$_POST['p_Name'];
$PIC=$_POST['party_identity'];
if(getimagesize($_FILES['logo']['tmp_name'])==FALSE)
{
	$sql="select *from party where party_name='$upd' OR PIC='$upd'";
	$result=mysql_query($sql);
	if(!$result)
	{
		echo "Error".mysql_error();
		exit;
	}
	while ($row=mysql_fetch_row($result))
	{
		$imag=$row[3];
	}
}
else {
	$img_name = $_FILES['logo']['name'];
	$temp = $_FILES['logo']['tmp_name'];
	$file_type = $_FILES['logo']['type'];
	$size = $_FILES['logo']['size'];
	if ($size > 500000) {
		echo "image is too large";
		exit;
	}
	$image = addslashes($temp);

	$image = file_get_contents($image);
	$target_file = $image;
	$image = base64_encode($image);
}
$name = $_POST['sym_name'];
$PRN=$_POST['party_rep_name'];
$SSC=$_POST['rep_ssn'];
$sex=$_POST['V-sex'];
$age=$_POST['ca_age'];
$PRP=$_POST['party_rep_pro'];
$nationality=$_POST['Nationality'];
$region=$_POST['region'];
$zone=$_POST['zone'];
$woreda=$_POST['woreda'];
$update="update party set party_name='$pname', PIC='$PIC', symb_name='$name', party_symbol='$image',PRN='$PRN',SSC='$SSC',sex='$sex', age='$age', PRP='$PRP', nationality='$nationality', region='$region', zone='$zone', woreda='$woreda' where party_name='$upd' OR PIC='$upd'";
if(!mysql_query($update))
{
	echo'Error'.mysql_error();
	exit;
}
echo'<font color="red">Change Saved';
?>
	</div>
</div>
</div>
  </div>
  <?php
  include ("../footer.php");
  ?>
  </body>
</html>

