<html lang="en">
<head>

	<?php
	session_start();
	include ("ecaheader.php");
	?>
    <STYLE TYPE="text/css">
#site_content
{ 
    padding: 0px;
	width: 1200px;
	height:800px;
	overflow: hidden;
	margin:10px auto;
	text-align:left;
	background:#ccc url(../image/mainback.jpg) repeat;
	border:5px solid green;
}
</style>
	<?php
	include ("sidebar.php");
	?>
	<div id="content">
<div class="content_item">
<b>
						<div id="contact" class="body">
<?php
$localhost="localhost";
$dbuser="root";
$dbpass="";
$dbname="ovs";
$con=mysql_connect($localhost,$dbuser,$dbpass);
if(!$con)
{ die("Coudn't connect to the server");
}
$db_select=mysql_select_db($dbname,$con);
if(!$db_select)
{
die("db is not selected".mysql_error());
}
$name=$_POST['Name'];
$socila_co=$_POST['eoid'];
$sex=$_POST['ca-Sex'];
$ag=$_POST['ca_age'];
$nati=$_POST['Nationality'];
$reg=$_POST['region'];
$zon=$_POST['zone'];
$wor=$_POST['woreda'];
$ema=$_POST['email'];
$phone=$_POST['pho_num'];
$use_name=$_POST['User_name'];
$pass=md5($_POST ['password']);
$inser="INSERT INTO election_officer(name,ssn, sex, age, nationality, region, zone, woreda, e_mail, phone_number,username, password) 
VALUES ('$name','$socila_co','$sex','$ag','$nati','$reg','$zon','$wor','$ema','$phone','$use_name','$pass')";
if (!mysql_query($inser))
{
die('you used  ' .mysql_error());
  }
 $x=0;
$sel = mysql_query( "SELECT MAX( Elec_of_identity ) AS max FROM election_officer ;" );
$row = mysql_fetch_array( $sel );
$x = $row['max'];
$EO_id=$x;
  mysql_close($con);
?>

					
						<form><u><b><center><font color="green" size="5pt">You have register</b></u></font></center>
						<table border="green" width=650px> 
				<tr>
				<td>Name</td><td><?php echo $name?></td>
				</tr>
				<tr>
				<tr>
				<td>Soial security code</td><td><?php echo $socila_co?></td></tr>
				<tr>
				<td>Sex</td><td><?php echo $sex?></td></tr>
				<tr>
				<td>Age</td><td><?php echo $ag?></td></tr>
				<tr>
				<td>Nationality</dt><td><?php echo $nati?></td></tr>
				<tr>
				<td>Region</td><td><?php echo $reg?></td></tr>
				<tr>
				<td>zone</td><td><?php echo $zon?></td></tr>
				<tr>
				<td>woreda</td><td><?php echo $wor?></td></tr>
				<tr>
				<td>E_mail</td><td><?php echo $ema?></td></tr>
				<tr>
				<td>Phone number</td><td><?php echo $phone?></td></tr>
				<tr>
				<td>User name</td><td><?php echo $use_name?></td></tr>
				<tr>
				<td>Password</td><td><?php echo $pass?></td></tr>
				<tr>
				<td>Your Worker Identity IS:</td><td><?php echo $EO_id ?></td></tr>
				</table>
				<br>
				<br>
				<center><a href="#">Print</a></center>
				</form>
					</div>
							</div>
					</div>
					</div>
					</div>

	<?php
	include ("../footer.php");
	?>
  </body>
</html>