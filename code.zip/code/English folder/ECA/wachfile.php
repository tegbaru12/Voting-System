<!DOCTYPE html>
<html lang="en">
  <head>
      </head>
                            <?php
                            $localhost = "localhost";
                            $dbuser = "root";
                            $dbpass = "";
                            $dbname = "ovs";
                            $con = mysql_connect($localhost, $dbuser, $dbpass);
                            if (!$con) {
                                die("Coudn't connect to the server");
                            }
                            $db_select = mysql_select_db($dbname, $con);
                            if (!$db_select) {
                                die("db is not selected" . mysql_error());
                            }
							  mysql_close($con);
                            $id=$_POST['one'];
                                $que=mysql_query("select *from party where party_name='$id'");
                                while ($row=mysql_fetch_assoc($que))
                                {
                                    $url=$row[17];

                                }
                                echo '<embed src="'.$url.'" width="600px" height="700px"> </embed>';
                            ?>
  </body>
</html>