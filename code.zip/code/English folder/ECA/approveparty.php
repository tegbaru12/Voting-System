<!DOCTYPE html>
<html lang="en">
  <head>
	  <?php
    session_start();
	  include ("ecaheader.php");

	  ?>
	   <script type="text/javascript" src="../js/validateCan_form.js"></script>
      <STYLE TYPE="text/css">
          #contact form {
              background: #f2f5f5;
              margin:auto;
              position:relative;
              width:680px;
              height:750px;
              font-family: ;
              font-size: 14px;
              font-style: italic;
              line-height: 24px;
              font-weight: ;
              color: black;
              text-decoration: none;
              -webkit-border-radius: 10px;
              -moz-border-radius: 10px;
              border-radius: 10px;
              padding:10px;
              border: 1px solid #99779;
              border: inset 0px solid #333;
              -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
              -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
              box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3)
          }
          </style>
  </head>
  <?php
  include ("sidebar.php");
  ?>
<div id="content">
 <div class="content_item">
					<b>
						<div id="contact" class="body">
                            <?php
                            if(isset($_POST['fl']))
                            {
                            $localhost = "localhost";
                            $dbuser = "root";
                            $dbpass = "";
                            $dbname = "ovs";
                            $con = mysql_connect($localhost, $dbuser, $dbpass);
                            if (!$con) {
                            die("Coudn't connect to the server");
                            }
                            $db_select = mysql_select_db($dbname, $con);
                            if (!$db_select) {
                            die("db is not selected" . mysql_error());
                            }
                            $id=$_POST['fl'];
                            echo $id;
                            $qr="select *from party where 	party_name='$id'";
                            $que=mysql_query($qr);
                            if(!($que))
                            {
                            echo 'Error'.mysql_error();
                            exit;
                            }
                            while ($row=mysql_fetch_assoc($que))
                            {
                            $url=$row['atach'];

                            }
                            echo '<embed src="'.$url.'" width="600px" height="700px"> </embed>';
                            }?>
                            <?php
                            $localhost = "localhost";
                            $dbuser = "root";
                            $dbpass = "";
                            $dbname = "ovs";
                            $con = mysql_connect($localhost, $dbuser, $dbpass);
                            if (!$con) {
                                die("Coudn't connect to the server");
                            }
                            $db_select = mysql_select_db($dbname, $con);
                            if (!$db_select) {
                                die("db is not selected" . mysql_error());
                            }
                            if(!(mysql_num_rows(mysql_query("select *from party WHERE status=0"))))
                            {
                                echo'<font color="red" size="4pt"> There is no party that wants to approve</font>';
                                exit;
                            }
                            $select="select *from party WHERE status=0";
                            $rest=mysql_query($select);
                            echo'<font size="5pt" color="#1e90ff"> LIST OF NEWLY REGISTERED PARTY</font>';
                            while($row=mysql_fetch_row($rest))
                            {
                                echo'<form name = "CandidateForm" enctype="multipart/form-data" action ="#" method="POST">';
                                echo'<table border="red">';
                                $id=$row[0];
                                echo'<tr><td align="center">Party Name</td><td align="center"><input type="text" style="background: #d7e3e3; width:200px; height:30px; font-size:12pt;border:none" name="pname" id="pname" value="'.$row[0].'"></td></tr>';
                                echo'<tr><td align="center">PIC</td><td align="center">'.$row[1].'</td></tr>';
                                echo '<tr><td align="center">Party Symbol Name</td><td align="center">'.$row[2].'</td></tr>';
                                echo '<tr><td align="center">Party Symbol </td><td align="center"><img src=" data:image;base64,'. $row[3].'" height="130" width="130" alt="file not found" /></td></tr>';
                                echo '<tr><td align="center">Party Representative name</td><td align="center">'.$row[4].'</td></tr>';
                                echo '<tr><td align="center">Social securty code</td><td align="center">'.$row[5].'</td></tr>';
                                echo '<tr><td align="center">Sex</td><td align="center">'.$row[6].'</td></tr>';
                                echo '<tr><td align="center">Age</td><td align="center">'.$row[7].'</td></tr>';
                                echo '<tr><td align="center">Party Representative proffision</td><td align="center">'.$row[8].'</td></tr>';
                                echo '<tr><td align="center">Represenative Nationality</td><td align="center">'.$row[9].'</td></tr>';
                                echo '<tr><td align="center">Represenative Region</td><td align="center">'.$row[10].'</td></tr>';
                                echo '<tr><td align="center">Represenative Zone</td><td align="center">'.$row[11].'</td></tr>';
                                echo '<tr><td align="center">Represenative Woreda</td><td align="center">'.$row[12].'</td></tr>';
                                echo '<tr><td align="center">E-mail</td><td align="center">'.$row[13].'</td></tr>';
                                echo '<tr><td align="center">Phone Number</td><td align="center">'.$row[14].'</td></tr>';
                                echo"<tr><td align='center'> Attached file or CV</td><td align='center'><span style='font-size: 10pt;color: blue;'><input type='submit' name='fl' id='fl' value='".$row[0]."'> </span></a></td></tr>";
                                echo'<tr><td align="right"><input type="submit" name="app" id="app" value="Approve"></td><td align="center"><input type="submit" name="no" id="no" value="Delete" ></td></tr>';
                                echo '</table></form>';
                            }

           if(isset($_POST['id']))
           {

           }
                     if(isset($_POST['app']))
                     {
                         $pn=$_POST['pname'];
                         $update="update party set status=1 WHERE party_name='$pn'";
                         if(mysql_query($update))
                         {
                             echo '<font color="blue" size=4"pt">'.$pn.'</font><font color="green" size="4pt">Approved successfully</font>';
                             exit;
                         }
                         else
                         {
                             echo'<font color="red" size=4"pt"> Error on approval of party</font>';
                             exit;
                         }
                     }
                            if(isset($_POST['no']))
                            {
                                $pn=$_POST['pname'];
                                $del="delete from party WHERE party_name='$pn'";
                                if(mysql_query($del))
                                {
                                    echo'<font size="5pt" color="#7fff00" >'.$pn.'Have no Enough Qualification So it will deleted from data base ';
                                    exit;
                                }
                                else{
                                   echo' <font size="5pt" color="#7fff00" > Error'.$pn.'Does not removed';
                                    exit;
                                }
                            }

                             mysql_close($con);
                            ?>
						</div>
			</div>
	</div>
	</div>
	
  <?php
  include ("../footer.php");
  ?>
  </body>
</html>
