<!DOCTYPE html>
<?php
session_start();
include("ecaheader.php");
include ("sidebar.php");
?>

	<div id="content">
		<div class="content_item">

			<p><b> <U>NATIONAL ElECTION BOARD OF ETHIOPIA</U></b></p>
			<p>After the downfall of the Derg regime a Transitional Government was established. Based on the Charter of the Transitional
				Government an Electoral Commission was established by Proclamation number. 11/1984 E.C. In February 1984 E.C. the Electoral
				Commission conducted the election for transitional administration committee members at the Woreda and Kebele levels. In May of
				the same year it conducted elections for National, Regional and Woreda Councils.</P>

			<p>
				After the completion of its mission the Electoral Commission was replaced by the National Electoral Board of Ethiopia, which was
				established by Proclamation number 64/1985 E.C. The Board is accountable to the House of Peoples Representatives and is an independent
				and autonomous organ for conducting elections having its own legal personality. According to Article 6 of the  amended proclamation number
				532/1999 E.C. The broad  has nine members who are nominated by the Prime Minister and appointed by the House of Peoples Representatives.
				The composition of the Board Members has taken into consideration the national diversity, gender representation and includes legal professionals.</P>
			<B> Board Members must:</B>
			<p> <ul type="special">
				<li>Be loyal to the Constitution</li>
				<li>Be non-partisan</li>
				<li>Be professionally competent</li>
				<li> Be known for their good conduct</li></ul></P>

			<p>The Board has a Secretariat headed by one Chief Executive and two Deputy Chief Executives. The Chief Executive is accountable to the Board while the<BR>
				Deputy Chief Executives are accountable to the Chief Executive.</p>
			<p>
				The Board has permanent employees working at the head office and regional branch offices of the Secretariat. In addition it has temporary electoral officers<BR>
				recruited from various governmental and non-governmental organizations who assist the Board during elections. Currently the Board has 547constituencies and <BR>
				around 43,500 polling stations.</p>
			<p><B>Objectives</B><BR>

				The Board has the following objectives:-<BR>
			<ul type="1">
				<li> Ensure the establishment of a Government elected through free, fair, and impartial elections held in accordance with the Constitution.</li>
				<li>Ensure the existence of an electoral system that enables political parties and private candidates, which respect the constitution
					and institutions established by it, compete equally and impartially.</li>
				<li>Enable citizens to exercise their constitutional democratic right to elect and be elected.</li></ul>
			</p>

			<p>
				<b><u>Powers and Duties of the Board</u></b></p>

			<ul>
				<li>   Execute impartially any election and referendum conducted in accordance with the Constitution and the amended Proclamation numbers 532/1999 E.C.</li>
				<li> Facilitate and ascertain that elections held periodically and at every level are conducted in free and fair manner.</li>
				<li>Prepare and distribute documents and materials necessary for conducting elections.</li>
				<li>Widely provide to the public civic and voter education relating to election; issue license to other bodies engaged in civic and voter education;
					follow and supervise their activities.</li>
				<li>Issue licenses to election observers and follow and supervise their activities</li>
				<li>Register and issue licenses to political parties; follow up and supervise them in accordance with law.</li>
				<li>Recruit on permanent and temporary basis, competent and non partisan electoral officers required to conduct elections at every level.</li>
				<li>Evaluate the implementation of periodical elections and electoral laws, undertake studies, collect and compile statistical data, identify
					areas that need amendments and submit to concerned body, keep properly any electoral documents.</li>
				<li>Organize and coordinate political parties’ joint forum.</li>
				<li>Investigate, cancel election results, order re-election or order injunction of the act and bring perpetrator before the court of law where it has
					received information about violation of law in the election process, fraudulent act or disturbance of peace and order of such magnitude and type which would
					determine the outcome of election from political organization running for election, private candidates, observers, electoral officers or any other sources.</li>
				<li>Certify and officially announce election results.</li></ul>



			<p><b><u>Elections executed by the Board since 1986 E.C.</u></b></p>

			<p>Since its establishment NEBE has held three general elections. Besides these the board has held re-election, by election, local election and referendum.
				Currently the board is undertaking tremendous preparations for the upcoming 2010 general election.
			</p>
		</div></div></div>
<?php
include("../footer.php");
?>
</body>
</html>
