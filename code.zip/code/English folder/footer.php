
<div id="content_green">
	  <div class="content_green_container_box">
		<h4>Latest Post</h4>
	    <p> Hawassa University is a public university in the SNNPR's of Ethiopia.</p>
		<div class="readmore">
		  <a href="#">Read more</a>
		</div>
	  </div>
      <div class="content_green_container_box">
       <h4>Follow Us</h4>
            <div class="footer_social_button">
                <a href="#"><img src="../image/facebook.png" title="facebook" alt="facebook" /></a>
				<a href="#"><img src="../image/twitter.png" title="twitter" alt="twitter" /></a>
                <a href="#"><img src="../image/gmail.png" title="gmail" alt="gmail" /></a>
                <a href="#"><img src="../image/youtube.png" title="youtube" alt="youtube" /></a>
			</div>
	  </div>
      <div class="content_green_container_boxl">
			<h4>Latest Election News</h4>
			<p> Ethiopia is one of developing country in east africa.</p>
			<div class="readmore">
			  <a href="#">Read more</a>
			</div> 
	  </div>    
	  <div class="content_green_container_boxl">
			<h4>Latest News</h4>
			<p>Ethiopia is one of developing country in east africa.</p>
			<div class="readmore">
			  <a href="#">Read more</a>
			</div>
		</div>   
    </div> 
<div id="footer_container">
    <div id="footer">
	<p>
				&copy 2016 by TEGBARU,ALEHEGN,TEWABE AND YIDEG. All Rights Reserved !!!
		</p>
	
    </div>
</div>  