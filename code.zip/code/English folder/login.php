
<!DOCTYPE html>
<?php
session_start();
?>
<html lang="en">
  <head>
	  <?php
	  include ("headerfile.php");
	  ?>
      <script type="text/javascript" src="js/login.js"></script>
 <STYLE TYPE="text/css">
 #contact form {
	background: #ccc url(../image/mainback.jpg) repeat;
margin:auto;
position:relative;
width:580px;
height:230px;
font-family: ;
font-size: 14px;
font-style: italic;
line-height: 24px;
font-weight: ;
color: black;
text-decoration: none;
-webkit-border-radius: 10px;
-moz-border-radius: 10px;
border-radius: 10px;
padding:10px;
border: 1px solid #99779;
border: inset 0px solid #333;
-webkit-box-shadow: 0px 0px 20px rgba(0, 0, 0, 1.9);
-moz-box-shadow: 0px 0px 28px rgba(0, 0, 0, 1.9);
box-shadow: 0px 0px 28px rgba(0, 0, 0, 1.9)
}
#site_content
{
    padding: 0px;
	width: 1300px;
	height:600px;
	overflow: hidden;
	margin:10px auto;
	text-align:left;
	background:#ccc url(../image/mainback.jpg) repeat;
	border:5px solid green;
}
</style>
  </head>
  <body>
<div id="site_content">
<div class="sidebar_container1">       
	<div class="sidebar">
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of ETHIOPIA</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of democracy</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of election</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">Past Election in Ethiopia</a></span>
	</div>
	</div>
	<div class="sidebar_container2">       
	<div class="sidebar">
			<p><font size="3pt"> </u><b>Election</b></u></p>
	<ul>	
<p><li><a href="#">past election in ethiopia</a></p>…</font>
   <ul>
<p><li><a href="#">the 2005 ethiopian election</a></p>…</font></li>
<p><li><a href="#">the 2010 ethiopian election</</a></p>…</font></li>
<p><li><a href="#">the 2015 ethiopian election</</a></p>…</font></li></ul></li>
<p><li><a href="#">structure of past ethiopian Government</a></p>…</font>
<ul><p><li><a href="#">zemene mesafinit</a></p>…</font></li>
<p>Between 1755 to 1855, Ethiopia experienced a period of isolation referred to as the Zemene Mesafint or "Age of Princes". The Emperors became figureheads.</<a href="#">read more</a>
</p>
<p><li><a href="#">Ethiopia 1855-1991</a></p>…</font></li>
<p>
The Emperor of Ethiopia was refered to as Niguse Negest (King of Kings) and Atse (Emperor).This time pass through  emperor Tewodros II,emperor Yohanis IV,
emperor minilik II,lij Eyasu, Zewditu ,emperor H/silasie and derue<a href="#">read more </a>
</p>
<p><li><a href="#">EFDRE </a></p>…</font></li></ul>
</li>
<p>

</p>
</ul>
	</div>
	</div>
	<div id="content">
<div class="content_item">
					<b>
					
						<div id="contact" background="green">
							<form name = "RegistrationForm" action ="loginpage.php" method="POST" onsubmit = "return login(this.form);">
<table>
								 <tr >
								 <td rowspan=3><img src="image/kkk.gif" height="100px" width="130px"/></td>
								 <td align="center">Login As</td>
								 <td><select id="type" class = "contactFormInput"  name = "type" value = "" onchange="validateAccounttype(this.options[this.selectedIndex].value);">
								         <option value = "0"selected = "selected">-select your account type-</option>
										 <option value="1" >Election Officer</option>
										 <option value="2" >Party</option>
										 <option value="3" >candidate</option>
										 <option value="4" >Voter</option>
										 </select>
										 </td>
										 <td><label id = "typeprompt"></label> </td>
										</tr>
										
										<tr>
								  <td align="center">user name</td>
								  <td><input type="text" id="user_name" name="user_name" class="contactFormInput"class="txtfield"  required></td></tr>
								 <tr><td align="center"> Password:</td>
								 <td><input type="password" id ="pass"  name ="pass" class="contactFormInput" class="txtfield" required> </td></tr>
								  <tr><td>
								  </td><td align="right"><button type="submit" id="log" name="log"><font color="blue" size="4pt">LOGIN</font></td></tr>
								
										</table></form>
				</div>
			</div>
	</div>
	</div>
  <?php
  include("footer.php");
  ?>
  </body>
</html>