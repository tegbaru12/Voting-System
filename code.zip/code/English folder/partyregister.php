<!DOCTYPE html>
<html lang="AM">
  <head>
	  <?php
	  session_start();
	  include ("headerfile.php");
	  ?>
<script type="text/javascript" src="js/validatePart_form.js"></script>
    <STYLE TYPE="text/css">
#site_content
{ 
    padding: 0px;
	width: 1200px;
	height:900px;
	overflow: hidden;
	margin:80px auto;
	text-align:left;
	background:#ccc url(../image/mainback.jpg) repeat;
	border:2px solid green;
}
</style>
	  <?php
	  include ("sidebar.php");
	  ?>
	  <div id="content">
<div class="content_item">
					<b>
						<div id="contact" class="body">
							<form name = "PartForm"  enctype="multipart/form-data" action ="party.php" method="POST" onsubmit = "return validateParRegisterForm(this.form);">
							<fieldset>
								<legend align="center"><font color="blue" size="5pt">POLETICAL PARTY REGISTRATION FORM</font></legend>
								<table >
									<tbody  > 
										<tr>
											<td align ="center">Party Name:</td>
											<td><input id = "p_Name" name="p_Name" class = "contactFormInput" type="text" class="txtfield" placeholder = "Party name here" onblur = " validateP_Name()"required></td>
										<td><label id = "PNamePrompt"></label> </td>
										</tr>
										<tr>
											<td align ="center">Party Identity code(name abrevation):</td>
											<td><input id = "party_identity" name="party_identity" class = "contactFormInput" type="text" class="txtfield" placeholder = "Name abrevation here"  onblur = "validateP_code()" ></td>
										<td><label id = "Party_codePrompt"></label> </td>
										</tr>
										<tr>
											<td align ="center">Party symbol name:</td>
											<td><input id = "sym_name" name="sym_name" class = "contactFormInput" type="text" class="txtfield" placeholder = "symbol name here"  onblur = " validatesympnmae()" required></td>
										<td><label id = "symbnameprompt"></label> </td>
										</tr>
										<tr>
											<td align ="center">Part symbol:</td>
											<td><input id = "logo" name="logo" class = "contactFormInput" type="file" accept="image/gif, image/jpeg, image/png,image/jpg" class="txtfield" placeholder = ""  onblur = "validateLogo()" required></td>
										<td><label id = "LogoPrompt"></label> </td>
										</tr>
										<tr>
											<td align ="center">Party representative name</td>
											<td><input id = "party_rep_name" name="party_rep_name" class = "contactFormInput" type="text" class="txtfield" placeholder = "representaive name"  onblur = " validateName()"required></td>
										<td><label id = "repnamePrompt"></label> </td>
										</tr>
										<tr>
											<td align ="center">party representative profession</td>
											<td ><select id = "party_rep_pro" class = "contactFormInput"  name = "party_rep_pro" value = "" onchange = " validateprofession(this.options[this.selectedIndex].value)">
											<option value="0" selected></option>
											<option value="BSC">BSC</option>
											<option value="MSC">MSC</option>
											<option value="PHD">PHD</option>
											</select>
											</td>
										<td><label id = "canproPrompt"></label> </td>
										</tr>
										<tr>
											<td align ="center">Social security code:</td>
											<td><input id = "rep_ssn" name="rep_ssn" class = "contactFormInput" type="text" class="txtfield" placeholder = "Identity code"  onblur = " validate_ssn()"required></td>
										<td><label id = "ssnPrompt"></label> </td>
										</tr>
										<tr>
										
											<td align="right">Sex:</td>
											<td>
												<input  id = "v-Sex" class = "contactFormInput"  type = "radio" name = "V-sex" value = "male" onkeyup = "return validateSex()"required> Male
												<input  id = "v-Sex" class = "contactFormInput"  type = "radio" name = "V-sex" value = "female" onkeyup = "return validateSex()"required> Female
											</td>
										<td><label id = "contactSexPrompt"></label> </td>
										</tr>
										<tr>
											<td align="right">Age</td>
											<td><script language="JavaScript">
                                            document.write("<select id='ca_age' class='contactFormInput' name='ca_age' onchange='validatecanage(this.options[this.selectedIndex].text)' required>" );
															for (var i=0; i <=110; i++)
															{
																document.write("<option value="+i+">" + i + "</option>");
																

															}
															document.write("</select>");
															</script>
													</td>
													
												<td><label id = "agePrompt"></label> </td>	
											</tr>
										<tr>	
										<td align="right">Nationality:</td>
											<td ><select id = "Nationality" class = "contactFormInput"  name = "Nationality" value = "" onchange = "  validateNationality(this.options[this.selectedIndex].value)">
											<option value = "0" >--select your country---</option>
												<option value = "Ethiopia">Ethiopia</option>
													<option value = "Kenya">Kenya</option>
													<option value = "sudan">sudan</option>
													<option value = "USA">USA</option>
													<option value = "Ertira">Ertira</option>
													<option value = "Egypt">Egypt</option>
													</select>
													</td>
													<td><label id = "nationpropmt"></label> </td>
												</tr>
												<tr>	
											<td align="right">Region:</td>
											<td><select id = "region" class = "contactFormInput"  name = "region" value = "" onchange= "validateRegion(this.options[this.selectedIndex].value)"  >
											<option value = "0">--select your Region---</option>
												<option value = "Amhara">Amhara</option>
													<option value = "oromo">oromo</option>
													<option value = "Tigray">Tigray</option>
													<option value = "SNNPR">SNNPR</option>
													<option value = "Afar">Afar</option>
													<option value = "Sumali">Sumali</option>
													<option value = "Beshangul Gumz">Beshangul Gumz</option>
													<option value = "Addiss Abeba">Addiss Abeba</option>
													<option value = "Gambela">Gambela</option>
													<option value = "Harari">Harari</option>
													<option value="DireDawa">DireDawa</option>
													
													</td>
														</td><td><label id = "canregionPrompt"></label> </td>
											</select>
										</tr>
										<tr>
											<td align="right">Zone:</td>
											<td><select id = "zone" class = "contactFormInput"  name = "zone" value = "" onchange= "validatezone(this.options[this.selectedIndex].value)"  >
											<option value="-1" >Zone</option>
											<script language="javascript">
											function validateRegion(x)
											{
									
										if(x=="0")
										{
											jsShow("canregionPrompt");
											producePrompt("please select region ", "canregionPrompt", "orange");
											return false;
										}
										var amh=["Agew Awi","East Gojjam","North Gondar","North Shewa","North Wollo","Oromia","South Gondar","South Wollo","WagHemra","West Gojjam","Bahir Dar"];
										var orm=["Arsi","Bale","Borena","East Hararge","East Shawa","East Wallagga","Guji Zone|Guji","Horo Guduru WallaggaZone","Illubabor Zone","Jimma Zone|Jimma]]","Kelem Wallagga","North Shawa","South West Shawa","West Arsi","West Hararge","West Shawa",
										  "West Wallagga zone","Adama","Jimma","Oromiya-Finfinne"];
										var tg=["Central Tigray","East Tigray","North West Tigray","South Tigray","South East Tigray","West Tigray","Mekele" ];
										var sou=["Bench Maji","Dawro","Gamo Gofa","Gedeo","Gurage","Hadiya","Keffa","Keficho"," Shekicho**","Kembata Tembaro","North Omo*","Sheka","Sidama","Silti","South Omo","Wolayita"
											,"Alaba","Amaro","Basketo", "Wolayita","Burji","Dirashe","Konso","Konta","Yem "];
										var af=["Administrative Zone 1 (a.k.a. Awsi Rasu)","Administrative Zone 2 (a.k.a. Kilbet Rasu)","Administrative Zone 3 (a.k.a. Gabi Rasu)","Administrative Zone 4 (a.k.a. Fantena Rasu)",
										"Administrative Zone 5 (a.k.a. Hari Rasu)","Argobba (special woreda)"];
										var suma=["Afder","Degehabur","Fiq","Gode","Jijiga","Korahe","Liben","Shinile","Werder"];
										var gam=["Anuak","Mezhenger","Nuer"];
										var besh=["Asosa","Kamashi","Metekel"];
										var dire=["Dire Dawa"];
										var addis=["Addiss Abeba"];
										var har=["Harari"];
										var i;
										if(x=="Amhara")
										{
										var am=document.getElementById("zone");
										var option=new Array(amh.length);
										for(i=0;i<amh.length;i++)
										{
										option[i]= document.createElement("option");
										option[i].text=amh[i];
										option[i].value=amh[i];
										 am.add(option[i]);
											
										}
										}
										var i;
										if(x=="oromo")
										{
										var or=document.getElementById("zone");
										var option=new Array(orm.length);
										for(i=0;i<orm.length;i++)
										{
										option[i]= document.createElement("option");
										option[i].text=orm[i];
										option[i].value=orm[i];
										 or.add(option[i]);
											}
										}
										if(x=="Tigray")
										{
										var t=document.getElementById("zone");
										var option=new Array(tg.length);
										for(i=0;i<tg.length;i++)
										{
										option[i]= document.createElement("option");
										option[i].text=tg[i];
										option[i].value=tg[i];
										  t.add(option[i]);
											
											}
										}
										if(x=="SNNPR")
										{
										var t=document.getElementById("zone");
										var option=new Array(sou.length);
										for(i=0;i<sou.length;i++)
										{
										option[i]= document.createElement("option");
										option[i].text=sou[i];
										option[i].value=sou[i];
										  t.add(option[i]);
										}
									}
									if(x=="Afar")
									{
										var t=document.getElementById("zone");
										var option=new Array(af.length);
										for(i=0;i<af.length;i++)
										{
										option[i]= document.createElement("option");
										option[i].text=af[i];
										option[i].value=af[i];
										  t.add(option[i]);
										}
									}
								 if(x=="Sumali")
										{
										var t=document.getElementById("zone");
										var option=new Array(suma.length);
										for(i=0;i<suma.length;i++)
										{
										option[i]= document.createElement("option");
										option[i].text=suma[i];
										option[i].value=suma[i];
										  t.add(option[i]);
										}
									}
									if(x=="Beshangul Gumz")
										{
										var t=document.getElementById("zone");
										var option=new Array(besh.length);
										for(i=0;i<besh.length;i++)
										{
										option[i]= document.createElement("option");
										option[i].text=besh[i];
										option[i].value=besh[i];
										  t.add(option[i]);
										}
									}
									if(x=="Addiss Abeba")
										{
										var t=document.getElementById("zone");
										var option=new Array(addis.length);
										for(i=0;i<addis.length;i++)
										{
										option[i]= document.createElement("option");
										option[i].text=addis[i];
										option[i].value=addis[i];
										  t.add(option[i]);
										}
									}
									if(x=="Gambela")
										{
										var t=document.getElementById("zone");
										var option=new Array(gam.length);
										for(i=0;i<gam.length;i++)
										{
										option[i]= document.createElement("option");
										option[i].text=gam[i];
										option[i].value=gam[i];
										  t.add(option[i]);
										}
									}
									if(x=="Harari")
										{
										var t=document.getElementById("zone");
										var option=new Array(har.length);
										for(i=0;i<har.length;i++)
										{
										option[i]= document.createElement("option");
										option[i].text=har[i];
										option[i].value=har[i];
										  t.add(option[i]);
										}
									}
									if(x=="DireDawa")
										{
										var t=document.getElementById("zone");
										var option=new Array(dire.length);
										for(i=0;i<dire.length;i++)
										{
										option[i]= document.createElement("option");
										option[i].text=dire[i];
										option[i].value=dire[i];
										  t.add(option[i]);
										}
									}
									jsShow("zonePrompt");
										producePrompt("ok  " , "zonePrompt", "green");
										setTimeout(function(){jsHide("zonePrompt");}, 2000);
										return true;
									}
											
											</script>
											</select>
													</td>
													<td><label id = "canzonePrompt"></label> </td>
											</tr>
												<tr>	
										<td align="right">Woreda:</td>
											<td>
											<select id="woreda" class="contactFormInput" name="woreda" onchange=" validateWoreda(this.options[this.selectedIndex].value)" onmouseover="selectworeda(this.options[this.selectedIndex].value)" required> 
											<option value="-1">-----select woreda--</option>
											</select>
											<script language="JavaScript">
									 function selectworeda(x)
									 {
									    
										 var wo=["Ababo", "Ab Ala", "Abaya", "Abay Chomen","Abe Dongoro "," Abergele"," Abeshege","Abichuna Gne'a","Abobo","Abuna Gindeberet","Adaa'r","Ada'a",
														"Adaba","Adadle"," Adama","Adami Tulu Jido Kombolcha ","Adda Berga","Addi Arekay","Addis Ketema","Adola","Adwa","Afambo","Afdem","Afder",
														"Afdera","Afele Kola (Dima)","Agalometi","Agarfa","Ahferom","Akaki","Akaki - Kalit","Akobo","Alaba","Alaje","Alamata","Albuko","Ale",
														"Aleltu","Alem Gena","Aleta Wendo","Alfa","Alge Sachi","Alicho Woriro","Alle","Amaro","Ambasel","Ambo Zuria","Ameya","Amibara","Amigna",
														"Amuru","Analemmo","Anchar","Anderacha","Aneded","Anfilo","Angolelana Tera","Anigacha","Ankasha","Ankober","Antsokiya","Arada","Arba Minch Zuria",
														"Arbe Gonna","Arero","Argoba","Argoba Liyu","Aroresa","Arsi Negele","Artuma","Artuma Fursi","Aseko","Asgede Tsimbila","Assagirt","Assosa","Atsbi Wenberta",
														"Awabel","Aware","Awash Fentale","Awra","Ayida","Ayira Guliso","Ayisha","Aysaita","Babile","Babile","Babo","Badele Zuria","Bahirdar Zuria","Bako Tibe",
														"Bambasi","Banja","Bare","Basketo","Baso Liben","Basona Worena","Bati","Becho","Bedeno","Begi","Bele Gesgar","Bena Tsemay","Bensa","Berahle",
														"Berbere","Bereh","Berehet","Bero","Beyeda","Bibugn","Bidu","Bila Seyo","Bilidigilu","Bilo Nopha","Bio Jiganifado","Bita (Big)","Boh","Boji Chekorsa",
														"Boji Dirmeji","Boke","Bole","Boloso Bombe","Boloso sore","Bona Zuria","Boneya Boshe","Bonke","Bora","Bore","Borecha",
														"Boreda","Boricha","Boset","Bugna","Bule","Bule Hora","Bulen","Bure","Bure Mudaytu","Burji","Bursa","Chefa Gula","Cheha",
														"Cheliya","Chena","Chencha","","Chereti/Weyib","Cheta","Chifra","Chilga","Chinaksen","Chire","Chiro Zuria","Chole","Chora",
														"Chuko","Chwaka","Dabat","Dabo Hana","Dale","Dale Sadi","Dale Wabera","Dalocha","Dalul","Damot Gale","Damot Pulasa","Damot Sore",
														"Damot Weydie","Dangila","Dangura","Daniboya","Dano","Danot","","Dara","Daramalo","Darimu","Daro Lebu","Dasenech (Kuraz)",
														"Dawe Kachen","Dawo","Dawunt","Debark","Debay Telatgen","Debeweyin","Debre Elias","Debre Libanos","Debresina","Debub Achefer","Debub Bench",
														"Decha","Deder","Dedesa","Dedo","Dega","Dega Damot","Degehabur","Degehamedo","Degeluna Tijo","Degem","Degua Temben","Dehana","Dehas",
														"Dejen","Delanta","Dembecha","Dembel","Dembia","Denan","Dendi","Denibu Gofa","Dera","Derashe","Dessie Zuria","Dewa Harewa",
														"Dewe","Dibat","Didu","Diga","Diguna Fango","Dihun","Diksis","Dila Zuria","Dillo","Dima","Dinsho","Dire","Dire Dawa",
														"Dire Dawa/Town","Dita","Doba","Dodola","Dodota","Dolobay","Dolo Odo","Dorani","Doya Gena","Dubti","Dugda","Dugda Dawa","Dulecha","Dune",
														"East Belesa","East Esite","East Imi","Ebenat","Eferatana Gidem","Ejere (Addis Alem)","Ela (Konta) ","Elidar","Enarj Enawga",
														"Enbise Sar Midir","Endamehoni","Enderta","Endiguagn","Enemay","Enemorina Eaner","Ensaro","Erebti","Erer","Erob","Esira",
														"Etang","Ewa","Ezha","Fagta Lakoma","Farta","Fedis","Fentale","Ferfer","Fik","Filtu","Fogera","Fursi","Gaji","Gambela Zuria",
														"Ganta Afeshum","Gasera","Gawo Kebe","Gaz Gibla","Gechi","Gedeb Asasa","Geladin","Gelana","Gelila (Semen Ari)","Gembora",
														"Gemechis","Gena Bosa","Gera","Gerar Jarso","Gerbo","Gesha (Deka)","Geta","Getawa","Gewane","Geze Gofa","Gibe","Gida Kiremu",
														"Gidami","Gidan","Gimbi","Gimbichu","Gimbo","Ginde Beret","Ginir","Girawa","Girja (Harenfema)","Gishe Rabel","Gnangatom","Goba",
														"Goba Koricha","Gobu Seyo","Gode","Godere","Goge","Gololcha Arsi","Gololcha Bale","Golo Oda","Goma","Goncha Siso Enese","Gonder Zuria",
														"Gonje","Gorche","Goro","Goro","Goro Baqaqsa","Goro Gutu","Guagusa Shikudad","Guangua","Guba","Guba Lafto","Gudetu Kondole",
														"Guduru","Gulele","Gulina","Gulomekeda","Gumay","Gumer","Guna","Gunagado","Guradamole","Gura Damole","Gurafereda","Gursum",
														"Gursum","Guto Gida","Guzamn","Habro","Habru","Hadero Tubito","Hagere Mariam","Halu (Huka)","Hambela Wamena","Hamer","Hamero",
														"Harar","Harena Buluk","Hareshen","Hargele","Haro Limu","Haro Maya","Haru","Hawa Galan","Hawasa Town","Hawassa Zuria",
														"Hawi Gudina","Hawzen","Hidabu Abote","Hintalo Wejirat","Hitosa","Homosha","Horo","Hudet","Hulet Ej Enese","Hulla","Humbo","Hurumu",
														"Ibantu","Ifata","Ilu","Inkolo Wabe","Jabi Tehnan","Jama","Janamora","Jarso","Jarso","Jarte Jardega","Jawi",
														"Jeju","Jeldu","Jibat","Jida","Jijiga","Jikawo","Jille Timuga","Jimma Arjo","Jimma Genete","Jimma Horo","Jimma Rare","Jore","Kacha Bira",
														"aKalu","Kamashi","Kebena","Kebribeyah","Kebridehar","Kediada Gambela","Kelafo","Kelela","Kelete Awelallo","Kemba","Kembibit","Kercha","Kersa","Kersa","Kersana Malima","Kewe","Kiltu Kara","Kindo Dida","Kindo Koysha","Kirkos-Kobo","Kochere","Kochere Gedeb","Kofele","Kokir Gedbano","Kokir Gedbano","Kokosa","Kola Temben","Kolfe - Keran","Kondaltiti","Koneba","Kore","Kucha","Kuni","Kurfa Chele","Adiyabo","Kurmuk","Kurri","Kutaber","Kuyu","Laelay","Laelay Maychew","Lagahida","Lalo Asabi"
														,"Lalo Kile","Lanfero","Lare","Lasta (Ayna)","Lay Armacho","Lay Gayint","Legambo","Legehida","Lege Hida","Leka Dulecha","Liben","Liben Chukala","Libo Kemkem","Lideta-Limu","Limu","Limu Bilbilo","Limu Kosa","Limu Seka","Loka-Abaya","Loma Bosa","Lome","Lude Hitosa","Maji","Male","Malga","Malka Balo","Mana Sibu","Maokomo Special","Mareka","Mareko","Masha","Mecha",
														"Meda Welabu","Medebay Zana","Megale","Mehal Sayint","Mekdela","Meket","Meko","Melekoza","Melka Soda","Mena","Mena","Menge","Mengesh","Menit Goldiye","Menjiwo","Menz Gera Midir","Menz Keya Gabriel"
														,"Menz Lalo Midir","Menz Mama Midir","Merahbete","Mereb Leke","Merti","Mesela","Meskan","Meta","Meta Robi","Metema","Metu Zuria","Meyu","Meyumuluka","Michakel","Mida Kegn",
														"Midega Tola","Mierab Azenet Berbere","Mierab Badawacho","Mieso","Mile","Mimo Weremo","Minjar Shenkora","Mirab Abaya","Mirab Armacho","Misha","Misrak Azenet Berbere","Misrak Badawacho","Misrak Gashamo","Miyo","Mojan Wedera","Moretna Jiru","Moyale","Muhur Na Aklil","Mulo","Munessa","Mustahil","Naeder Adet","Nefas Silk","Nejo","Nenesebo (Wereka)","Nole Kaba",
														"Nono","Nunu Kumba","Odo Shakiso","Ofa","Ofla","Omo Nada","Pawe Special","Quara","Quarit","Raya Azebo","Rayitu","Robe","Saesie Tsaedaemba","Saharti Samre","Sahla","Sale Nono","Sankura","Sasiga","Sayilem","Sayint","Sayo","Sayo Nole","Seden Sodo","Segeg",
														"Seka Chekorsa","Sekela","Sekoru","Sekota","Selahad","Selamgo","Selti","Semen Achefer","Semen Bench","Senan","Serer/Elkere","Seru","Setema","Seweyna","Shalla","Shashemene Zuria","Shashogo",
														"Shay Bench","Shebe Dino","Shebel Bereta","Shebe Sambo","Sheka","Shekosh","Sherkole","Shilabo","Shinile","Shirka","Sibu Sire",
														"Sigmo","Simada","Simurobi Gele'alo","Sinana","Siraro","Sirba Abay","Sire","Siya Debirna Wayu","Sodo","Sodo Daci","Sodo Zuria","Soro","South Ari (Bako Gazer)",
														"Sude","Sululta","Surma","Tach Armacho","Tach Gayint","Tahtay Adiyabo","Tahtay Koraro","Tahtay Maychew",
														"Takusa","Tanqua Abergele","Tarema Ber","Teferi Ber","Telalak","Teltele","Tembaro","Tena","Tenta","Teru","Thehulederie","Tikur Enchini","Tiro Afeta","Tiyo",
														"Tocha","Toke Kutaye","Tole","Tsegede","Tselemt","Tselemti","Tulo","Ubadebretsehay","Uraga","Wadera","Wadla","Waliso","Walmara","Wama Hagalo","Wantawo","Wara Jarso",
														"Warder","Wayu Tuka","Wegde","Welkait","Wemberma","Wenago","Wenbera","Wenchi","Werei Leke","Were Ilu","West Belesa","West Esite","West Imi","Wilbareg","Wondo-Genet",
														"Wonosho","Worebabu","Wuchale","Yabelo","Yalo","Yama Logi Welel","Yaso","Yaya Gulele","Yayu","Yeka","Yeki","Yem Special","Yilmana Densa","Yirgachefe","Yubdo","Zala","Ziquala","Ziway Dugda"];
													   var t=document.getElementById("woreda");
													  var option=new Array(wo.length);
														for(i=0;i<wo.length;i++)
														 {
														 option[i]= document.createElement("option");
														option[i].text=wo[i];
														option[i].value=wo[i];
													   t.add(option[i]);
														}
										   return true;
									        }

											</script></td>
										<td><label id = "canwereaPrompt"></label> </td>
										</tr>
										<tr>
											<td align ="center">E-mail:</td>
											<td><input id = "email" name="email"  class = "contactFormInput" type="text" value="" class="txtfield" placeholder = "representative e-mail"  onblur = "validaterepemail()"></td>
											 <td><label id = "caemilPrompt"> </label></td>
										</tr> 
										<tr>
											<td align ="center">Phone_number:</td>
											<td><input id = "pho_num" name="pho_num"  class = "contactFormInput" type="text" value="" class="txtfield" placeholder = "representative phone number"  onblur = " validaterepone()"></td>
											 <td><label id = "phonePrompt"> </label></td>
										</tr>
										<tr>
											<td align ="center">User Name:</td>
											<td><input id = "User_name" name="user_name" class = "contactFormInput" type="text" class="txtfield" placeholder = "Give user name" onblur = " validateUsername()" required></td>
										<td><label id = "UserNamePrompt"></label> </td>
										</tr>
											<tr>
											<td align ="center">Password:</td>
											<td><input id = "password" name="password" class = "contactFormInput" type="password" class="txtfield" placeholder = "Password" onblur = " validatePassword()"required></td>
										<td><label id = "PasswordPrompt"></label> </td>
										</tr>
											<tr>
											<td align ="center">Re  type password:</td>
											<td><input id = "re_pasword" name = "re_pasword"class = "contactFormInput" type="password" class="txtfield" placeholder = "re enter password" onblur = " validateRePassword()"required></td>
										<td><label id = "re_passowrdPrompt"></label> </td>
										</tr>
										   <tr>
											   <td align="center"> Atach your personality</td>
											   <td><input type="file" id="cv" accept="text/plain,application/pdf,application/vnd.ms-powerpoint,application/msword,application/vnd.ms-excel" name="cv" style="widtth:90px;" required> </td>
										   </tr>
											<tr>
											<td></td>
											<td align="center"><button type = "submit" id="reg" ><strong> Register </strong></button> </td>
										<td><button type = "reset" onclick = "" ><strong> Reset </strong></button> </td>
										</tr>
										<tr>
										<td>
										</td>
										<td align ="center"><label id="suc"> </td>
										</tr>
									</tbody>
								</table>
								</fieldset>
							</form>
				</div>
			</div>
	</div>
	</div>
	  <?php
	  include ("footer.php");
	  ?>
  </body>
</html>
