<?php
/**
 * Created by PhpStorm.
 * User: alexo
 * Date: 5/27/2016
 * Time: 12:53 AM
 */
session_start();
include ("voterheade.php");
?>
<style type="text/css" xmlns="http://www.w3.org/1999/html">
#site_content
{
padding: 0px;
overflow: hidden;
margin:10px auto;
text-align:left;
border:5px solid green;
}
#content
{
    border: none;
    padding: 5px;
    width: 700px;
    margin: px 0px 1px 0px;
    margin-left:220px;
    float: left;
    position:absolute;
}
#contact form {
    background: #f2f5f5;
    margin:auto;
    position:relative;
    width:680px;
    height:5000px;
    font-family: ;
    font-size: 14px;
    font-style: italic;
    line-height: 24px;
    padding-top: -10px;
    color: black;
}
#contact form table {
    width:650px;
    position: relative;
}
</style>
<div id="site_content">

    <div class="sidebar_container1">
        <div class="sidebar">
            <a href="#"><span style="color: blue;font-size: 12pt;">History of ETHIOPIA</a></span><br>
            <a href="#"><span style="color: blue;font-size: 12pt;">History of democracy</a></span><br>
            <a href="#"><span style="color: blue;font-size: 12pt;">History of election</a></span><br>
            <a href="#"><span style="color: blue;font-size: 12pt;">Past Election in Ethiopia</a></span>
        </div>
    </div>
    <div class="sidebar_container2">
        <div class="sidebar">
            <p><font size="3pt"> </u><b>Election</b></u></p>
            <ul>
                <p><li><a href="#">past election in ethiopia</a></p>…</font>
                <ul>
                    <p><li><a href="#">the 2005 ethiopian election</a></p>…</font></li>
                    <p><li><a href="#">the 2010 ethiopian election</</a></p>…</font></li>
                    <p><li><a href="#">the 2015 ethiopian election</</a></p>…</font></li></ul></li>
                <p><li><a href="#">structure of past ethiopian Government</a></p>…</font>
                <ul><p><li><a href="#">zemene mesafinit</a></p>…</font></li>
                    <p>Between 1755 to 1855, Ethiopia experienced a period of isolation referred to as the Zemene Mesafint or "Age of Princes". The Emperors became figureheads.</<a href="#">read more</a>
                    </p>
                    <p><li><a href="#">Ethiopia 1855-1991</a></p>…</font></li>
                    <p>
                        The Emperor of Ethiopia was refered to as Niguse Negest (King of Kings) and Atse (Emperor).This time pass through  emperor Tewodros II,emperor Yohanis IV,
                        emperor minilik II,lij Eyasu, Zewditu ,emperor H/silasie and derue<a href="#">read more </a>
                    </p>
                    <p><li><a href="#">EFDRE </a></p>…</font></li></ul>
                </li>
                <p>
                </p>
            </ul>
        </div>
    </div>
    <div id="content">
                <div id="contact" background="green">
                    <form action="#" name="add" enctype="multipart/form-data" method="POST">
    <?php
        $localhost = "localhost";
        $dbuser = "root";
        $dbpass = "";
        $dbname = "ovs";
        $con = mysql_connect($localhost, $dbuser, $dbpass);
        if (!$con) {
            die("Coudn't connect to the server");
        }
        $db_select = mysql_select_db($dbname, $con);
        if (!$db_select) {
            die("db is not selected" . mysql_error());
        }
                        $qry="SELECT *FROM video ORDER BY id DESC ";
                        $resul=mysql_query($qry);
                        while($row=mysql_fetch_row($resul))
                        {
                            echo$row[3];
                            echo'<br>';
                            echo" <embed src='$row[2]' width='560' height='315'></embed>";
                            echo'<br>';
                            echo$row[1];
                            echo'<br>';
                        }
                        $qr="SELECT *FROM photos ORDER BY id DESC ";
                        $result=mysql_query($qr);
                        while($row=mysql_fetch_row($result))
                        {
                            echo$row[3];
                            echo'<br>';
                            echo '<img src=" data:image;base64,'. $row[2].'" height="400" width="560" alt="image not found"/>';
                            echo'<br>';
                            echo$row[1];
                            echo'<br>';
                        }
                        ?>
                    </form>

        </div>
    </div>
</div>
<?php
include ("../footer.php");
?>
</body>
</html>
