
<!DOCTYPE html>
<?php
session_start();
include ("voterheade.php");
?>
<div id="site_content">		
	<div class = "slide_container">	
			<img width=" 1150" name ="slide" height="300" src="../image/a.jpg" />
			<script type="text/javascript">
			var image1 = new Image();
			image1.src="../image/aa.jpg";
			var image2 = new Image();
			image2.src="../image/aaa.jpg";
			var image3 = new Image();
			image3.src="../image/ac.jpg";
			var image4 = new Image();
			image4.src="../image/acc.jpg"
			var image5 = new Image();
			image5.src="../image/ff.jpg";
			var image6 = new Image();
			image6.src="../image/mi.jpg"
			var image7 = new Image();
			image7.src="../image/pep.jpg"
			var step=1;
            function slideit()
            {
                
                document.images.slide.src = eval("image"+step+".src")
                if(step<8)
                    step++
                else
                    step=1;
                setTimeout("slideit()",2500)
            }
            slideit();
         </script>
	<div id="advert">	
	          <marquee height="400px" behavior = "alternate" direction = "up" >
			  <image width="400px" height="400px" src="../image/tgr.jpg">
			   <a href="#"><span style="color: blue;font-size: 12pt;">Tgray people</a></span>
			  <a href="#"><span style="color: blue;font-size: 12pt;">Afar People</a></span>
			 <image width="400px" height="400px" src="../image/afa.jpg">
			 <a href="#"><span style="color: blue;font-size: 12pt;">Amhara People</a></span>
			 <image width="400px" height="400px" src="../image/amh.jpg">
			  <a href="#"><span style="color: blue;font-size: 12pt;">Oromo People</a></span>
			 <image width="400px" height="400px" src="../image/oro.jpg">
			 </marquee>
			 </marquee>
			 <marquee height="400px" behavior = "alternate" direction = "down" >
			  <image width="400px" height="400px" src="../image/dev1.jpg">
			 <image width="400px" height="400px" src="../image/dev2.jpg">
			 <image width="400px" height="400px" src="../image/dev3.jpg">
			 <image width="400px" height="400px" src="../image/dev4.jpg">
			 <image width="400px" height="400px" src="../image/hj.jpg">
			 <image width="400px" height="400px" src="../image/pro.jpg">
			 </marquee>
	</div>
	</div>
	<div class="sidebar_container1">       
	<div class="sidebar">
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of ETHIOPIA</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of democracy</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of election</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">Past Election in Ethiopia</a></span>
	</div>
	</div>
	<div id="content">
	<div class="content_item">
	<p><b><font size="3pt">International dimensions of free and fair elections vis-à-vis Ethiopia’s elections process</font></b></p>
	<p>Ethiopia, a country with more than 3000 years long history as independent state had never had an elected government till 1991. The worst thing 
	is that even the various leaders who ruled Ethiopia at different time were used to believe that democracy is a mistake.  For example, 
	Emperor Haileslasse who ruled Ethiopia from 1931 to 1975s used to believe “democracy can be harmful, a mistake”.
	<table><tr><td><font color ="red">Emperor Haile Selassie</font></td>
	<td><font color ="red">Mengistu Hailemariam</font></td>
	<tr><td><img width="200px" name "Emperor Haile Selassie" height="200px" src="../image/hail.jpg"/>
	</td><td><img width="200px" name "Emperor Haile Selassie" height="200px" src="../image/men.jpg"/></td></tr></table>
	</p>
	<p>Changes happen fast, however.  In 1991, following the demise of the military junta (Derg), EPRDF led government introduced and 
	practiced the concept of democracy.  EPRDF heartily determined that elections are one of the basic elements of the democratic rights, where the will of the people is the determining one to establish a government.
	Any government who comes to power out of election is illegitimate. Hence, for the first time in history, Ethiopia has been practicing ‘one of the largest democratic exercises in the African continent’. Consistent with the international law of elections, the country has declared its commitment for democracy via establishing Ethiopian Electorate Board through the endorsement of the House of Peoples’ 
	Representative (parliament) unlike other countries by the executive body, an independent body to conduct free and fair elections.
	</p>
	<p>
	Hereafter, more than 95% voters out of the eligible citizen for election have been registered; an evident how the people are determined to decide their fate via secret ballot
	in the last four national elections. This number of voters of Ethiopia is much bigger than that of USA whose 40% voters got registered every election.
	</p>
	<p>
	<b>The Constitution of the Federal Democratic Republic of Ethiopia clearly stipulates that:</b>
	</p>
	<p>
	Article 38 (1), the Constitution underlined that: "Every Ethiopian national [has the right] to  
	take part in the conduct of public affairs, directly and through freely chosen representatives".
	</p>
	<p>
	As Ethiopia is signatory to various International Laws, that ‘Election shall allow expression of the will of the people’ is its core principle clearly set in its constitution. In line 
	with the Ethiopian Constitutional principles, so far, it has conducted the 1st, 2nd, 3rd and the 4th National and Regional elections in 1995 and 2000, 2005, 2010 respectively. Since then,
	the people decided its fate through secret ballot boxes, thus the idea of ‘the will of the people’ has became practical. The 1st, 2nd elections though were conducted in the basis of free and 
	fair elections where weak opposition parties participated making it less exposed to the international community. It was for this reason that the world did not say much about Ethiopia’s election. 
	It was because of that Ethiopians were unfamiliar with such elections that led to comparatively passive competition among the various political parties. Arguably, the international criteria for 
	free and fair elections consistent with Ethiopian realities were applied fairly.
	</p>
	<p>
	On the basis of the constitution of the EFDR consistent with the International Election Law, the contesting parties were accessed with media coverage, rally rights, debating time, electoral campaign rights,
	and other basic enabling elements of conducting elections on equitable basis.</p>
	<p>
	At the request of the government of a sovereign state, the UN may undertake verification; still the electoral process is managed by a national electorate board. The 1992 and 1993 resolutions were both adapted 
	without a controversy vote, each recognizing that the fundamental responsibility for ensuring free and fair elections lies with governments. Consistent with the international practice, the Ethiopian government thus, 
	invited various international election observer teams, one of whom was the Carter Center, EU, AU etc though their observing and reporting style, intentionally or not, was somewhat different.
	</p>
	<p>
	Ethiopia is under massive preparation to conduct the fifth national election scheduled in May 21, 2015. More than 55 contesting political parties are registered and are seen in Medias presenting their agenda and 
	introducing to the people. Election campaigning and other means of election process are being conducted openly. Code of conduct of parties is ratified by parliament so that all parties must be guided equally.
	Such approach is acceptable internationally where it can manage election process and parties differences equally. Such practices worked well in Cambodia and other countries.  Close to 35 million (95% eligible 
	citizen took card) voters are registered.</p>
	<p>
	Ethiopia has managed to apply almost all international measurements of democracy and free and fair elections principles and has been practicing them fairly. The best way to justify if one was free and fair 
	election was not only using the principles on proper but how they were applied well on ground objectively. Thus, there are various cultural and political landscape and previous election experiences which can 
	vary from country to country. Ethiopia is obviously new practitioner and much desired things are left. But to be sure, the country is on the right track in this regard.
	</p>
	<p><center><a href="#">Prev</a>
	<a href="#">Next</a></center>
	</p>
	</div>
	</div>
	</div>
<?php
include ("../footer.php");
?>
  </body>
</html>
