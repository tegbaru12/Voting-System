<!DOCTYPE html>
<?php
session_start();
include("voterheade.php");
?>
<style type="text/css">
#site_content
{
padding: 0px;
width: 1300px;
height:600px;
overflow: hidden;
margin:10px auto;
text-align:left;
background:#ccc url(../image/mainback.jpg) repeat;
border:5px solid green;
}
</style>

<div id="site_content">	

<div class="sidebar_container1">       
	<div class="sidebar">
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of ETHIOPIA</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of democracy</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of election</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">Past Election in Ethiopia</a></span>
	</div>
	</div>
	<div id="content">
<div class="content_item">
	<b>
	<div id="contact" background="green">
	<form>
<?php
$localhost="localhost";
			$dbuser="root";
			$dbpass="";
			$dbname="ovs";
			$con=mysql_connect($localhost,$dbuser,$dbpass);
			if(!$con)
			{ 
			die("Coudn't connect to the server");
			}
			$db_select=mysql_select_db($dbname,$con);
			if(!$db_select)
			{
			die("db is not selected".mysql_error());
			}
$us=$_SESSION['login_voter'];
$wa="select *from voters where 	user_name='$us'";
 $resh=mysql_query($wa);
while ($rsd=mysql_fetch_row($resh))
{
	$voterid=$rsd[0];
}
	if(mysql_num_rows(mysql_query("select *from voted where v_id='$voterid'")))
	{
		echo"Warning ! you have already voted";
		exit;
	}
	$vot=1;
	$selecaname=$_POST['can'];
 $selecreg=$_POST['canr'];
	$sql="SELECT *FROM cand where C_name='$selecaname'";
	$resu=mysql_query($sql);
	if(!$resu)
	{
		echo "You have not vote for Fedral";
	}
	while($row=mysql_fetch_array($resu))
	{
		$pname=$row['party_name'];
		$region=$row['region'];
		$zone=$row['zone'];
		$woreda=$row['woreda'];
		if(mysql_num_rows(mysql_query("select *from vote where C_name='$selecaname'")))
		{
			$sel="select *from vote where C_name='$selecaname'";
			$res=mysql_query($sel);
			if(!$res)
			{
				echo"you have not vote for regional";
				exit;
			}
			while($ro=mysql_fetch_array($res))
			{
				$vot=$ro['vot'];
				$vot=$vot+1;
			}
			$so="update vote set vot='$vot' where C_name='$selecaname' ";
			if(mysql_query($so))
			{
				echo" YOU HAVE SUCCSSFULLY VOTE for FEDRAL!!!!";
			}
			else
			{
				echo'Error in vote';
			}
		}
		else{
			$so="INSERT INTO vote(party_name,C_name, region, zone, woreda, vot,subje) VALUES ('$pname','$selecaname','$region','$zone','$woreda','$vot',0)";
			if(mysql_query($so))
			{
				echo'you have successfully vote';
			}

		}
	}
$vot=1;
$sql="SELECT *FROM cand where C_name='$selecreg'";
$resu=mysql_query($sql);
if(!$resu)
{
	echo "You have not vote for regional";
	exit;
}
while($row=mysql_fetch_array($resu))
{
$pname=$row['party_name'];
$region=$row['region'];
$zone=$row['zone'];
$woreda=$row['woreda'];
if(mysql_num_rows(mysql_query("select *from vote where C_name='$selecreg'")))
{
	$sel="select *from vote where C_name='$selereg'";
	$res=mysql_query($sel);
	if(!$res)
	{
		echo'You have not vote for regional';
	}
	while($ro=mysql_fetch_array($res))
	{
		$vot=$ro['vot'];
		$vot=$vot+1;
	}
	$so="update vote set vot='$vot' where C_name='$selecreg' ";
	if(mysql_query($so))
	{
		echo" YOU HAVE SUCCSSFULLY VOTE !!!!";
	}
	else
	{
		echo'You have not vote for regional';
	}
}
else{
	$so="INSERT INTO vote(party_name,C_name, region, zone, woreda, vot,subje) VALUES ('$pname','$selecaname','$region','$zone','$woreda','$vot',1)";
	if(mysql_query($so))
	{
		echo'you have successfully vote for regional';
	}
}
$ins="INSERT INTO voted(v_id) VALUES ('$voterid')";
if(!mysql_query($ins))
{
	die ("some error occured".mysql_error());
}
?>
</form>
	</div>
	</div>
	</div>
	</div>
<?php
include ("../footer.php");
?>
  </body>
</html>
