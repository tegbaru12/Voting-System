<!DOCTYPE html>
<?php
session_start();
include("voterheade.php");
?>

<div id="site_content">	

<div class="sidebar_container1">       
	<div class="sidebar">
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of ETHIOPIA</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of democracy</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of election</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">Past Election in Ethiopia</a></span>
	</div>
	</div>
	<div id="content">
<div class="content_item">
	<b>
	<div id="contact" background="green">
	<form name = "RegistrationForm" action ="http://localhost/code/English folder/voter/sendvote.php" enctype="multipart/form-data" method="post" onsubmit = "return(validatloginform());">
	<center>
	<?php
	$localhost="localhost";
			$dbuser="root";
			$dbpass="";
			$dbname="ovs";
			$con=mysql_connect($localhost,$dbuser,$dbpass);
			if(!$con)
			{ 
			die("Coudn't connect to the server");
			}
			$db_select=mysql_select_db($dbname,$con);
			if(!$db_select)
			{
			die("db is not selected".mysql_error());
			}
			$voter_id=$_POST['voter_id'];
			$pass=$_POST['password'];
			if(mysql_num_rows(mysql_query("SELECT *from voters where v_id='$voter_id'")))
			{
			$sql="SELECT *from voters where v_id='$voter_id' AND password='$pass'";
			$resul=mysql_query($sql);
			while($row=mysql_fetch_array($resul))
			{
	       if($row['password']!=md5($pass))
		   {
			   echo"You Entered incorrect password";
			   exit;
		   }

			$region=$row['region'];
			$zone=$row['zone'];
			$woreda=$row['woreda'];
			$sel="SELECT *FROM cand where region='$region' AND zone='$zone' AND woreda='$woreda'";
			$result=mysql_query($res);
			if(!$result)
			{
			echo "Error on displaying paper".mysql_error();
			exit;
			}
			?>
			<table border="green">
			<?php
			$i=0;
			while($pap=mysql_fetch_array($result))
			{
			?>
			<tr>
			<td>
			<table>
			<tr>
			<td><?php echo '<input  id = "can"  name = "can" class = "contactFormInput"  type = "radio"  value = "'.$pap[1].'" required>';?>
			</td>
			</tr>
			<tr>
			<td>
			<?php echo '<img src=" data:image;base64,'. $pap[2].'" height="130" width="130" alt="image not found"/>';?>
			</td>
			</tr>
			<tr>
			<td>
			<?php echo $pap[0];?>
			</td>
			</tr>
			<td>
			subjected to:-<?php echo $pap[3];?>
			</td>
			</tr>
			</table>
			</td>
			<?php
			$i=$i+1;
			if($i>=3)
			{
			?>
			</tr>
			<?php
			}
			}
			}
			}
	?>
	</table>
	</center>
	</form>
	</div>
	</div>
	</div>
	</div>
<?php
include ("../footer.php");
?>
  </body>
</html>
