
<!DOCTYPE html>
<?php
session_start();
include("voterheade.php");
?>
   <script type="text/javascript" src="../js/validateVote_form.js"></script>
      <STYLE TYPE="text/css">
 #contact form {
	background: pink;
margin:auto;
position:relative;
width:500px;
height:230px;
font-family: ;
font-size: 14px;
font-style: italic;
line-height: 24px;
font-weight: ;
color: black;
text-decoration: none;
-webkit-border-radius: 30px;
-moz-border-radius: 30px;
border-radius: 10px;
padding:10px;
border: 10px solid #fff;
border: inset 10px solid #fff;
-webkit-box-shadow: 0px 100px 100px rgba(0, 0, 0, 1.9);
-moz-box-shadow: 0px 100px 280px rgba(0, 0, 0, 1.9);
box-shadow: 0px 0px 28px rgba(0, 0, 0, 1.9)
}
#site_content
{ 
    padding: 0px;
	width: 1300px;
	height:600px;
	overflow: hidden;
	margin:10px auto;
	text-align:left;
	background:#ccc url(../image/mainback.jpg) repeat;
	border:5px solid green;
}
</style>
<div id="site_content">	

<div class="sidebar_container1">       
	<div class="sidebar">
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of ETHIOPIA</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of democracy</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of election</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">Past Election in Ethiopia</a></span>
	</div>
	</div>
	<div class="sidebar_container2">       
	<div class="sidebar">
	<p><font size="3pt"> </u><b>Election</b></u></p>
	<ul>	
<p><li><a href="#">past election in ethiopia</a></p>…</font>
   <ul>
<p><li><a href="#">the 2005 ethiopian election</a></p>…</font></li>
<p><li><a href="#">the 2010 ethiopian election</</a></p>…</font></li>
<p><li><a href="#">the 2015 ethiopian election</</a></p>…</font></li></ul></li>
<p><li><a href="#">structure of past ethiopian Government</a></p>…</font>
<ul><p><li><a href="#">zemene mesafinit</a></p>…</font></li>
<p>Between 1755 to 1855, Ethiopia experienced a period of isolation referred to as the Zemene Mesafint or "Age of Princes". The Emperors became figureheads.</<a href="#">read more</a>
</p>
<p><li><a href="#">Ethiopia 1855-1991</a></p>…</font></li>
<p>
The Emperor of Ethiopia was refered to as Niguse Negest (King of Kings) and Atse (Emperor).This time pass through  emperor Tewodros II,emperor Yohanis IV,
emperor minilik II,lij Eyasu, Zewditu ,emperor H/silasie and derue<a href="#">read more </a>
</p>
<p><li><a href="#">EFDRE </a></p>…</font></li></ul>
</li>
<p>
</p>
</ul>
	</div>
	</div>
	<div id="content">
<div class="content_item">
					<b>
						<div id="contact" background="green">
							<?php
							$date =date_create();
							date_date_set($date,2016 ,05 ,30 );
							$date=date_format($date, "y/m/d");
							$curentdate=date("y/m/d");
							if($date!=$curentdate)
							{
								echo"Today is not Election day please wait elction day.It is".$date."today is".$curentdate;
								exit;
							}
							?>
							<form name = "RegistrationForm" action ="votepaper.php" enctype="multipart/form-data" method="post" onsubmit = "return(validatloginform());">
								<center><legend align="center"><font color="blue" size="5pt">VOTE PAGE</legend></font>
								<table >
								<tr>
								 <td align="center">Voter Identity code:</td>
								 <td><input id = "voter_id"  name = "voter_id"  class = "contactFormInput" type="text" value="" class="txtfield" placeholder = "Voter identity code"  onkeyup = "validateID()" required></td>
								 <td><label id="voteridePrompt"></label></td>
								 </tr>
								          <tr>
											<td align ="center">Password:</td>
											<td><input id = "password" name = "password" class = "contactFormInput" type="password" class="txtfield" placeholder = "Password" required></td>
										  <td><label id = "PasswordPrompt"></label> </td>
										  </tr>
								  <tr>
								  <td>
								  </td>
								  <td ><button type="submit" id="log" ><font color="blue" size="4pt">GET VOTING PAPER</font></center>
								  </td>
								  </tr>
								  </table></center>
							</form>
				</div>
			</div>
	</div>
	</div>
	<?php
	include ("../footer.php");
	?>
  </body>
</html>
