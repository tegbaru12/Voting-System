<!DOCTYPE html>
<?php
session_start();
include("voterheade.php");
?>
<div id="site_content" xmlns="http://www.w3.org/1999/html">
<div class="sidebar_container1">       
	<div class="sidebar">
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of ETHIOPIA</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of democracy</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of election</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">Past Election in Ethiopia</a></span>
	</div>
	</div>
	<div id="content">
<div class="content_item">
	<b>
	<div id="contact" background="green">
	<form name = "RegistrationForm" action ="sendvote.php" enctype="multipart/form-data" method="post" onsubmit = "return(validatloginform());">
	<center>
	<?php
	$localhost="localhost";
			$dbuser="root";
			$dbpass="";
			$dbname="ovs";
			$con=mysql_connect($localhost,$dbuser,$dbpass);
			if(!$con)
			{ 
			die("Coudn't connect to the server");
			}
			$db_select=mysql_select_db($dbname,$con);
			if(!$db_select)
			{
			die("db is not selected".mysql_error());
			}
			$voter_id=$_POST['voter_id'];
			$pass=md5($_POST['password']);
			if(mysql_num_rows(mysql_query("SELECT *FROM voted where v_id='$voter_id'")))
			{
			echo'<font color="red"> Warning ! you are already voted before !</font>';
			exit;
			}
			if(mysql_num_rows(mysql_query("SELECT *from voters where v_id='$voter_id'AND password='$pass'")))
			{
			$sql="SELECT *from voters where v_id='$voter_id' AND password='$pass'";
			$resul=mysql_query($sql);
			while($row=mysql_fetch_array($resul))
	{
	$region = $row['region'];
	$zone = $row['zone'];
	$woreda = $row['woreda'];
	$posi = "Fedral";
	$por = "Regional";
	if ((mysql_num_rows(mysql_query("SELECT *FROM cand where woreda='$woreda' AND position='$posi' AND status=1"))))
	{
		$sel = "SELECT *FROM cand where woreda='$woreda' AND position='$posi'AND status=1";
		$result = mysql_query($sel);
		if (!$result) {
			echo "Error on displaying paper" . mysql_error();
			exit;
		}


		echo '<tr><td colspan="2"> <font size="4pt" color="#7fff00">FOR FEDRAL LEVEL</font></td></tr>
		<table border="green">';
		$i = 0;
		?>
		<tr>
		<?php
		while ($pap = mysql_fetch_array($result)) {
			if ($i > 3) {
				$i = 0;
				echo '<tr>';
			}
			?>
			<td>
				<table>
					<tr>
						<td><?php echo '<input  id = "can"  name = "can" class = "contactFormInput"  type = "radio"  value = "' . $pap[1] . '" required>' . $pap[1]; ?>
						</td>
					</tr>
					<tr>
						<td>
							<?php echo '<img src=" data:image;base64,' . $pap[2] . '" height="130" width="130" alt="image not found"/>'; ?>
						</td>
					</tr>
					<tr>
						<td>
							<?php echo $pap[0]; ?>
						</td>
					</tr>
					<tr>
					</tr>
				</table>
			</td>
			<?php
			$i = $i + 1;
			if ($i == 3) {
				?>
				</tr>
				<?php
			}
		}
	}
	if (!(mysql_num_rows(mysql_query("SELECT *FROM cand where woreda='$woreda' AND position='$posi' AND status=1"))))
	{
		echo "<tr><td colspan='2'><font color='#a52a2a' size='4pt'>There is no candidate subjected to fedral</font></td></tr>";
	}
	if (!(mysql_num_rows(mysql_query("SELECT *FROM cand where woreda='$woreda' AND position='$por' AND status=1"))))
	{
		echo "<tr><td colspan='2'><font color='#a52a2a' size='4pt'> <br>There is no candidate subjected to Regional</font></td></tr> ";
	}
	else{
	$sel = "SELECT *FROM cand where woreda='$woreda' AND position='$posi'AND status=1";
	$result = mysql_query($sel);
	if (!$result) {
		echo "Error on displaying paper" . mysql_error();
		exit;
	}
	?>

		<tr><td colspan="2"><font size="4pt" color="#7fff00">FOR REGIONAL LEVEL</font></td></tr>
		<table border="green">
			<?php
			$i = 0;
			?>
			<tr>
				<?php
				while ($pap = mysql_fetch_array($result))
				{
				if ($i > 3)
				{
				$i = 0;
				?>
		<tr>
		<?php
		}
		?>
		<td>
			<table>
				<tr>
					<td><?php echo '<input  id = "canr"  name = "canr" class = "contactFormInput"  type = "radio"  value = "' . $pap[1] . '" required>' . $pap[1]; ?>
					</td>
				</tr>
				<tr>
					<td>
						<?php echo '<img src=" data:image;base64,' . $pap[2] . '" height="130" width="130" alt="image not found"/>'; ?>
					</td>
				</tr>
				<tr>
					<td>
						<?php echo $pap[0]; ?>
					</td>
				</tr>
				<tr>
				</tr>
			</table>
		</td>
		<?php
		$i = $i + 1;
		if ($i == 3) {
			?>
			</tr>
			<?php
		}
		}
		}

		?>
			<tr>
				<td>
				</td>
				<td>

					<?php echo '<button type="submit" id="log" name="log" value="" ><font color="blue" size="4pt">VOTE';
					?></td>
			</tr>
			<?php
			}
		MYSQL_CLOSE($con);
		}
		else
		{
		echo '<font color="red" size="4pt">wrong password or voter identity </font>';
		exit;
		}?>
	</table>
	</center>
	</form>
	</div>
	</div>
	</div>
	</div>
<?php
include ("../footer.php");
?>
</body>
</html>
