<!DOCTYPE html>
	<head>
<?php
session_start();
include ("voterheade.php");
?>
<style type="text/css">
#site_content
{
padding: 0px;
width: 1200px;
height:700px;
overflow: hidden;
margin:10px auto;
text-align:left;
background:#ccc url(../image/mainback.jpg) repeat;
border:5px solid green;
}
</style></head>
<div id="site_content">
<div class="sidebar_container1">       
	<div class="sidebar">
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of ETHIOPIA</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of democracy</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">History of election</a></span><br>
	 <a href="#"><span style="color: blue;font-size: 12pt;">Past Election in Ethiopia</a></span>
	</div>
	</div>
<div id="content">
<div class="content_item">
		<b>
			<div id="contact" class="body">
				<form>
						<table>
<?php
$userna=$_SESSION['login_voter'];
$localhost="localhost";
$dbuser="root";
$dbpass="";
$dbname="ovs";
$con=mysql_connect($localhost,$dbuser,$dbpass);
if(!$con)
{ die("Coudn't connect to the server");
}
$db_select=mysql_select_db($dbname,$con);
if(!$db_select)
{
	die("db is not selected".mysql_error());
}
$sql="select *from voters where user_name='$userna'";
$result=mysql_query($sql);
while ($row=mysql_fetch_row($result))
{
	echo'<tr><td>Voter Identity Number:</td> <td>'.$row[0].'</td></tr>';
	echo'<tr><td>Name:</td> <td>'.$row[1];
	echo" ";
	echo $row[2].'</td></tr>';
	echo'<tr><td>Mother name:</td> <td>'.$row[3].'</td></tr>';
	echo'<tr><td>SSN:</td> <td>'.$row[4].'</td></tr>';
	echo'<tr><td>Sex:</td> <td>'.$row[5].'</td></tr>';
	echo'<tr><td>Age:</td> <td>'.$row[6].'</td></tr>';
	echo'<tr><td>Nationality:</td> <td>'.$row[7].'</td></tr>';
	echo'<tr><td>Region:</td> <td>'.$row[8].'</td></tr>';
	echo'<tr><td>Zone:</td> <td>'.$row[9].'</td></tr>';
	echo'<tr><td>Woreda:</td> <td>'.$row[10].'</td></tr>';
	echo'<tr><td>User Name:</td> <td>'.$row[11].'</td></tr>';

}
mysql_close($con);
?>
						</table>
				</form>
			</div>
	</div>
</div>
</div>
	<?php
	include ("../footer.php");
	?>
	</body>
	</html>
