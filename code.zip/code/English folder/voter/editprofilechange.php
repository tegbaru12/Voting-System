<!DOCTYPE html>
<html lang="en">
<head>
	<?php
	session_start();
	include ("voterheade.php");
	?>
	<script type="text/javascript" src="../js/createAccoount_form.js"></script>
	<STYLE TYPE="text/css">
		#contact form {
			background: #f2f5f5;
			margin:auto;
			position:relative;
			width:680px;
			height:350px;
			font-family: ;
			font-size: 14px;
			font-style: italic;
			line-height: 24px;
			font-weight: ;
			color: black;
			text-decoration: none;
			-webkit-border-radius: 10px;
			-moz-border-radius: 10px;
			border-radius: 10px;
			padding:10px;
			border: 1px solid #99779;
			border: inset 0px solid #333;
			-webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
			-moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);
			box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3)
		}
		#site_content
		{
			padding: 0px;
			width: 1200px;
			height:400px;
			overflow: hidden;
			margin:80px auto;
			text-align:left;
			background:#ccc url(../image/mainback.jpg) repeat;
			border:2px solid green;
		}
	</style>
</head>
<div id="site_content">

	<div class="sidebar_container1">
		<div class="sidebar">
			<a href="#"><span style="color: blue;font-size: 12pt;">History of ETHIOPIA</a></span><br>
			<a href="#"><span style="color: blue;font-size: 12pt;">History of democracy</a></span><br>
			<a href="#"><span style="color: blue;font-size: 12pt;">History of election</a></span><br>
			<a href="#"><span style="color: blue;font-size: 12pt;">Past Election in Ethiopia</a></span>
		</div>
	</div>
	<div id="content"
	<div class="content_item">
	<b>
	<div id="contact" class="body">
		<form>
		<?php
		$userna=$_SESSION['login_voter'];
		$localhost="localhost";
		$dbuser="root";
		$dbpass="";
		$dbname="ovs";
		$con=mysql_connect($localhost,$dbuser,$dbpass);
		if(!$con)
		{ die("Coudn't connect to the server");
		}
		$db_select=mysql_select_db($dbname,$con);
		if(!$db_select)
		{
			die("db is not selected".mysql_error());
		}
 $use=$_POST['User_name'];
$olppass=md5($_POST['oldpassword']);
$newpass=md5($_POST['password']);
$sql="select *from voters where user_name='$use'";
$result=mysql_query($sql);
while ($row=mysql_fetch_row($result))
{
	if($row[12]!=$olppass)
	{
		incorrectpass();
	}
	else{
		$sq="update voters set user_name='$use',password='$newpass' where 	v_id='$row[0]'";
		if(!mysql_query($sq))
		{
			die("Edit profile Error".mysql_error());
		}
		echo'<font color="blue" size="5pt"> Change Saved</font>';
	}
}
function incorrectpass()
{
	$userna=$_SESSION['login_voter'];
	$localhost="localhost";
	$dbuser="root";
	$dbpass="";
	$dbname="ovs";
	$con=mysql_connect($localhost,$dbuser,$dbpass);
	if(!$con)
	{ die("Coudn't connect to the server");
	}
	$db_select=mysql_select_db($dbname,$con);
	if(!$db_select)
	{
		die("db is not selected".mysql_error());
	}
	$sql="select *from voters where user_name='$userna'";
	$result=mysql_query($sql);
	while ($row=mysql_fetch_row($result)) {
		echo '
	<form name = "CandidateForm" action ="editprofilechange.php" method="POST" enctype="multipart/form-data" onsubmit = "return validatecreateAccount(this.form);">
	<fieldset>
	<legend align="center"><font color="blue" size="5pt"><legend>EDIT PROFILE</font></legend>
		<table >
			<tbody  >
			<tr>
				<td align ="center">User Name:</td>
				<td><input id = "User_name" name = "User_name" class = "contactFormInput" value="' . $row[11] . '" type="text" class="txtfield" placeholder = "' . $row[11] . '" onblur = "validateUsername()"required></td>
				<td><label id = "UserNamePrompt"></label> </td>
			</tr>
			<tr>
				<td align ="center">Current Password:</td>
				<td><input id = "oldpassword" name = "oldpassword" class = "contactFormInput" type="password" class="txtfield" placeholder = "enter Password" required></td>
				<td><label id = "PasswordPrompt"></label> </td>
			</tr>
			<tr>
				<td align ="center">New Password:</td>
				<td><input id = "password" name = "password" class = "contactFormInput" type="password" class="txtfield" placeholder = "enter Password" onblur = "validatePassword()"required></td>
				<td><label id = "PasswordPrompt"></label> </td>
			</tr>
			<tr>
				<td align ="center">Re  type new password:</td>
				<td><input id = "re_pasword" name = "re_pasword"  class = "contactFormInput" type="password" class="txtfield" placeholder = "re enter password" onblur = "validateRePassword()"required></td>
				<td><label id = "re_passowrdPrompt"></label> </td>
			</tr>
			<tr>
				<td></td>
				<td align="center"><button type = "submit" id="se" ><strong> Save Change </strong></button> </td>
				<td><button type = "reset" onclick = "" ><strong> CLEAR </strong></button> </td>
			</tr>
			</tbody>
		</table>
		</fieldset></form>';
		}
}
		mysql_close($con);
		?>
			</form>
	</div>
	</div>
</div>
</div>
<?php
include ("../footer.php");
?>
</body>
</html>
