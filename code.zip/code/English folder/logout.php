<?php
session_start();
if(isset($_COOKIE["user"]))
{
    setcookie("user", '', strtotime( '-5 days' ), '/');
}

if(session_destroy()) {
    ?><script language="javascript">
    window.location="login.php";
</script>
<?php
}
?>