<?php
/**
 * Created by PhpStorm.
 * User: alexo
 * Date: 5/27/2016
 * Time: 12:53 AM
 */
session_start();
include ("headerfile.php");
?>
   <script type="text/javascript" src="js/validatePart_form.js"></script>
    <STYLE TYPE="text/css">
		#site_content
		{
			padding: 0px;
			width: 1200px;
			height:900px;
			overflow: hidden;
			margin:80px auto;
			text-align:left;
			background:#ccc url(../image/mainback.jpg) repeat;
			border:2px solid green;
		}
</style>
	<?php
	include ("sidebar.php");
	?>
<div id="content">
<div class="content_item">
					<b>
						<div id="contact" class="body">
						
							<form  >
<?php
$localhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "ovs";
$con = mysql_connect($localhost, $dbuser, $dbpass);
if (!$con) {
	die("Coudn't connect to the server");
}
$db_select = mysql_select_db($dbname, $con);
if (!$db_select) {
	die("db is not selected" . mysql_error());
}
$pname=$_POST['p_Name'];
$PIC=$_POST['party_identity'];
if(getimagesize($_FILES['logo']['tmp_name'])==FALSE)
{
echo "please upload party symbol";
exit;
}
$img_name=$_FILES['logo']['name'];
$temp=$_FILES['logo']['tmp_name'];
$file_type=$_FILES['logo']['type'];
$size=$_FILES['logo']['size'];
if($size>500000)
{
echo "image is too large";
exit;
}
$image=addslashes($temp);
$symname=$_POST['sym_name'];
$image=file_get_contents($image);
$target_file=$image;
$image=base64_encode($image);
move_uploaded_file($_FILES["logo"]["tmp_name"], "image/");
$PRN=$_POST['party_rep_name'];
$SSC=$_POST['rep_ssn'];
$sex=$_POST['V-sex'];
$age=$_POST['ca_age'];
$PRP=$_POST['party_rep_pro'];
$nationality=$_POST['Nationality'];
$region=$_POST['region'];
$zone=$_POST['zone'];
$woreda=$_POST['woreda'];
$e_mail=$_POST['email'];
$phone=$_POST['pho_num'];
$username=$_POST['user_name'];
$password=md5($_POST['password']);
$name = $_FILES['cv']['name'];
$tempp = $_FILES['cv']['tmp_name'];
if(!(move_uploaded_file($tempp, "atachedfile/" . $name)))
{
	echo'Error '.error_get_last();
	exit;

}
$url = "http://localhost/code/English folder/atachedfile/$name";
$db = mysql_connect("localhost", "root","");
if(!$db)
{ echo "unable to open this local host file sorry";
exit;
}

mysql_select_db("OVS",$db) or
die("unable to open the database OVS ");

$sql="INSERT INTO party(party_name, PIC, symb_name, party_symbol,PRN,SSC,sex, age, PRP, nationality, region, zone, woreda, email, phone_number,user_name, password,atach,status) 
                 VALUES('$pname','$PIC','$symname','$image','$PRN','$SSC','$sex','$age','$PRP','$nationality','$region','$zone','$woreda','$e_mail','$phone','$username','$password','$url',0)";
if(!mysql_query($sql))
{
die ("sorry you are not registered".mysql_error());
}
?>

							<fieldset>
								<legend align="center"><font color="blue" size="4pt">PARTY REGISTERD SUCSSUSFULY WITH THE FOLLOWING DETAIL</font></legend>
								<table border="green">
										<tr>
											<td>Party Name:</td>
											<td><?php echo $pname ?></td>
										</tr>
										<tr>
											<td>Party Identity code(name abrevation):</td>
											<td><?php echo $PIC ?> </td>
										</tr>
									<tr>
										<td>party symbol name</td>
										<td><?php echo $symname;?></td>
									</tr>
										<tr>
											<td>Part symbol:</td>
											<td><?php echo '<img src=" data:image;base64,'. $image.'" height="130" width="130" alt="file not found" />'?></td>
										</tr>
										<tr>
											<td>Party representative name</td>
											<td><?php echo $PRN ?> </td>
										
										</tr>
										<tr>
											<td>party representative profession</td>
											<td ><?php echo $PRP ?>	</td>
										
										</tr>
										<tr>
											<td>Social security code:</td>
											<td ><?php echo $SSC ?>	</td>
											
									
										</tr>
										<tr>
										
											<td>Sex:</td>
											<td><?php echo $sex ?>
	
											</td>
										
										</tr>
										<tr>
											<td>Age</td>

													<td><?php echo $age ?></td>
													
							
											</tr>
										<tr>	
										<td>Nationality:</td>
											
													<td><?php echo $nationality ?></td>
												</tr>
												<tr>	
											<td>Region:</td>

											<td><?php echo $region ?> </td>
											
										</tr>
										<tr>
											<td>Zone:</td>

													<td><?php echo $zone ?> </td>
											</tr>
												<tr>	
										<td>Woreda:</td>

										<td><?php echo $woreda ?> </td>
										</tr>
										<tr>
											<td>E-mail:</td>
											
											 <td><?php echo $e_mail ?></td>
										</tr> 
										<tr>
											<td>Phone_number:</td>

											 <td><?php echo $phone ?></td>
										</tr>
										<tr>
											<td >User Name:</td>
											<td><?php echo $username ?></td>
										</tr>
											<tr>
											<td>Password:</td>
											<td><?php echo $password ?></td>
										</tr>
									<tr>
										<td>Attached file</td>
										<td><?php echo"<embed src='$url' width='160' height='115'></embed>";?></td>
									</tr>

									</tbody>
								</table>
								<br>
				<br>
				<center><a href="#">Print</a></center>
				</form>
								</fieldset>
							</form>
				</div>
			</div>
	</div>
	</div>
	<?php
	include ("footer.php");
	?>
  </body>
</html>
