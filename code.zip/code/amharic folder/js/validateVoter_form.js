function validatefname(){
	var fname = document.getElementById("F_Name").value;
	if(fname.length == 0){
		jsShow("F_NamePrompt");
		producePrompt("እባክዎን የመጀመሪያ ስም?  ", "F_NamePrompt", "red");
		return false;
		
	}
	var nameexp =/^[a-zA-Z]+$/;
	if(!fname.match(nameexp)){
		jsShow("F_NamePrompt");
		producePrompt("ስም በፊደል መፃፍ አለበት", "F_NamePrompt", "orange");
		return false;
	}
	jsShow("F_NamePrompt");
	producePrompt("እሺ!  " + fname, "F_NamePrompt", "green");
	setTimeout(function(){jsHide("F_NamePrompt");}, 2000);
		return true;
}
 function validatelname(){
	var lname = document.getElementById("L_Name").value;
	if(lname.length == 0){
		jsShow("L_NamePrompt");
		producePrompt("እባክዎን የመቸረሻ ስም ?  ", "L_NamePrompt", "red");
		return false;
		
	}
	var nameexp =/^[a-zA-Z]+$/;
	if(!lname.match(nameexp)){
		jsShow("L_NamePrompt");
		producePrompt("ስም በፊደል መፃፍ አለበት ", "L_NamePrompt", "orange");
		return false;
	}
	jsShow("L_NamePrompt");
	producePrompt("እሺ !    " + lname, "L_NamePrompt", "green");
	setTimeout(function(){jsHide("L_NamePrompt");}, 2000);
		return true;
}
 function validatemName(){
	var cname = document.getElementById("Mother_Name").value;
	if(cname.length == 0){
		jsShow("M_NamePrompt");
		producePrompt("እባክዎን የእናት ስም እስከ አባት?  ", "M_NamePrompt", "red");
		return false;
		
	}
	var nameexp = /^[A-Za-z]+\s{1}[A-Za-z]+$/;
	if(!cname.match(nameexp)){
		jsShow("M_NamePrompt");
		producePrompt(" ስም በፊደል መፃፍ አለበት  ", "M_NamePrompt", "orange");
		return false;
	}
	jsShow("M_NamePrompt");
	producePrompt("እሺ.. " + cname, "M_NamePrompt", "green");
	setTimeout(function(){jsHide("M_NamePrompt");}, 2000);
		return true;
		
}
function validate_ssn()
{
var pname = document.getElementById("ssn").value;
	if(pname.length == 0){
		jsShow("ssnPrompt");
		producePrompt("እባክዎን የመራጩን የህዝብ መታወቂያ ኮድ ?  ", "ssnPrompt", "red");
		return false;
		
	}
	var nameexp =/^[a-zA-Z0-9\/]+$/;
	if(!pname.match(nameexp)){
		jsShow("ssnPrompt");
		producePrompt("የአጸጻፍ ችግር አለበት ", "ssnPrompt", "orange");
		return false;
	}
	jsShow("ssnPrompt");
	producePrompt("እሺ!   " + pname, "ssnPrompt", "green");
	setTimeout(function(){jsHide("ssnPrompt");}, 2000);
		return true;	
}
function validatecanage(x)
{
	var cage=parseInt(x);
	if(cage<18)
	{
	 jsShow("agePrompt");
		producePrompt("እድሜዎ ለምርጫ አልደረሰም?  ", "agePrompt", "red");	
		return false;
	}
	jsShow("agePrompt");
	producePrompt("እሺ !  " + cage, "agePrompt", "green");
	setTimeout(function(){jsHide("agePrompt");}, 2000);
		return true;
}
function validateNationality(x)
{
	if(x=="0")
	{
		jsShow("nationpropmt");
		producePrompt("እባክዎን ሀገርዎን ይምረጡ", "nationpropmt", "orange");
		return false;
	}
	if(x!="2")
	{
		jsShow("nationpropmt");
		producePrompt("ዜግነትዎ ለመምረጥ አይፈቀድልዎትም  ", "nationpropmt", "orange");
		return false;
	}
	jsShow("nationpropmt");
	producePrompt(" እሺ", "nationpropmt", "green");
	setTimeout(function(){jsHide("nationpropmt");}, 2000);
		return true;
}
function validateRegion(x)
{
	if(x=="0")
	{
		jsShow("canregionPrompt");
		producePrompt("እባክዎን ክልልዎን ይምረጡ  ", "canregionPrompt", "orange");
		return false;
	}
	jsShow("canregionPrompt");
	producePrompt(" እሺ", "canregionPrompt", "green");
	setTimeout(function(){jsHide("canregionPrompt");}, 2000);
	return true;
}
function validatezone(x)
{
	if(x=="-1"){
		jsShow("canzonePrompt");
		producePrompt("እባክዎን ዞን ይምረጡ?  ", "canzonePrompt", "red");
		return false;
		
	}
	jsShow("canproPrompt");
	producePrompt("እሺ!   ", "canzonePrompt", "green");
	setTimeout(function(){jsHide("canzonePrompt");}, 2000);
		return true;
}
function validateWoreda(x)
{
	if(x == "-1"){
		jsShow("canwereaPrompt");
		producePrompt("እባክዎን ወረዳ ይምረጡ?  ", "canwereaPrompt", "red");
		return false;
		
	}
	jsShow("canwereaPrompt");
	producePrompt("እሺ !   ", "canwereaPrompt", "green");
	setTimeout(function(){jsHide("canwereaPrompt");}, 2000);
		return true;
}
function validateID()
{
var pname = document.getElementById("voter_id").value;
	if(pname.length == 0){
		jsShow("voteridePrompt");
		producePrompt("እባክዎን የመራጭ መለያ ኮድ ያስገቡ  ", "voteridePrompt", "red");
		return false;
		
	}
	var nameexp =/^[0-9]+$/;
	if(!pname.match(nameexp)){
		jsShow("voteridePrompt");
		producePrompt("እባክዎን ትክክል የመራጭ መለያ ኮድ ያስገቡ ", "voteridePrompt", "orange");
		return false;
	}
	jsShow("voteridePrompt");
	producePrompt("እሺ!   " + pname, "voteridePrompt", "green");
	setTimeout(function(){jsHide("voteridePrompt");}, 2000);
		return true;	
}
function validateUsername()
{
	var A_name = document.getElementById("User_name").value;
	if(A_name.length == 0){
		jsShow("UserNamePrompt");
		producePrompt("እባክዎን የመጠቀሚያ ስም ያስገቡ ?", "UserNamePrompt", "red");
		return false;
		
	}
	var A_nameexp = /^[A-Za-z]+[\.\-_][A-Za-z]+$/;
	if(!A_name.match(A_nameexp)){
		jsShow("UserNamePrompt");
		producePrompt("የተሳሳተ የመግቢያ ሥም", "UserNamePrompt", "orange");
		return false;
	}
	if(A_name.length <= 3){
		jsShow("UserNamePrompt");
		producePrompt("ቢያንስ 3 ሆሄ"", "UserNamePrompt", "blue");
		return false;
		
	}
	jsShow("UserNamePrompt");
	producePrompt("እባክዎን ደህና መጡ  " + A_name, "UserNamePrompt", "green");
	setTimeout(function(){jsHide("UserNamePrompt");}, 2000);
		return true;
}
function validatePassword()
{
	var pass=document.getElementById("password").value;
	var x=pass.length;
	if(x == 0){
		jsShow("PasswordPrompt");
		producePrompt("እባክዎን የይለፍ ቃል?    ", "PasswordPrompt", "red");
		return false;
		
	}
	if(x<=5){
		jsShow("PasswordPrompt");
		producePrompt(" ደካማ! !   ", "PasswordPrompt", "orange");
		return false;
		}
	jsShow("PasswordPrompt");
	producePrompt("ጠንካራ " , "PasswordPrompt", "green");
	setTimeout(function(){jsHide("PasswordPrompt");}, 2000);
		return true;
}
function validateRePassword(){
	var RPassword = document.getElementById("re_pasword").value;
	var pass=document.getElementById("password").value;
	var x=RPassword.length;
	if( x == 0){
		jsShow("repassowrdPrompt");
		producePrompt("የይለፍ ቃል ድጋሚ  ", "repassowrdPrompt", "red");
		return false;
		
	}
	
	if(pass ==RPassword){
		jsShow("repassowrdPrompt");
	producePrompt("ተዛምዷል" , "repassowrdPrompt", "green");	
	setTimeout(function(){jsHide("repassowrdPrompt");}, 4000);
	return true;	
	}
	jsShow("repassowrdPrompt");
	producePrompt("አልተዛደም" , "repassowrdPrompt", "red");	
	return false;	
}
function jsShow(id){
	document.getElementById(id).style.display = "block";
}

function jsHide(id){
	document.getElementById(id).style.display = "none";
}

function producePrompt(message, promptLocation, color){
	document.getElementById(promptLocation).innerHTML = message;
	document.getElementById(promptLocation).style.color = color;
}