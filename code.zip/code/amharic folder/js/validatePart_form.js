function validateP_Name(){
	var pname = document.getElementById("p_Name").value;
	if(pname.length == 0){
		jsShow("PNamePrompt");
		producePrompt("እባክዎን የፓርቲ ስም?  ", "PNamePrompt", "red");
		return false;
		
	}
	var nameexp =/^[ሀ-ፐ\s-, ]+$/;
	if(!pname.match(nameexp)){
		jsShow("PNamePrompt");
		producePrompt("የተሳሳተ ሥም ", "PNamePrompt", "orange");
		return false;
	}
	jsShow("PNamePrompt");
	producePrompt("እሺ   " + pname, "PNamePrompt", "green");
	setTimeout(function(){jsHide("PNamePrompt");}, 2000);
		return true;
}
function validateP_code()
{
var pname = document.getElementById("party_identity").value;
	if(pname.length == 0){
		jsShow("Party_codePrompt");
		producePrompt(" የስሙ አፅሮተ ቃል ያሰገቡ ?  ", "Party_codePrompt", "red");
		return false;
		
	}
	var nameexp =/^[ሀ-ፐ0-9\/]+$/;
	if(!pname.match(nameexp)){
		jsShow("Party_codePrompt");
		producePrompt("እባክዎን ትክክልኛ አፅሮተ ቃል ያሰገቡ ", "Party_codePrompt", "orange");
		return false;
	}
	jsShow("Party_codePrompt");
	producePrompt("እሺ !   " + pname, "Party_codePrompt", "green");
	setTimeout(function(){jsHide("Party_codePrompt");}, 2000);
		return true;
}
 function validateName(){
	var cname = document.getElementById("party_rep_name").value;
	if(cname.length == 0){
		jsShow("repnamePrompt");
		producePrompt("እባክዎን የተዎካዩን ሙሉ ስም ያስገቡ ?  ", "repnamePrompt", "red");
		return false;
		
	}
	var nameexp = /^[ሀ-ፐ]+\s{1}[ሀ-ፐ]+$/;
	if(!cname.match(nameexp)){
		jsShow("repnamePrompt");
		producePrompt(" እባክዎን ትክክልኛ ሙሉ ስም ያስገቡ  ", "repnamePrompt", "orange");
		return false;
	}
	jsShow("repnamePrompt");
	producePrompt("እሺ ! " + cname, "repnamePrompt", "green");
	setTimeout(function(){jsHide("repnamePrompt");}, 2000);
		return true;	
}
function validate_ssn()
{
var pname = document.getElementById("rep_ssn").value;
	if(pname.length == 0){
		jsShow("ssnPrompt");
		producePrompt("እባክዎን የተዎካዩን የህዝብ መታወቂያ ኮድ ያስገቡ ?  ", "ssnPrompt", "red");
		return false;
		
	}
	var nameexp =/^[ሀ-ፐ0-9\/]+$/;
	if(!pname.match(nameexp)){
		jsShow("ssnPrompt");
		producePrompt("እባክዎን ትክክልኛ የተዎካዩን የህዝብ መታወቂያ ኮድ ያስገቡ  ", "ssnPrompt", "orange");
		return false;
	}
	jsShow("ssnPrompt");
	producePrompt("እሺ!   " + pname, "ssnPrompt", "green");
	setTimeout(function(){jsHide("ssnPrompt");}, 2000);
		return true;	
}
function validatecanage(x)
{
	var cage=parseInt(x);
	if(cage<21)
	{
	 jsShow("repagePrompt");
		producePrompt("የፓርቲ ተወካይ ለመሆን እድሜ ከ20 መብልጥ አለብት?  ", "repagePrompt", "red");	
		return false;
	}
	else{
	jsShow("repagePrompt");
	producePrompt("እሺ   " + cage, "repagePrompt", "green");
	setTimeout(function(){jsHide("repagePrompt");}, 2000);
		return true;
	}
}
function validateprofession(x){
	if(x == "0"){
		jsShow("repproPrompt");
		producePrompt("እባክዎን የተወካዩን የትምህርት ደረጃ?  ", "repproPrompt", "red");
		return false;
	}
	
		else{
		jsShow("repproPrompt");
	    producePrompt("ትክክል   " , "repproPrompt", "green");
	    setTimeout(function(){jsHide("repproPrompt");}, 2000);
		return true;
		}
}
function validateNationality(x)
{
	if(x !="0")
	{
		jsShow("repnationalityPrompt");
		producePrompt("የፓርቲ ሊቀመንበር ለመሆን እትዮጲያዊ መሆን አለብዎት", "repnationalityPrompt", "orange");
		return false;
	}
	else{
	jsShow("repnationalityPrompt");
	producePrompt(" ትክክል", "repnationalityPrompt", "green");
	setTimeout(function(){jsHide("repnationalityPrompt");}, 2000);
		return true;
	}
}
function validateRegion(x)
{
	if(x =="0")
	{
		jsShow("repRegionPrompt");
		producePrompt("እባክዎን ክልልዎን ይምረጡ ", "repRegionPrompt", "orange");
		return false;
	}
	else
	{
	jsShow("repRegionPrompt");
	producePrompt("እሺ", "repRegionPrompt", "orange");
	setTimeout(function(){jsHide("repRegionPrompt");}, 2000);
		return true;
	}
}
function validatezone(x)
{
	if(x =="-1"){
		jsShow("canzonePrompt");
		producePrompt("እባክዎን ዞን ይምረጡ?  ", "canzonePrompt", "red");
		return false;
		
	}
	else{
	jsShow("canproPrompt");
	producePrompt("እሺ!   ", "canzonePrompt", "green");
	setTimeout(function(){jsHide("canzonePrompt");}, 2000);
		return true;
	}
}
function validateWoreda(x)
{
	if(x == "-1"){
		jsShow("canwereaPrompt");
		producePrompt("እባክዎን ወረዳ ይምረጡ?  ", "canwereaPrompt", "red");
		return false;
	}
	else{
	jsShow("canwereaPrompt");
	producePrompt("እሺ !   ", "canwereaPrompt", "green");
	setTimeout(function(){jsHide("canwereaPrompt");}, 2000);
		return true;
	}
}
function validaterepemail()
{
	var caemail = document.getElementById("email").value;
	
	if(caemail.length == 0){
		jsShow("caemilPrompt");
		producePrompt("እባክዎን ኢሜይል? ", "caemilPrompt", "red");
		return false;
		
	}
	var emailexp = /^[\w\.\-_\+]+@[\w-]+(\.\w{2,4})+$/;
	if(!caemail.match(emailexp)){
		jsShow("caemilPrompt");
		producePrompt("የተሳሳተ ኢሜይል ", "caemilPrompt", "orange");
		return false;
	}
	jsShow("caemilPrompt");
	producePrompt("ትከክክል " + caemail, "caemilPrompt", "green");
	setTimeout(function(){jsHide("caemilPrompt");}, 2000);
		return frue;
}
function validatecanpone()
{
var phone = document.getElementById("pho_num").value;
if(phone.length == 0){
	jsShow("phonePrompt");
		producePrompt("እባክዎን ስልክ? ", "phonePrompt", "red");
		return false;
		
	}
	var phoexp=/^\+\d{3}-\d{3}-\d{3}-\d{4}$/;
	if(!phone.match(phoexp))
	{
		jsShow("phonePrompt");
		producePrompt("please include only digits ", "phonePrompt", "blue");
		return false;
	}
	if(phone.length == 17){
	jsShow("phonePrompt");
	producePrompt("መልካም " + phone, "phonePrompt", "green");
	setTimeout(function(){jsHide("phonePrompt");}, 4000);
		return true;
	}	
	
		jsShow("phonePrompt");
		producePrompt("የአካባቢ ኮድ ", "phonePrompt", "orange");
		return false;
}
function validateUsername()
{
	var A_name = document.getElementById("User_name").value;
	if(A_name.length == 0){
		jsShow("UserNamePrompt");
		producePrompt("እባክዎን የመግቢያ ሥም?", "UserNamePrompt", "red");
		return false;
		
	}
	var A_nameexp = /^[ሀ-ፐ]+[\.\-_][ሀ-ፐ]+$/;;
	if(!A_name.match(A_nameexp)){
		jsShow("UserNamePrompt");
		producePrompt("የተሳሳተ የመግቢያ ሥም?", "UserNamePrompt", "orange");
		return false;
	}
	if(A_name.length <= 3){
		jsShow("UserNamePrompt");
		producePrompt("ቢያንስ 3 ሆሄ", "UserNamePrompt", "blue");
		return false;
		
	}
	jsShow("UserNamePrompt");
	producePrompt("እባክዎን ደህና መጡ  " + A_name, "UserNamePrompt", "green");
	setTimeout(function(){jsHide("UserNamePrompt");}, 2000);
		return true;
}
function validatePassword()
{
	var pass=document.getElementById("password").value;
	var x=pass.length;
	if(x == 0){
		jsShow("PasswordPrompt");
		producePrompt("እባክዎን የይለፍ ቃል?    ", "PasswordPrompt", "red");
		return false;
		
	}
	if(x<=5){
		jsShow("PasswordPrompt");
		producePrompt(" ደካማ! !   ", "PasswordPrompt", "orange");
		return false;
		}
	jsShow("PasswordPrompt");
	producePrompt("ጠንካራ " , "PasswordPrompt", "green");
	setTimeout(function(){jsHide("PasswordPrompt");}, 2000);
		return true;
}
function validateRePassword(){
	var RPassword = document.getElementById("re_pasword").value;
	var pass=document.getElementById("password").value;
	var x=RPassword.length;
	if( x == 0){
		jsShow("re_passowrdPrompt");
		producePrompt("የይለፍ ቃል ድጋሚ  ", "re_passowrdPrompt", "red");
		return false;
		
	}
	
	if(pass ==RPassword){
		jsShow("re_passowrdPrompt");
	producePrompt("ተዛምዷል" , "re_passowrdPrompt", "green");	
	setTimeout(function(){jsHide("re_passowrdPrompt");}, 4000);
	return true;	
	}
	jsShow("re_passowrdPrompt");
	producePrompt("አልተዛደም" , "re_passowrdPrompt", "red");	
	return false;	
}
function jsShow(id){
	document.getElementById(id).style.display = "block";
}

function jsHide(id){
	document.getElementById(id).style.display = "none";
}

function producePrompt(message, promptLocation, color){
	document.getElementById(promptLocation).innerHTML = message;
	document.getElementById(promptLocation).style.color = color;
}