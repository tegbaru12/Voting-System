<?php
$pname=$_REQUEST['p_Name'];
$PIC=$_REQUEST['party_identity'];

$party_symbol=$_REQUEST['logo'];
$PRN=$_REQUEST['party_rep_name'];
$SSC=$_REQUEST['rep_ssn'];
$sex=$_REQUEST['v-sex'];
$age=$_REQUEST['ca_age'];
$PRP=$_REQUEST['party_rep_pro'];
$nationality=$_REQUEST['Nationality'];
$region=$_REQUEST['region'];
$zone=$_REQUEST['zone'];
$woreda=$_REQUEST['woreda'];
$email=$_REQUEST['email'];
$phone=$_REQUEST['phone_number'];
$username=$_REQUEST['user_name'];
$password=$_REQUEST['password'];
$db = mysql_connect("localhost", "root", "");
mysql_select_db("OVS",$db);
$sql="insert into party values('$pname','$PIC','$party','$PRN','$SSC','$sex',
'$age','$PRP','$nationality','$region','$zone','$woreda','$email','$username','$password')";
$ab=mysql_query($sql);
echo "thank you may bro";

?>